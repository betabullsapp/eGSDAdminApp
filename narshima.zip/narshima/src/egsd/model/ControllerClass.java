package egsd.model;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.parse4j.Parse;
import org.parse4j.ParseCloud;
import org.parse4j.ParseException;
import org.parse4j.ParseFile;
import org.parse4j.ParseObject;
import org.parse4j.ParseQuery;
import org.parse4j.ParseUser;
import org.parse4j.util.ParseRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.google.zxing.WriterException;

import egsd.model.DirectoryDetails;
import egsd.model.DirectoryDetailsModel;
import egsd.model.EgsdDirectoryItemObjects;
import egsd.model.EgsdDirectoryItemParseObject;
import egsd.model.EgsdHotelObjects;
import egsd.model.EgsdLoctionObject;
import egsd.model.EgsdLoginFields;
import egsd.model.EgsdMenuObjects;
import egsd.model.EgsdPhonesObjects;
import egsd.model.EgsdSearchTemplateObjects;
import egsd.model.EgsdStyleObjects;
import egsd.model.EgsdTemplateObjects;
import egsd.model.EgsdUserObjects;
import egsd.model.HotelMenuListModel;
import egsd.model.LocationAdminCount;
import egsd.service.GenerateQRCode;
import egsd.service.GenericComparator;
import egsd.service.PrintImage;
import egsd.service.SendEmail;

@Controller
public class ControllerClass {
	List<ParseObject> results = null;
	List<ParseObject> changeLocresults = null;
	List<ParseObject> resultsDirectoryItem = null;

	static ModelAndView mav = new ModelAndView();

	static {
		ParseRegistry.registerSubclass(EgsdDirectoryItemParseObject.class);
		ParseRegistry.registerSubclass(EgsdLoginFields.class);
		String applicationId = "FAbluZyN0hpXGpudGXrt9WOgvUQCxey3KEGALLle";
		String restAPIKey = "kuw3smoLkqoRfYbNKSPM4btXtlB33sdg9jGaIi65";
		//String applicationId = "y9HAZgLIScdanM185BzRUzrXnHU1leNK5swR1BpT";
		//String restAPIKey = "f37WJsYsPwymLqeC5sFzuHMA5Ev6owkxBdSCembt";
		System.out.println("b4 initialization");
		Parse.initialize(applicationId, restAPIKey);
		System.out.println("aftr initialization");
		System.out.println("----------------------------");

	}

	public static ModelAndView getDataFromParse(HttpServletRequest request) {

		System.out.println("this is from getDataFromParse");

		// ModelAndView mav=new ModelAndView();

		mav.clear();

		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("user:" + request.getParameter("user"));

		// mav.addObject("user", request.getAttribute("user"));
		// mav.addObject("userName", request.getAttribute("userName"));

		List<ParseObject> results = null;
		List<ParseObject> changeLocresults = null;

		ParseQuery<ParseObject> queryForLocationAdminWasEmpty = ParseQuery.getQuery("_User");
		queryForLocationAdminWasEmpty.whereEqualTo("user", "Location Admin");
		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfEmptyAdmins = null;

		try {
			listOfEmptyAdmins = queryForLocationAdminWasEmpty.find();
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));
			}

		} catch (NullPointerException npe) {

			listOfUserObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfEmptyLocationAdmins", listOfUserObjects);

		// list of Templates
		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
		queryForTemplateObjects.whereNotEqualTo("type", "group");

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list of Groups
		ParseQuery<ParseObject> queryForGroupObjects = ParseQuery.getQuery("Template");
		queryForGroupObjects.whereEqualTo("type", "group");

		List<ParseObject> listOfGroupObjects = null;

		try {
			listOfGroupObjects = queryForGroupObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();

				listOfEgsdGroupObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdGroupObjects", listOfEgsdGroupObjects);

		} catch (NullPointerException npe) {

		}

		ParseQuery<ParseObject> changeLocquery = ParseQuery.getQuery("Location");
		// changeLocquery.whereEqualTo("user",
		// request.getParameter("name"));
		try {
			changeLocresults = changeLocquery.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(changeLocresults);
		List<EgsdLoctionObject> changeLoc = new ArrayList<EgsdLoctionObject>(20);

		try {
			Iterator<ParseObject> changeLocIterator = changeLocresults.listIterator();
			while (changeLocIterator.hasNext()) {
				ParseObject locchange = changeLocIterator.next();

				changeLoc.add(new EgsdLoctionObject(locchange.getObjectId(), locchange.getString("Directories"),
						locchange.getString("Name"), locchange.getString("zipcode"), locchange.getString("Address1"),
						locchange.getString("Address2"), locchange.getString("Street"), locchange.getString("Town"),
						locchange.getString("GroupSiteId"), locchange.getString("GroupName"),
						locchange.getString("Country"), null, null, locchange.getString("ParentLocationID"),
						locchange.getString("description")));

			}
		} catch (NullPointerException npe) {

		}

		// System.out.println(changeLoc);
		mav.addObject("changeLoc", changeLoc);
		mav.addObject("selectLocObj", changeLoc);

		String directoryIdForLocationId = null;

		if (request.getParameter("objectId") != null) {
			ParseQuery<ParseObject> queryForDirectoryId = ParseQuery.getQuery("DirectoryItem");
			queryForDirectoryId.whereEqualTo("objectId", request.getParameter("objectId"));
			List<ParseObject> listObjectHavingRequiredDirectoryId = null;

			try {
				listObjectHavingRequiredDirectoryId = queryForDirectoryId.find();
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			Iterator<ParseObject> iteratorHavingDirectoryId = listObjectHavingRequiredDirectoryId.listIterator();

			ParseObject parseObjectHavingDirectoryId = iteratorHavingDirectoryId.next();

			directoryIdForLocationId = parseObjectHavingDirectoryId.getString("LocationId");
		}

		System.out.println("Location id:" + directoryIdForLocationId);

		ParseQuery<ParseObject> query = ParseQuery.getQuery("Location");
		if (request.getParameter("userName") != null)
			if (request.getParameter("userName").equals("Location Admin"))
				query.whereEqualTo("objectId", directoryIdForLocationId);
		// in case of selecting location
		/*
		 * if(request.getParameter("locId")!=null)
		 * query.whereEqualTo("objectId",request.getParameter("locId"));
		 */
		// in case of editing locations
		if (request.getParameter("objectIdOfLocation") != null)
			if (request.getParameter("userName").equals("Location Admin"))
				query.whereEqualTo("objectId", request.getParameter("objectIdOfLocation"));
		// incase of adding location
		/*
		 * if(request.getParameter("userName")!=null)
		 * if(request.getParameter("userName").equals("Location Admin"))
		 * if(request.getAttribute("locationId")!=null)
		 * query.whereEqualTo("objectId",request.getAttribute("locationId"));
		 * 
		 */

		// query.whereEqualTo("user", request.getParameter("name"));
		// query.whereEqualTo("Name", request.getParameter("locName"));

		try {
			results = query.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(results);
		List<EgsdLoctionObject> hlobj = new ArrayList<EgsdLoctionObject>();
		try {
			Iterator<ParseObject> hlit = results.listIterator();
			ParseObject p = null;
			while (hlit.hasNext()) {
				p = hlit.next();
				/*
				 * System.out.println(p.getObjectId());
				 * System.out.println(p.getString("Directories"));
				 * System.out.println(p.getString("Name"));
				 * System.out.println(p.getString("zipcode"));
				 * System.out.println(p.getString("Address1"));
				 */

				String logo = "No Image To Display";
				if (p.getParseFile("Logo") != null)
					logo = p.getParseFile("Logo").getUrl();

				String qRCode = "No Image To Display";
				if (p.getParseFile("QRCode") != null)
					qRCode = p.getParseFile("QRCode").getUrl();

				String hotelLogo = "No Image To Display";
				if (p.getParseFile("HotelLogo") != null)
					qRCode = p.getParseFile("HotelLogo").getUrl();

				String footerImage = "No Image To Display";
				if (p.getParseFile("footerImage") != null)
					qRCode = p.getParseFile("FooterImage").getUrl();

				EgsdLoctionObject e = new EgsdLoctionObject();

				e.setObjectId(p.getObjectId());
				e.setDirectory(p.getString("Directories"));
				e.setName(p.getString("Name"));
				e.setZipcode(p.getString("zipcode"));
				e.setAddress(p.getString("Address1"));
				e.setAddress2(p.getString("Address2"));
				e.setStreet(p.getString("Street"));
				e.setTown(p.getString("Town"));
				e.setSiteId(p.getString("siteId"));
				e.setGroupName(p.getString("GroupName"));
				e.setCountry(p.getString("Country"));
				e.setLogo(logo);
				e.setqRCode(qRCode);
				e.setParentDirectoryId(p.getString("ParentLocationID"));
				e.setDescription(p.getString("description"));

				hlobj.add(e);

				// hlobj.add(new
				// EgsdHotelAndLocObj(p.getString("hotel_name"),p.getString("location")));
			}
		} catch (NullPointerException npe) {

		}
		System.out.println(hlobj);

		mav.addObject("locObj", hlobj);
		mav.addObject("locObjForEdit", hlobj);
		mav.addObject("locObjForAddDirectoryItems", hlobj);
		mav.addObject("locObjForEditLocation", hlobj);
		mav.addObject("locObjForDeleteLocation", hlobj);
		mav.addObject("locObjForParentHotel", hlobj);

		// this is for directory items objects

		ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
		if (request.getParameter("locId") != null)
			queryForDirectoryItem.whereEqualTo("LocationId", request.getParameter("locId"));
		// queryForDirectoryItem.whereEqualTo("DirectoryID",p.getString("Directories"));
		queryForDirectoryItem.orderByAscending("Title");
		queryForDirectoryItem.limit(1000);
		List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
		try {
			directoryItemParseObjectsList = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(300);
		System.out.println("Directory items are loaded:");
		try {
			Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
			System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->"
					+ "getTitle" + "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->"
					+ "getEmail" + "--->" + "getPhones");
			int count = 1;
			while (iterator.hasNext()) {

				EgsdDirectoryItemParseObject egsd = iterator.next();
				// System.out.println( count++ +" "+ egsd.getObjectId()
				// + "---> " + egsd.getDirectoryId()
				// + "--->" + egsd.getParentDirectoryId()
				// + "--->" + egsd.getTitle()
				// + "--->" + egsd.getCaption()
				// + "--->" + egsd.getTimings()
				// + "--->" + egsd.getWebsite()
				// + "--->" + egsd.getEmail()
				// + "--phoneId->" + egsd.getPhones()
				// + "--->" + egsd.getStyleID() +"<--StyleID ");
				String img = "No Image To Display";
				if (egsd.getParseFile("Picture") != null)
					img = egsd.getParseFile("Picture").getUrl();
				// System.out.print(img);
				String styleId = null;
				ParseObject StyleIdPO = egsd.getParseObject("StyleId");
				if (egsd.getParseObject("StyleId") != null)
					styleId = StyleIdPO.getObjectId();
				// System.out.println(styleId);

				/*
				 * if(StyleIdPO.getObjectId()!=null) System.out.println(
				 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
				 */

				directoryItemObjectsList.add(new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(),
						egsd.getTitle(), egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
						egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
						egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

			}
		} catch (NullPointerException npe) {

		}

		System.out.println("before adding dir objs");
		mav.addObject("direcObjList", directoryItemObjectsList);
		mav.addObject("subDirObj", directoryItemObjectsList);
		mav.addObject("subsubDirObj", directoryItemObjectsList);
		mav.addObject("DirObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjId", directoryItemObjectsList);
		// adding DirectiryItems for editing values
		mav.addObject("showSubDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("showDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjForNavBar", directoryItemObjectsList);
		mav.addObject("subDiscriptionObjForNavBar", directoryItemObjectsList);
		// addind directory Items for Adding DirectoryItems
		mav.addObject("subDiscriptionObjForAddDirItems", directoryItemObjectsList);
		mav.addObject("showSubDiscriptionObjIdForDelete", directoryItemObjectsList);

		System.out.println("aftr adding dir objs");

		System.out.println("in select b4 Phones");

		ParseQuery<ParseObject> queryForPhones = ParseQuery.getQuery("Phones");
		queryForPhones.limit(1000);
		List<ParseObject> phonesParseObjectsList = null;
		try {
			phonesParseObjectsList = queryForPhones.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdPhonesObjects> phonesObjectsList = new ArrayList<EgsdPhonesObjects>(200);
		System.out.println("Phone Objects  are loaded:");
		// System.out.println(phonesParseObjectsList);
		try {
			Iterator<ParseObject> phoneIterator = phonesParseObjectsList.listIterator();
			int i = 0;
			while (phoneIterator.hasNext()) {

				ParseObject egsdPhonePO = phoneIterator.next();

				// System.out.println(egsdPhonePO.getObjectId()
				// +"-->"+egsdPhonePO.getString("PhoneId")
				// +"-->"+egsdPhonePO.getString("Type")
				// +"-->"+egsdPhonePO.getString("Ext"));
				phonesObjectsList.add(new EgsdPhonesObjects(egsdPhonePO.getObjectId(), egsdPhonePO.getString("PhoneId"),
						egsdPhonePO.getString("Type"), egsdPhonePO.getString("Ext")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(phonesObjectsList);
		mav.addObject("phonesObjectsList", phonesObjectsList);
		mav.addObject("phonesObjectsListForEdit", phonesObjectsList);
		mav.addObject("phonesObjectsListForDelete", phonesObjectsList);

		ParseQuery<ParseObject> queryForMenu = ParseQuery.getQuery("Menu");
		List<ParseObject> menuParseObjectsList = null;
		try {
			menuParseObjectsList = queryForMenu.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdMenuObjects> menuObjectsList = new ArrayList<EgsdMenuObjects>(200);
		System.out.println("Menu Items are loaded:");
		// System.out.println(menuParseObjectsList);
		try {
			Iterator<ParseObject> menuIterator = menuParseObjectsList.listIterator();
			while (menuIterator.hasNext()) {

				ParseObject egsdMenuPO = menuIterator.next();
				// System.out.println(egsdMenuPO.getObjectId() + "---> " +
				// egsdMenuPO.getString("MenuId") + "--->"
				// + egsdMenuPO.getString("Description") + "--->" +
				// egsdMenuPO.getString("Price"));
				// System.out.println(egsdMenuPO.getParseObject("StyleID"));
				// ParseObject styleIdObj=egsdMenuPO.getParseObject("StyleID");

				ParseObject ppp = egsdMenuPO.getParseObject("StyleID");
				// System.out.println("menu o.i:
				// "+egsdMenuPO.getObjectId()+"::styleId o.i:
				// "+ppp.getObjectId());

				menuObjectsList.add(new EgsdMenuObjects(egsdMenuPO.getObjectId(), egsdMenuPO.getString("MenuId"),
						egsdMenuPO.getString("Description"), egsdMenuPO.getString("Price"), ppp.getObjectId()));
			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(menuObjectsList);
		mav.addObject("menuObjectsList", menuObjectsList);
		mav.addObject("menuObjectsListForEdit", menuObjectsList);
		mav.addObject("menuObjectsListForDelete", menuObjectsList);

		// loading StyleId objs
		ParseQuery<ParseObject> queryForStyleID = ParseQuery.getQuery("Style");
		queryForStyleID.limit(1000);
		List<ParseObject> styleIdObjParseObj = null;
		try {
			styleIdObjParseObj = queryForStyleID.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdStyleObjects> styleObjects = new ArrayList<EgsdStyleObjects>(200);
		try {
			Iterator<ParseObject> styleIterator = styleIdObjParseObj.listIterator();
			// System.out.println(styleIdObjParseObj);

			while (styleIterator.hasNext()) {
				ParseObject sp = styleIterator.next();
				/*
				 * System.out.println(sp.getObjectId()
				 * +"-->"+sp.getString("TitleFont")
				 * +"-->"+sp.getString("TitleColor")
				 * +"-->"+sp.getString("CaptionFont")
				 * +"-->"+sp.getString("CaptionColor")
				 * +"-->"+sp.getString("DescriptionFont")
				 * +"-->"+sp.getString("DescriptionColor")
				 * +"-->"+sp.getString("PhonesFont")
				 * +"-->"+sp.getString("PhonesColor")
				 * +"-->"+sp.getString("TimingsFont")
				 * +"-->"+sp.getString("TimingsColor")
				 * +"-->"+sp.getString("WebsiteFont")
				 * +"-->"+sp.getString("WebsiteColor")
				 * +"-->"+sp.getString("EmailFont")
				 * +"-->"+sp.getString("EmailColor")
				 * +"-->"+sp.getString("StyleID")
				 * +"-->"+sp.getString("PriceFont")
				 * +"-->"+sp.getString("PriceColor"));
				 */

				styleObjects.add(new EgsdStyleObjects(sp.getObjectId(), sp.getString("TitleFont"),
						sp.getString("TitleColor"), sp.getString("TitleFamily"), sp.getString("CaptionFont"),
						sp.getString("CaptionColor"), sp.getString("CaptionFamily"), sp.getString("DescriptionFont"),
						sp.getString("DescriptionColor"), sp.getString("DescriptionFamily"), sp.getString("PhonesFont"),
						sp.getString("PhonesColor"), sp.getString("PhonesFamily"), sp.getString("TimingsFont"),
						sp.getString("TimingsColor"), sp.getString("TimingsFamily"), sp.getString("WebsiteFont"),
						sp.getString("WebsiteColor"), sp.getString("WebsiteFamily"), sp.getString("EmailFont"),
						sp.getString("EmailColor"), sp.getString("EmailFamily"), sp.getString("StyleID"),
						sp.getString("PriceFont"), sp.getString("PriceColor"), sp.getString("PriceFamily")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(styleObjects);
		System.out.println("Style items are Loaded");
		mav.addObject("styleObjects", styleObjects);
		mav.addObject("styleObjectsForEdit", styleObjects);
		mav.addObject("styleObjectsForMenu", styleObjects);
		mav.addObject("styleObjectsForAddDirItems", styleObjects);
		mav.addObject("styleObjectsForDelete", styleObjects);

		System.out.println("End of Controller");

		return mav;
	}

	@RequestMapping(value = "/print")
	public ModelAndView print(HttpServletRequest request) throws Exception {

		mav.setViewName("SuperAdmin");
		System.out.println(request.getParameter("qrcode"));
		String imgUrl = request.getParameter("qrcode");
		PrintImage image = new PrintImage();
		String res = image.printImage(imgUrl);
		System.out.println(res);
		return mav;
	}

	@SuppressWarnings("finally")
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(HttpServletRequest request) {

		try {
			ParseUser ps = ParseUser.login(request.getParameter("username"), request.getParameter("password"));

			System.out.println(ps.getString("user"));

			System.out.println("userName:" + ps.getString("user"));
			System.out.println("user:" + request.getParameter("username"));

			request.setAttribute("userName", ps.getString("user"));
			request.setAttribute("user", request.getParameter("username"));

			// EgsdController.getDataFromParse(request);

			// mav.clear();

			if (ps.getString("user").equals("CS Admin")) {
				adminLoad(request);
				mav.setViewName("CSHotelList");
			}

			else if (ps.getString("user").equals("IT Admin")) {
				adminLoad(request);
				mav.setViewName("ITHotelList");
			}

			else if (ps.getString("user").equals("Super Admin")) {

				adminLoad(request);
				mav.setViewName("SuperHotelList");

			} else {

				request.setAttribute("locationId", ps.getObjectId());
				System.out.println(ps.getObjectId());
				mav.clear();
				LocationAdminCount lcount = new LocationAdminCount();
				int count = locationDetails(request);

				if (count > 0) {
					mav.setViewName("LocationList");
				} else {
					mav.setViewName("LocationDetails");
				}

			}

			// mav.addObject(returnObjectsOfMethod);
			mav.addObject("userName", ps.getString("user"));
			mav.addObject("user", request.getParameter("username"));

		} catch (ParseException pe) {
			mav.setViewName("Error");
			mav.addObject("errorMsg", "Enter Valid UserName/Password.");
		} finally {
			return mav;
		}

	}

	public static void adminLoad(HttpServletRequest request) {

		mav.clear();

		List<ParseObject> results = null;
		List<ParseObject> changeLocresults = null;

		ParseQuery<ParseObject> queryForLocationAdminWasEmpty = ParseQuery.getQuery("_User");
		queryForLocationAdminWasEmpty.whereEqualTo("user", "Location Admin");
		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfEmptyAdmins = null;

		try {
			listOfEmptyAdmins = queryForLocationAdminWasEmpty.find();
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));
				System.out.println(parseObjectHavingEmptyAdmins.getString("firstname") + " firstname and last name "
						+ parseObjectHavingEmptyAdmins.getString("lastname"));
			}

		} catch (NullPointerException npe) {

			listOfUserObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfEmptyLocationAdmins", listOfUserObjects);

		// list of admins

		ParseQuery<ParseObject> queryForAdmins = ParseQuery.getQuery("_User");
		// queryForLocationAdminWasEmpty.addAscendingOrder("username");
		queryForAdmins.orderByAscending("user");
		queryForAdmins.whereNotEqualTo("user", "IT Admin");
		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfAdmins = null;

		try {

			listOfAdmins = queryForAdmins.find();

		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfAdminObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfAdminObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));

			}

		} catch (NullPointerException npe) {

			listOfAdminObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfAdmins", listOfAdminObjects);

		// list of Templates
		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
		queryForTemplateObjects.whereNotEqualTo("type", "group");

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list of Groups
		ParseQuery<ParseObject> queryForGroupObjects = ParseQuery.getQuery("Template");
		queryForGroupObjects.whereEqualTo("type", "group");

		List<ParseObject> listOfGroupObjects = null;

		try {
			listOfGroupObjects = queryForGroupObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();

				listOfEgsdGroupObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdGroupObjects", listOfEgsdGroupObjects);

		} catch (NullPointerException npe) {

		}

		ParseQuery<ParseObject> changeLocquery = ParseQuery.getQuery("Location");
		changeLocquery.addAscendingOrder("Name");
		// changeLocquery.whereEqualTo("user",
		// request.getParameter("name"));
		try {
			changeLocresults = changeLocquery.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(changeLocresults);
		List<EgsdLoctionObject> changeLoc = new ArrayList<EgsdLoctionObject>(20);

		try {
			Iterator<ParseObject> changeLocIterator = changeLocresults.listIterator();
			while (changeLocIterator.hasNext()) {
				ParseObject locchange = changeLocIterator.next();

				changeLoc.add(new EgsdLoctionObject(locchange.getObjectId(), locchange.getString("Directories"),
						locchange.getString("Name"), locchange.getString("zipcode"), locchange.getString("Address1"),
						locchange.getString("Address2"), locchange.getString("Street"), locchange.getString("Town"),
						locchange.getString("GroupSiteId"), locchange.getString("GroupName"),
						locchange.getString("Country"), null, null, locchange.getString("ParentLocationID"),
						locchange.getString("description")));

			}
		} catch (NullPointerException npe) {

		}

		// System.out.println(changeLoc);
		mav.addObject("changeLoc", changeLoc);
		mav.addObject("selectLocObj", changeLoc);

		String directoryIdForLocationId = null;

		if (request.getParameter("objectId") != null) {
			ParseQuery<ParseObject> queryForDirectoryId = ParseQuery.getQuery("DirectoryItem");
			queryForDirectoryId.whereEqualTo("objectId", request.getParameter("objectId"));
			List<ParseObject> listObjectHavingRequiredDirectoryId = null;

			try {
				listObjectHavingRequiredDirectoryId = queryForDirectoryId.find();
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			Iterator<ParseObject> iteratorHavingDirectoryId = listObjectHavingRequiredDirectoryId.listIterator();

			ParseObject parseObjectHavingDirectoryId = iteratorHavingDirectoryId.next();

			directoryIdForLocationId = parseObjectHavingDirectoryId.getString("LocationId");
		}

		System.out.println("Location id:" + directoryIdForLocationId);

		ParseQuery<ParseObject> query = ParseQuery.getQuery("Location");
		if (request.getParameter("userName") != null)
			if (request.getParameter("userName").equals("Location Admin"))
				query.whereEqualTo("objectId", directoryIdForLocationId);
		// in case of selecting location
		/*
		 * if(request.getParameter("locId")!=null)
		 * query.whereEqualTo("objectId",request.getParameter("locId"));
		 */
		// in case of editing locations
		if (request.getParameter("objectIdOfLocation") != null)
			if (request.getParameter("userName").equals("Location Admin"))
				query.whereEqualTo("objectId", request.getParameter("objectIdOfLocation"));
		// incase of adding location
		/*
		 * if(request.getParameter("userName")!=null)
		 * if(request.getParameter("userName").equals("Location Admin"))
		 * if(request.getAttribute("locationId")!=null)
		 * query.whereEqualTo("objectId",request.getAttribute("locationId"));
		 * 
		 */

		// query.whereEqualTo("user", request.getParameter("name"));
		// query.whereEqualTo("Name", request.getParameter("locName"));

		try {
			results = query.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(results);
		List<EgsdLoctionObject> hlobj = new ArrayList<EgsdLoctionObject>();
		try {
			Iterator<ParseObject> hlit = results.listIterator();
			ParseObject p = null;
			while (hlit.hasNext()) {
				p = hlit.next();
				/*
				 * System.out.println(p.getObjectId());
				 * System.out.println(p.getString("Directories"));
				 * System.out.println(p.getString("Name"));
				 * System.out.println(p.getString("zipcode"));
				 * System.out.println(p.getString("Address1"));
				 */

				String logo = "No Image To Display";
				if (p.getParseFile("Logo") != null)
					logo = p.getParseFile("Logo").getUrl();

				String qRCode = "No Image To Display";
				if (p.getParseFile("QRCode") != null)
					qRCode = p.getParseFile("QRCode").getUrl();

				String hotelLogo = "No Image To Display";
				if (p.getParseFile("HotelLogo") != null)
					qRCode = p.getParseFile("HotelLogo").getUrl();

				String footerImage = "No Image To Display";
				if (p.getParseFile("footerImage") != null)
					qRCode = p.getParseFile("FooterImage").getUrl();

				EgsdLoctionObject e = new EgsdLoctionObject();

				e.setObjectId(p.getObjectId());
				e.setDirectory(p.getString("Directories"));
				e.setName(p.getString("Name"));
				e.setZipcode(p.getString("zipcode"));
				e.setAddress(p.getString("Address1"));
				e.setAddress2(p.getString("Address2"));
				e.setStreet(p.getString("Street"));
				e.setTown(p.getString("Town"));
				e.setSiteId(p.getString("siteId"));
				e.setGroupName(p.getString("GroupName"));
				e.setCountry(p.getString("Country"));
				e.setLogo(logo);
				e.setqRCode(qRCode);
				e.setParentDirectoryId(p.getString("ParentLocationID"));
				e.setDescription(p.getString("description"));

				hlobj.add(e);

				// hlobj.add(new EgsdLoctionObject(p.getObjectId(),
				// p.getString("Directories"), p.getString("Name"),
				// p.getString("zipcode"), p.getString("Address1"),
				// p.getString("Address2"), p.getString("Street"),
				// p.getString("Town"),p.getString("GroupSiteId"),p.getString("GroupName"),p.getString("Country"),
				// logo,qRCode,p.getString("ParentLocationID"),p.getString("description")));

				// hlobj.add(new
				// EgsdHotelAndLocObj(p.getString("hotel_name"),p.getString("location")));
			}
		} catch (NullPointerException npe) {

		}
		System.out.println(hlobj);

		mav.addObject("locObj", hlobj);
		mav.addObject("locObjForEdit", hlobj);
		mav.addObject("locObjForAddDirectoryItems", hlobj);
		mav.addObject("locObjForEditLocation", hlobj);
		mav.addObject("locObjForDeleteLocation", hlobj);
		mav.addObject("locObjForParentHotel", hlobj);

	}

	public static void adminLoad1(HttpServletRequest request) {

		mav.clear();

		List<ParseObject> results = null;
		List<ParseObject> changeLocresults = null;

	}

	public static int locationDetails(HttpServletRequest request) {

		System.out.println("locationId:" + request.getAttribute("locationId"));
		int lcount = 0;

		ParseQuery<ParseObject> queryForGroupLocationAdminHotels = ParseQuery.getQuery("Location");
		queryForGroupLocationAdminHotels.whereEqualTo("GroupId", request.getAttribute("locationId"));

		List<ParseObject> listOfLocationsFromParse = null;

		try {
			listOfLocationsFromParse = queryForGroupLocationAdminHotels.find();

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (listOfLocationsFromParse == null) {
			lcount = 0;
		} else {
			lcount = listOfLocationsFromParse.size();
		}

		try {

			Iterator<ParseObject> iteratorForLocations = listOfLocationsFromParse.listIterator();

			List<EgsdLoctionObject> listOfParseLocationObjects = new ArrayList<EgsdLoctionObject>(10);

			while (iteratorForLocations.hasNext()) {

				ParseObject p = iteratorForLocations.next();
				// p = hlit.next();
				/*
				 * System.out.println(p.getObjectId());
				 * System.out.println(p.getString("Directories"));
				 * System.out.println(p.getString("Name"));
				 * System.out.println(p.getString("zipcode"));
				 * System.out.println(p.getString("Address1"));
				 */

				String logo = "No Image To Display";
				if (p.getParseFile("Logo") != null)
					logo = p.getParseFile("Logo").getUrl();

				String qRCode = "No Image To Display";
				if (p.getParseFile("QRCode") != null)
					qRCode = p.getParseFile("QRCode").getUrl();

				String hotelLogo = "No Image To Display";
				if (p.getParseFile("HotelLogo") != null)
					qRCode = p.getParseFile("HotelLogo").getUrl();

				String footerImage = "No Image To Display";
				if (p.getParseFile("footerImage") != null)
					qRCode = p.getParseFile("FooterImage").getUrl();

				EgsdLoctionObject e = new EgsdLoctionObject();

				e.setObjectId(p.getObjectId());
				e.setDirectory(p.getString("Directories"));
				e.setName(p.getString("Name"));
				e.setZipcode(p.getString("zipcode"));
				e.setAddress(p.getString("Address1"));
				e.setAddress2(p.getString("Address2"));
				e.setStreet(p.getString("Street"));
				e.setTown(p.getString("Town"));
				e.setSiteId(p.getString("siteId"));
				e.setGroupName(p.getString("GroupName"));
				e.setCountry(p.getString("Country"));
				e.setLogo(logo);
				e.setqRCode(qRCode);
				e.setParentDirectoryId(p.getString("ParentLocationID"));
				e.setDescription(p.getString("description"));

				listOfParseLocationObjects.add(e);
				//
				//
				//
				// listOfParseLocationObjects.add(new
				// EgsdLoctionObject(p.getObjectId(),
				// p.getString("Directories"), p.getString("Name"),
				// p.getString("zipcode"), p.getString("Address1"),
				// p.getString("Address2"), p.getString("Street"),
				// p.getString("Town"),p.getString("GroupSiteId"),p.getString("GroupName"),p.getString("Country"),logo,qRCode,p.getString("ParentLocationID"),p.getString("description")));
				//
				//

			}

			mav.addObject("hotelsList", listOfParseLocationObjects.size());

			mav.addObject("selectLocObj", listOfParseLocationObjects);
			mav.addObject("locObjForEdit", listOfParseLocationObjects);
			mav.addObject("locObjForAddDirectoryItems", listOfParseLocationObjects);
			mav.addObject("locObjForEditLocation", listOfParseLocationObjects);
			mav.addObject("locObjForDeleteLocation", listOfParseLocationObjects);
			mav.addObject("locObjForParentHotel", listOfParseLocationObjects);

			System.out.println("End of Controller");

		} catch (NullPointerException npe) {

			System.out.println(npe);
		}
		return lcount;

	}

	public static void locationDetails1(HttpServletRequest request) {

		System.out.println("locationId:" + request.getAttribute("locationId"));

		ParseQuery<ParseObject> queryForGroupLocationAdminHotels = ParseQuery.getQuery("Location");
		queryForGroupLocationAdminHotels.whereEqualTo("GroupId", request.getAttribute("locationId"));

		List<ParseObject> listOfLocationsFromParse = null;

		try {
			listOfLocationsFromParse = queryForGroupLocationAdminHotels.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForLocations = listOfLocationsFromParse.listIterator();

			List<EgsdLoctionObject> listOfParseLocationObjects = new ArrayList<EgsdLoctionObject>(10);

			while (iteratorForLocations.hasNext()) {

				ParseObject p = iteratorForLocations.next();
				// p = hlit.next();
				/*
				 * System.out.println(p.getObjectId());
				 * System.out.println(p.getString("Directories"));
				 * System.out.println(p.getString("Name"));
				 * System.out.println(p.getString("zipcode"));
				 * System.out.println(p.getString("Address1"));
				 */

				String logo = "No Image To Display";
				if (p.getParseFile("Logo") != null)
					logo = p.getParseFile("Logo").getUrl();

				String qRCode = "No Image To Display";
				if (p.getParseFile("QRCode") != null)
					qRCode = p.getParseFile("QRCode").getUrl();
				String hotelLogo = "No Image To Display";

				if (p.getParseFile("HotelLogo") != null)
					qRCode = p.getParseFile("HotelLogo").getUrl();

				String footerImage = "No Image To Display";
				if (p.getParseFile("FooterImage") != null)
					qRCode = p.getParseFile("FooterImage").getUrl();

				EgsdLoctionObject e = new EgsdLoctionObject();

				e.setObjectId(p.getObjectId());
				e.setDirectory(p.getString("Directories"));
				e.setName(p.getString("Name"));
				e.setZipcode(p.getString("zipcode"));
				e.setAddress(p.getString("Address1"));
				e.setAddress2(p.getString("Address2"));
				e.setStreet(p.getString("Street"));
				e.setTown(p.getString("Town"));
				e.setSiteId(p.getString("siteId"));
				e.setGroupName(p.getString("GroupName"));
				e.setCountry(p.getString("Country"));
				e.setLogo(logo);
				e.setqRCode(qRCode);
				e.setParentDirectoryId(p.getString("ParentLocationID"));
				e.setDescription(p.getString("description"));

				listOfParseLocationObjects.add(e);

				// listOfParseLocationObjects.add(new
				// EgsdLoctionObject(p.getObjectId(),
				// p.getString("Directories"), p.getString("Name"),
				// p.getString("zipcode"), p.getString("Address1"),
				// p.getString("Address2"), p.getString("Street"),
				// p.getString("Town"),p.getString("GroupSiteId"),p.getString("GroupName"),p.getString("Country"),logo,qRCode,p.getString("ParentLocationID"),p.getString("description")));

			}

			mav.addObject("selectLocObj", listOfParseLocationObjects);
			mav.addObject("locObjForEdit", listOfParseLocationObjects);
			mav.addObject("locObjForAddDirectoryItems", listOfParseLocationObjects);
			mav.addObject("locObjForEditLocation", listOfParseLocationObjects);
			mav.addObject("locObjForDeleteLocation", listOfParseLocationObjects);
			mav.addObject("locObjForParentHotel", listOfParseLocationObjects);

			// this is for directory items objects

			ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
			if (request.getParameter("locId") != null)
				queryForDirectoryItem.whereEqualTo("LocationId", request.getParameter("locId"));
			// queryForDirectoryItem.whereEqualTo("DirectoryID",p.getString("Directories"));
			queryForDirectoryItem.orderByAscending("Title");
			queryForDirectoryItem.limit(1000);
			List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
			try {
				directoryItemParseObjectsList = queryForDirectoryItem.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(300);
			System.out.println("Directory items are loaded:");
			try {
				Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
				System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->"
						+ "getTitle" + "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->"
						+ "getEmail" + "--->" + "getPhones");
				int count = 1;
				while (iterator.hasNext()) {

					EgsdDirectoryItemParseObject egsd = iterator.next();
					// System.out.println( count++ +" "+ egsd.getObjectId()
					// + "---> " + egsd.getDirectoryId()
					// + "--->" + egsd.getParentDirectoryId()
					// + "--->" + egsd.getTitle()
					// + "--->" + egsd.getCaption()
					// + "--->" + egsd.getTimings()
					// + "--->" + egsd.getWebsite()
					// + "--->" + egsd.getEmail()
					// + "--phoneId->" + egsd.getPhones()
					// + "--->" + egsd.getStyleID() +"<--StyleID ");
					String img = "No Image To Display";
					if (egsd.getParseFile("Picture") != null)
						img = egsd.getParseFile("Picture").getUrl();
					// System.out.print(img);
					String styleId = null;
					ParseObject StyleIdPO = egsd.getParseObject("StyleId");
					if (egsd.getParseObject("StyleId") != null)
						styleId = StyleIdPO.getObjectId();
					// System.out.println(styleId);

					/*
					 * if(StyleIdPO.getObjectId()!=null) System.out.println(
					 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
					 */

					directoryItemObjectsList.add(
							new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(), egsd.getTitle(),
									egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
									egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
									egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

				}
			} catch (NullPointerException npe) {

			}

			System.out.println("before adding dir objs");
			mav.addObject("direcObjList", directoryItemObjectsList);
			mav.addObject("subDirObj", directoryItemObjectsList);
			mav.addObject("subsubDirObj", directoryItemObjectsList);
			mav.addObject("DirObjId", directoryItemObjectsList);
			mav.addObject("DiscriptionObjId", directoryItemObjectsList);
			// adding DirectiryItems for editing values
			mav.addObject("showSubDiscriptionObjId", directoryItemObjectsList);
			mav.addObject("showDiscriptionObjId", directoryItemObjectsList);
			mav.addObject("DiscriptionObjForNavBar", directoryItemObjectsList);
			mav.addObject("subDiscriptionObjForNavBar", directoryItemObjectsList);
			// addind directory Items for Adding DirectoryItems
			mav.addObject("subDiscriptionObjForAddDirItems", directoryItemObjectsList);
			mav.addObject("showSubDiscriptionObjIdForDelete", directoryItemObjectsList);

			System.out.println("aftr adding dir objs");

			System.out.println("in select b4 Phones");

			ParseQuery<ParseObject> queryForPhones = ParseQuery.getQuery("Phones");
			queryForPhones.limit(1000);
			List<ParseObject> phonesParseObjectsList = null;
			try {
				phonesParseObjectsList = queryForPhones.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<EgsdPhonesObjects> phonesObjectsList = new ArrayList<EgsdPhonesObjects>(200);
			System.out.println("Phone Objects  are loaded:");
			// System.out.println(phonesParseObjectsList);
			try {
				Iterator<ParseObject> phoneIterator = phonesParseObjectsList.listIterator();
				int i = 0;
				while (phoneIterator.hasNext()) {

					ParseObject egsdPhonePO = phoneIterator.next();

					// System.out.println(egsdPhonePO.getObjectId()
					// +"-->"+egsdPhonePO.getString("PhoneId")
					// +"-->"+egsdPhonePO.getString("Type")
					// +"-->"+egsdPhonePO.getString("Ext"));
					phonesObjectsList
							.add(new EgsdPhonesObjects(egsdPhonePO.getObjectId(), egsdPhonePO.getString("PhoneId"),
									egsdPhonePO.getString("Type"), egsdPhonePO.getString("Ext")));

				}
			} catch (NullPointerException npe) {

			}
			// System.out.println(phonesObjectsList);
			mav.addObject("phonesObjectsList", phonesObjectsList);
			mav.addObject("phonesObjectsListForEdit", phonesObjectsList);
			mav.addObject("phonesObjectsListForDelete", phonesObjectsList);

			ParseQuery<ParseObject> queryForMenu = ParseQuery.getQuery("Menu");
			List<ParseObject> menuParseObjectsList = null;
			try {
				menuParseObjectsList = queryForMenu.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<EgsdMenuObjects> menuObjectsList = new ArrayList<EgsdMenuObjects>(200);
			System.out.println("Menu Items are loaded:");
			// System.out.println(menuParseObjectsList);
			try {
				Iterator<ParseObject> menuIterator = menuParseObjectsList.listIterator();
				while (menuIterator.hasNext()) {

					ParseObject egsdMenuPO = menuIterator.next();
					// System.out.println(egsdMenuPO.getObjectId() + "---> " +
					// egsdMenuPO.getString("MenuId") + "--->"
					// + egsdMenuPO.getString("Description") + "--->" +
					// egsdMenuPO.getString("Price"));
					// System.out.println(egsdMenuPO.getParseObject("StyleID"));
					// ParseObject
					// styleIdObj=egsdMenuPO.getParseObject("StyleID");

					ParseObject ppp = egsdMenuPO.getParseObject("StyleID");
					// System.out.println("menu o.i:
					// "+egsdMenuPO.getObjectId()+"::styleId o.i:
					// "+ppp.getObjectId());

					menuObjectsList.add(new EgsdMenuObjects(egsdMenuPO.getObjectId(), egsdMenuPO.getString("MenuId"),
							egsdMenuPO.getString("Description"), egsdMenuPO.getString("Price"), ppp.getObjectId()));
				}
			} catch (NullPointerException npe) {

			}
			// System.out.println(menuObjectsList);
			mav.addObject("menuObjectsList", menuObjectsList);
			mav.addObject("menuObjectsListForEdit", menuObjectsList);
			mav.addObject("menuObjectsListForDelete", menuObjectsList);

			// loading StyleId objs
			ParseQuery<ParseObject> queryForStyleID = ParseQuery.getQuery("Style");
			queryForStyleID.limit(1000);
			List<ParseObject> styleIdObjParseObj = null;
			try {
				styleIdObjParseObj = queryForStyleID.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<EgsdStyleObjects> styleObjects = new ArrayList<EgsdStyleObjects>(200);
			try {
				Iterator<ParseObject> styleIterator = styleIdObjParseObj.listIterator();
				// System.out.println(styleIdObjParseObj);

				while (styleIterator.hasNext()) {
					ParseObject sp = styleIterator.next();
					/*
					 * System.out.println(sp.getObjectId()
					 * +"-->"+sp.getString("TitleFont")
					 * +"-->"+sp.getString("TitleColor")
					 * +"-->"+sp.getString("CaptionFont")
					 * +"-->"+sp.getString("CaptionColor")
					 * +"-->"+sp.getString("DescriptionFont")
					 * +"-->"+sp.getString("DescriptionColor")
					 * +"-->"+sp.getString("PhonesFont")
					 * +"-->"+sp.getString("PhonesColor")
					 * +"-->"+sp.getString("TimingsFont")
					 * +"-->"+sp.getString("TimingsColor")
					 * +"-->"+sp.getString("WebsiteFont")
					 * +"-->"+sp.getString("WebsiteColor")
					 * +"-->"+sp.getString("EmailFont")
					 * +"-->"+sp.getString("EmailColor")
					 * +"-->"+sp.getString("StyleID")
					 * +"-->"+sp.getString("PriceFont")
					 * +"-->"+sp.getString("PriceColor"));
					 */

					styleObjects
							.add(new EgsdStyleObjects(sp.getObjectId(), sp.getString("TitleFont"),
									sp.getString("TitleColor"), sp.getString("TitleFamily"), sp.getString(
											"CaptionFont"),
									sp.getString("CaptionColor"), sp.getString("CaptionFamily"),
									sp.getString("DescriptionFont"), sp.getString("DescriptionColor"),
									sp.getString("DescriptionFamily"), sp.getString("PhonesFont"),
									sp.getString("PhonesColor"), sp.getString("PhonesFamily"),
									sp.getString("TimingsFont"), sp.getString("TimingsColor"),
									sp.getString("TimingsFamily"), sp.getString("WebsiteFont"),
									sp.getString("WebsiteColor"), sp.getString("WebsiteFamily"),
									sp.getString("EmailFont"), sp.getString("EmailColor"), sp.getString("EmailFamily"),
									sp.getString("StyleID"), sp.getString("PriceFont"), sp.getString("PriceColor"),
									sp.getString("PriceFamily")));

				}
			} catch (NullPointerException npe) {

			}
			// System.out.println(styleObjects);
			System.out.println("Style items are Loaded");
			mav.addObject("styleObjects", styleObjects);
			mav.addObject("styleObjectsForEdit", styleObjects);
			mav.addObject("styleObjectsForMenu", styleObjects);
			mav.addObject("styleObjectsForAddDirItems", styleObjects);
			mav.addObject("styleObjectsForDelete", styleObjects);

			System.out.println("End of Controller");

		} catch (NullPointerException npe) {

		}

	}

	String userName = "";

	@RequestMapping(value = "/select")
	public synchronized ModelAndView select(HttpServletRequest request) throws ParseException {

		System.out.println("User:" + request.getParameter("user"));
		System.out.println("UserName:" + request.getParameter("userName"));
		System.out.println("user:" + request.getAttribute("user"));
		System.out.println("username:" + request.getAttribute("userName"));
		System.out.println("LocId:" + request.getParameter("locId"));
		System.out.println("LocId:" + request.getAttribute("locId"));

		// mav.addObject("userName", request.getParameter("name"));
		// mav.addObject("user", request.getParameter("user"));

		/*
		 * ParseQuery<ParseObject>
		 * queryForAddingChain=ParseQuery.getQuery("Location");
		 * queryForAddingChain.whereEqualTo("objectId",request.getParameter(
		 * "locId"));
		 */
		mav.clear();

		List<ParseObject> results = null;
		List<ParseObject> changeLocresults = null;

		ParseQuery<ParseObject> queryForLocationAdminWasEmpty = ParseQuery.getQuery("_User");
		
		queryForLocationAdminWasEmpty.orderByAscending("username");
		queryForLocationAdminWasEmpty.whereEqualTo("user", "Location Admin");
		

		List<ParseObject> listOfEmptyAdmins = null;

		try {

			listOfEmptyAdmins = queryForLocationAdminWasEmpty.find();

		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));

			}

		} catch (NullPointerException npe) {

			listOfUserObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfEmptyLocationAdmins", listOfUserObjects);

		ParseQuery<ParseObject> queryForAdmins = ParseQuery.getQuery("_User");
		// queryForLocationAdminWasEmpty.addAscendingOrder("username");

		queryForAdmins.whereEqualTo("Status", true);
		if (request.getParameter("userName") != null) {
			userName = request.getParameter("userName");
		}
		if (request.getAttribute("userName") != null) {
			userName = (String) request.getAttribute("userName");
		}

		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfAdmins = null;

		try {

			listOfAdmins = queryForAdmins.find();

		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfAdminObjects = new ArrayList<EgsdUserObjects>(100);
		List<EgsdUserObjects> listOfAdminObjects1 = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfAdminObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));

			}

		} catch (NullPointerException npe) {

			listOfAdminObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}
		System.out.println(listOfAdminObjects.size());
		if (userName.equals("IT Admin")) {

			for (int k = 0; k < listOfAdminObjects.size(); k++) {
				if (listOfAdminObjects.get(k).getUser().toString().equals("IT Admin")) {
					listOfAdminObjects1.add(listOfAdminObjects.get(k));
				}
			}
			for (int k = 0; k < listOfAdminObjects.size(); k++) {
				if (listOfAdminObjects.get(k).getUser().toString().equals("Super Admin")) {
					listOfAdminObjects1.add(listOfAdminObjects.get(k));
				}
			}

			for (int k = 0; k < listOfAdminObjects.size(); k++) {
				if (listOfAdminObjects.get(k).getUser().toString().equals("CS Admin")) {
					listOfAdminObjects1.add(listOfAdminObjects.get(k));
				}
			}
			for (int k = 0; k < listOfAdminObjects.size(); k++) {
				if (listOfAdminObjects.get(k).getUser().toString().equals("Location Admin")) {
					listOfAdminObjects1.add(listOfAdminObjects.get(k));
				}
			}
		}
		System.out.println("userName is " + userName);
		if (userName.equals("Super Admin")) {

			for (int k = 0; k < listOfAdminObjects.size(); k++) {
				if (listOfAdminObjects.get(k).getUser().toString().equals("CS Admin")) {
					listOfAdminObjects1.add(listOfAdminObjects.get(k));
				}
			}
			for (int k = 0; k < listOfAdminObjects.size(); k++) {
				if (listOfAdminObjects.get(k).getUser().toString().equals("Location Admin")) {
					listOfAdminObjects1.add(listOfAdminObjects.get(k));
				}
			}
		}
		if (userName.equals("CS Admin")) {
			for (int k = 0; k < listOfAdminObjects.size(); k++) {
				if (listOfAdminObjects.get(k).getUser().toString().equals("Location Admin")) {
					listOfAdminObjects1.add(listOfAdminObjects.get(k));
				}
			}
		}
		for (EgsdUserObjects e : listOfAdminObjects1) {
			System.out.println(e.getUser() + "-->" + e.getUsername());

		}
		System.out.println(listOfAdminObjects1.size());
		mav.addObject("listOfAdmins", listOfAdminObjects1);

		// list of Templates
		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
		queryForTemplateObjects.orderByAscending("Name");
		queryForTemplateObjects.whereNotEqualTo("type", "group");

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(100);

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list of Groups
		ParseQuery<ParseObject> queryForGroupObjects = ParseQuery.getQuery("Template");
		queryForGroupObjects.orderByAscending("Name");

		queryForGroupObjects.whereEqualTo("type", "group");

		List<ParseObject> listOfGroupObjects = null;

		try {
			listOfGroupObjects = queryForGroupObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(100);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();

				listOfEgsdGroupObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdGroupObjects", listOfEgsdGroupObjects);

		} catch (NullPointerException npe) {

		}

		// System.out.println( request.getParameter("locId"));
		ParseQuery<ParseObject> changeLocquery = ParseQuery.getQuery("Location");
		// changeLocquery.whereEqualTo("objectId",
		// request.getParameter("locId"));
		try {
			changeLocresults = changeLocquery.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(changeLocresults);
		List<EgsdLoctionObject> changeLoc = new ArrayList<EgsdLoctionObject>(100);

		try {
			Iterator<ParseObject> changeLocIterator = changeLocresults.listIterator();
			while (changeLocIterator.hasNext()) {
				ParseObject locchange = changeLocIterator.next();

				changeLoc.add(new EgsdLoctionObject(locchange.getObjectId(), locchange.getString("Directories"),
						locchange.getString("Name"), locchange.getString("zipcode"), locchange.getString("Address1"),
						locchange.getString("Address2"), locchange.getString("Street"), locchange.getString("Town"),
						locchange.getString("GroupSiteId"), locchange.getString("GroupName"),
						locchange.getString("Country"), null, null, locchange.getString("ParentLocationID"),
						locchange.getString("description")));

			}
		} catch (NullPointerException npe) {

		}

		// System.out.println(changeLoc);
		mav.addObject("changeLoc", changeLoc);
		mav.addObject("selectLocObj", changeLoc);

		String directoryIdForLocationId = null;

		if (request.getParameter("objectId") != null) {
			ParseQuery<ParseObject> queryForDirectoryId = ParseQuery.getQuery("DirectoryItem");
			queryForDirectoryId.whereEqualTo("objectId", request.getParameter("objectId"));
			List<ParseObject> listObjectHavingRequiredDirectoryId = null;

			try {
				listObjectHavingRequiredDirectoryId = queryForDirectoryId.find();
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Iterator<ParseObject> iteratorHavingDirectoryId = listObjectHavingRequiredDirectoryId.listIterator();

				ParseObject parseObjectHavingDirectoryId = iteratorHavingDirectoryId.next();

				directoryIdForLocationId = parseObjectHavingDirectoryId.getString("LocationId");
			} catch (NullPointerException npe) {

			}
		}

		System.out.println("Location id:" + directoryIdForLocationId);

		ParseQuery<ParseObject> query = ParseQuery.getQuery("Location");
		// in case of selecting location
		if (request.getParameter("locId") != null)
			query.whereEqualTo("objectId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			query.whereEqualTo("objectId", request.getAttribute("locId"));

		try {
			results = query.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(results);
		List<EgsdLoctionObject> hlobj = new ArrayList<EgsdLoctionObject>();
		try {
			Iterator<ParseObject> hlit = results.listIterator();
			ParseObject p = null;
			while (hlit.hasNext()) {
				p = hlit.next();
				/*
				 * System.out.println(p.getObjectId());
				 * System.out.println(p.getString("Directories"));
				 * System.out.println(p.getString("Name"));
				 * System.out.println(p.getString("zipcode"));
				 * System.out.println(p.getString("Address1"));
				 */

				String logo = "No Image To Display";
				if (p.getParseFile("Logo") != null)
					logo = p.getParseFile("Logo").getUrl();

				String qRCode = "No Image To Display";
				if (p.getParseFile("QRCode") != null)
					qRCode = p.getParseFile("QRCode").getUrl();

				String hotelLogo = "No Image To Display";
				if (p.getParseFile("HotelLogo") != null)
					hotelLogo = p.getParseFile("HotelLogo").getUrl();

				String footerImage = "No Image To Display";
				if (p.getParseFile("FooterImage") != null)
					footerImage = p.getParseFile("FooterImage").getUrl();
				EgsdLoctionObject e = new EgsdLoctionObject();

				e.setObjectId(p.getObjectId());
				e.setDirectory(p.getString("Directories"));
				e.setName(p.getString("Name"));
				e.setZipcode(p.getString("zipcode"));
				e.setAddress(p.getString("Address1"));
				e.setAddress2(p.getString("Address2"));
				e.setStreet(p.getString("Street"));
				e.setTown(p.getString("Town"));
				e.setSiteId(p.getString("siteId"));
				e.setGroupName(p.getString("GroupName"));
				e.setCountry(p.getString("Country"));
				e.setLogo(logo);
				e.setqRCode(qRCode);
				e.setParentDirectoryId(p.getString("ParentLocationID"));
				e.setDescription(p.getString("description"));

				hlobj.add(e);

				// hlobj.add(new EgsdLoctionObject(p.getObjectId(),
				// p.getString("Directories"), p.getString("Name"),
				// p.getString("zipcode"), p.getString("Address1"),
				// p.getString("Address2"), p.getString("Street"),
				// p.getString("Town"),p.getString("GroupSiteId"),p.getString("GroupName"),p.getString("Country"),
				// logo,qRCode,p.getString("ParentLocationID"),p.getString("description")));

				// hlobj.add(new
				// EgsdHotelAndLocObj(p.getString("hotel_name"),p.getString("location")));
			}
		} catch (NullPointerException npe) {

		}
		System.out.println(hlobj);

		mav.addObject("locObj", hlobj);
		mav.addObject("locObjForEdit", hlobj);
		mav.addObject("locObjForAddDirectoryItems", hlobj);
		mav.addObject("locObjForEditLocation", hlobj);
		mav.addObject("locObjForDeleteLocation", hlobj);
		mav.addObject("locObjForParentHotel", hlobj);

		// this is for directory items objects

		ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
		if (request.getParameter("locId") != null)
			queryForDirectoryItem.whereEqualTo("LocationId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			queryForDirectoryItem.whereEqualTo("LocationId", request.getAttribute("locId"));

		// queryForDirectoryItem.whereEqualTo("DirectoryID",p.getString("Directories"));
		queryForDirectoryItem.orderByAscending("Title");
		queryForDirectoryItem.limit(1000);
		List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
		try {
			directoryItemParseObjectsList = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(1000);
		System.out.println("Directory items are loaded:");
		try {
			Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
			System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->"
					+ "getTitle" + "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->"
					+ "getEmail" + "--->" + "getPhones");
			int count = 1;
			while (iterator.hasNext()) {

				EgsdDirectoryItemParseObject egsd = iterator.next();
				String img = "No Image To Display";
				if (egsd.getParseFile("Picture") != null)
					img = egsd.getParseFile("Picture").getUrl();
				// System.out.print(img);
				String styleId = null;
				ParseObject StyleIdPO = egsd.getParseObject("StyleId");
				if (egsd.getParseObject("StyleId") != null)
					styleId = StyleIdPO.getObjectId();
				// System.out.println(styleId);

				/*
				 * if(StyleIdPO.getObjectId()!=null) System.out.println(
				 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
				 */

				directoryItemObjectsList.add(new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(),
						egsd.getTitle(), egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
						egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
						egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

			}
		} catch (NullPointerException npe) {

		}

		System.out.println("before adding dir objs");
		mav.addObject("direcObjList", directoryItemObjectsList);
		mav.addObject("subDirObj", directoryItemObjectsList);
		mav.addObject("subsubDirObj", directoryItemObjectsList);
		mav.addObject("DirObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjId", directoryItemObjectsList);
		// adding DirectiryItems for editing values
		mav.addObject("showSubDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("showDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjForNavBar", directoryItemObjectsList);
		mav.addObject("subDiscriptionObjForNavBar", directoryItemObjectsList);
		// addind directory Items for Adding DirectoryItems
		mav.addObject("subDiscriptionObjForAddDirItems", directoryItemObjectsList);
		mav.addObject("showSubDiscriptionObjIdForDelete", directoryItemObjectsList);

		System.out.println("aftr adding dir objs");

		System.out.println("in select b4 Phones");

		ParseQuery<ParseObject> queryForPhones = ParseQuery.getQuery("Phones");
		queryForPhones.limit(1000);
		if (request.getParameter("locId") != null)
			queryForPhones.whereEqualTo("LocationId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			queryForPhones.whereEqualTo("LocationId", request.getAttribute("locId"));

		List<ParseObject> phonesParseObjectsList = null;
		try {
			phonesParseObjectsList = queryForPhones.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdPhonesObjects> phonesObjectsList = new ArrayList<EgsdPhonesObjects>(1000);
		System.out.println("Phone Objects  are loaded:");
		// System.out.println(phonesParseObjectsList);
		try {
			Iterator<ParseObject> phoneIterator = phonesParseObjectsList.listIterator();
			int i = 0;
			while (phoneIterator.hasNext()) {

				ParseObject egsdPhonePO = phoneIterator.next();

				// System.out.println(egsdPhonePO.getObjectId()
				// +"-->"+egsdPhonePO.getString("PhoneId")
				// +"-->"+egsdPhonePO.getString("Type")
				// +"-->"+egsdPhonePO.getString("Ext"));
				phonesObjectsList.add(new EgsdPhonesObjects(egsdPhonePO.getObjectId(), egsdPhonePO.getString("PhoneId"),
						egsdPhonePO.getString("Type"), egsdPhonePO.getString("Ext")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(phonesObjectsList);
		mav.addObject("phonesObjectsList", phonesObjectsList);
		mav.addObject("phonesObjectsListForEdit", phonesObjectsList);
		mav.addObject("phonesObjectsListForDelete", phonesObjectsList);

		ParseQuery<ParseObject> queryForMenu = ParseQuery.getQuery("Menu");
		if (request.getParameter("locId") != null)
			queryForMenu.whereEqualTo("LocationId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			queryForMenu.whereEqualTo("LocationId", request.getAttribute("locId"));
		List<ParseObject> menuParseObjectsList = null;
		try {
			menuParseObjectsList = queryForMenu.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdMenuObjects> menuObjectsList = new ArrayList<EgsdMenuObjects>(1000);
		System.out.println("Menu Items are loaded:");
		// System.out.println(menuParseObjectsList);
		try {
			Iterator<ParseObject> menuIterator = menuParseObjectsList.listIterator();
			while (menuIterator.hasNext()) {

				ParseObject egsdMenuPO = menuIterator.next();
				// System.out.println(egsdMenuPO.getObjectId() + "---> " +
				// egsdMenuPO.getString("MenuId") + "--->"
				// + egsdMenuPO.getString("Description") + "--->" +
				// egsdMenuPO.getString("Price"));
				// System.out.println(egsdMenuPO.getParseObject("StyleID"));
				// ParseObject styleIdObj=egsdMenuPO.getParseObject("StyleID");

				ParseObject ppp = egsdMenuPO.getParseObject("StyleID");
				// System.out.println("menu o.i:
				// "+egsdMenuPO.getObjectId()+"::styleId o.i:
				// "+ppp.getObjectId());

				menuObjectsList.add(new EgsdMenuObjects(egsdMenuPO.getObjectId(), egsdMenuPO.getString("MenuId"),
						egsdMenuPO.getString("Description"), egsdMenuPO.getString("Price"), ppp.getObjectId()));
			}
		} catch (NullPointerException npe) {

		}
		System.out.println(menuObjectsList.size() + " " + menuObjectsList);
		// System.out.println(menuObjectsList);
		mav.addObject("menuObjectsList", menuObjectsList);
		mav.addObject("menuObjectsListForEdit", menuObjectsList);
		mav.addObject("menuObjectsListForDelete", menuObjectsList);

		// loading StyleId objs
		ParseQuery<ParseObject> queryForStyleID = ParseQuery.getQuery("Style");
		queryForStyleID.limit(1000);
		if (request.getParameter("locId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getAttribute("locId"));

		List<ParseObject> styleIdObjParseObj = null;
		try {
			styleIdObjParseObj = queryForStyleID.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdStyleObjects> styleObjects = new ArrayList<EgsdStyleObjects>(200);
		try {
			Iterator<ParseObject> styleIterator = styleIdObjParseObj.listIterator();
			// System.out.println(styleIdObjParseObj);

			while (styleIterator.hasNext()) {
				ParseObject sp = styleIterator.next();
				/*
				 * System.out.println(sp.getObjectId()
				 * +"-->"+sp.getString("TitleFont")
				 * +"-->"+sp.getString("TitleColor")
				 * +"-->"+sp.getString("CaptionFont")
				 * +"-->"+sp.getString("CaptionColor")
				 * +"-->"+sp.getString("DescriptionFont")
				 * +"-->"+sp.getString("DescriptionColor")
				 * +"-->"+sp.getString("PhonesFont")
				 * +"-->"+sp.getString("PhonesColor")
				 * +"-->"+sp.getString("TimingsFont")
				 * +"-->"+sp.getString("TimingsColor")
				 * +"-->"+sp.getString("WebsiteFont")
				 * +"-->"+sp.getString("WebsiteColor")
				 * +"-->"+sp.getString("EmailFont")
				 * +"-->"+sp.getString("EmailColor")
				 * +"-->"+sp.getString("StyleID")
				 * +"-->"+sp.getString("PriceFont")
				 * +"-->"+sp.getString("PriceColor"));
				 */

				styleObjects.add(new EgsdStyleObjects(sp.getObjectId(), sp.getString("TitleFont"),
						sp.getString("TitleColor"), sp.getString("TitleFamily"), sp.getString("CaptionFont"),
						sp.getString("CaptionColor"), sp.getString("CaptionFamily"), sp.getString("DescriptionFont"),
						sp.getString("DescriptionColor"), sp.getString("DescriptionFamily"), sp.getString("PhonesFont"),
						sp.getString("PhonesColor"), sp.getString("PhonesFamily"), sp.getString("TimingsFont"),
						sp.getString("TimingsColor"), sp.getString("TimingsFamily"), sp.getString("WebsiteFont"),
						sp.getString("WebsiteColor"), sp.getString("WebsiteFamily"), sp.getString("EmailFont"),
						sp.getString("EmailColor"), sp.getString("EmailFamily"), sp.getString("StyleID"),
						sp.getString("PriceFont"), sp.getString("PriceColor"), sp.getString("PriceFamily")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(styleObjects);
		System.out.println("Style items are Loaded");
		mav.addObject("styleObjects", styleObjects);
		mav.addObject("styleObjectsForEdit", styleObjects);
		mav.addObject("styleObjectsForMenu", styleObjects);
		mav.addObject("styleObjectsForAddDirItems", styleObjects);
		mav.addObject("styleObjectsForDelete", styleObjects);

		System.out.println("End of Controller");

		if (request.getParameter("userName").equals("Location Admin")) {
			if (request.getParameter("locId") != null)
				locationAdminLocations(request);
			if (request.getAttribute("locId") != null) {
				List changeLocresults1 = null;
				String groupId = null;
				// list of hotel to corresponding locaiona admin

				System.out.println(request.getAttribute("locId"));
				ParseQuery<ParseObject> changeLocquery1 = ParseQuery.getQuery("Location");
				changeLocquery1.whereEqualTo("objectId", request.getAttribute("locId"));
				try {
					changeLocresults1 = changeLocquery1.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(changeLocresults1);
				List<EgsdLoctionObject> changeLoc1 = new ArrayList<EgsdLoctionObject>(50);

				try {
					Iterator<ParseObject> changeLocIterator1 = changeLocresults1.listIterator();
					while (changeLocIterator1.hasNext()) {
						ParseObject locchange1 = changeLocIterator1.next();

						System.out.println("groupId :" + locchange1.getString("GroupId"));

						groupId = locchange1.getString("GroupId");

					}
				} catch (NullPointerException npe) {

				}

				ParseQuery<ParseObject> queryForGroupLocationAdminHotels = ParseQuery.getQuery("Location");
				queryForGroupLocationAdminHotels.whereEqualTo("GroupId", groupId);

				List<ParseObject> listOfLocationsFromParse = null;

				try {
					listOfLocationsFromParse = queryForGroupLocationAdminHotels.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForLocations = listOfLocationsFromParse.listIterator();

					List<EgsdLoctionObject> listOfParseLocationObjects = new ArrayList<EgsdLoctionObject>(10);

					while (iteratorForLocations.hasNext()) {

						ParseObject p = iteratorForLocations.next();
						// p = hlit.next();
						/*
						 * System.out.println(p.getObjectId());
						 * System.out.println(p.getString("Directories"));
						 * System.out.println(p.getString("Name"));
						 * System.out.println(p.getString("zipcode"));
						 * System.out.println(p.getString("Address1"));
						 */

						String logo = "No Image To Display";
						if (p.getParseFile("Logo") != null)
							logo = p.getParseFile("Logo").getUrl();

						String qRCode = "No Image To Display";
						if (p.getParseFile("QRCode") != null)
							qRCode = p.getParseFile("QRCode").getUrl();

						String hotelLogo = "No Image To Display";
						if (p.getParseFile("HotelLogo") != null)
							hotelLogo = p.getParseFile("HotelLogo").getUrl();

						String footerImage = "No Image To Display";
						if (p.getParseFile("footerImage") != null)
							footerImage = p.getParseFile("FooterImage").getUrl();

						listOfParseLocationObjects
								.add(new EgsdLoctionObject(p.getObjectId(), p.getString("Directories"),
										p.getString("Name"), p.getString("zipcode"), p.getString("Address1"),
										p.getString("Address2"), p.getString("Street"), p.getString("Town"),
										p.getString("GroupSiteId"), p.getString("GroupName"), p.getString("Country"),
										logo, qRCode, p.getString("ParentLocationID"), p.getString("description")));

					}

					mav.addObject("adminLocObj", listOfParseLocationObjects);

					System.out.println("End of Controller");

				} catch (NullPointerException npe) {

				}
			}
		}

		System.out.println("select is redireting to getDataFromParse()");
		// EgsdController.getDataFromParse(request);
		System.out.println("getDataFromParse() is redireting to select ");

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationDetails");

		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdmin");

		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("ITAdmin");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdmin");

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		return mav;

	}

	public void locationAdminLocations(HttpServletRequest request) {

		List changeLocresults1 = null;
		String groupId = null;
		// list of hotel to corresponding locaiona admin

		System.out.println(request.getParameter("locId"));
		ParseQuery<ParseObject> changeLocquery1 = ParseQuery.getQuery("Location");
		changeLocquery1.whereEqualTo("objectId", request.getParameter("locId"));
		try {
			changeLocresults1 = changeLocquery1.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(changeLocresults1);
		List<EgsdLoctionObject> changeLoc1 = new ArrayList<EgsdLoctionObject>(50);

		try {
			Iterator<ParseObject> changeLocIterator1 = changeLocresults1.listIterator();
			while (changeLocIterator1.hasNext()) {
				ParseObject locchange1 = changeLocIterator1.next();

				System.out.println("groupId :" + locchange1.getString("GroupId"));

				groupId = locchange1.getString("GroupId");

			}
		} catch (NullPointerException npe) {

		}

		ParseQuery<ParseObject> queryForGroupLocationAdminHotels = ParseQuery.getQuery("Location");
		queryForGroupLocationAdminHotels.whereEqualTo("GroupId", groupId);

		List<ParseObject> listOfLocationsFromParse = null;

		try {
			listOfLocationsFromParse = queryForGroupLocationAdminHotels.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForLocations = listOfLocationsFromParse.listIterator();

			List<EgsdLoctionObject> listOfParseLocationObjects = new ArrayList<EgsdLoctionObject>(10);

			while (iteratorForLocations.hasNext()) {

				ParseObject p = iteratorForLocations.next();
				// p = hlit.next();
				/*
				 * System.out.println(p.getObjectId());
				 * System.out.println(p.getString("Directories"));
				 * System.out.println(p.getString("Name"));
				 * System.out.println(p.getString("zipcode"));
				 * System.out.println(p.getString("Address1"));
				 */

				String logo = "No Image To Display";
				if (p.getParseFile("Logo") != null)
					logo = p.getParseFile("Logo").getUrl();

				String qRCode = "No Image To Display";
				if (p.getParseFile("QRCode") != null)
					qRCode = p.getParseFile("QRCode").getUrl();

				String hotelLogo = "No Image To Display";
				if (p.getParseFile("HotelLogo") != null)
					hotelLogo = p.getParseFile("HotelLogo").getUrl();

				String footerImage = "No Image To Display";
				if (p.getParseFile("footerImage") != null)
					footerImage = p.getParseFile("FooterImage").getUrl();

				listOfParseLocationObjects.add(new EgsdLoctionObject(p.getObjectId(), p.getString("Directories"),
						p.getString("Name"), p.getString("zipcode"), p.getString("Address1"), p.getString("Address2"),
						p.getString("Street"), p.getString("Town"), p.getString("GroupSiteId"),
						p.getString("GroupName"), p.getString("Country"), logo, qRCode, p.getString("ParentLocationID"),
						p.getString("description")));

			}

			mav.addObject("adminLocObj", listOfParseLocationObjects);

			System.out.println("End of Controller");

		} catch (NullPointerException npe) {

		}
	}

	@RequestMapping(value = "/editLocation", headers = "content-type=multipart/*", method = RequestMethod.POST)
	public ModelAndView editLocation(MultipartHttpServletRequest request) {

		System.out.println("Entered into Edit Location");

		System.out.println("objectId:" + request.getParameter("locId"));
		System.out.println("directoryId:" + request.getParameter("directory"));
		System.out.println("Name:" + request.getParameter("name"));
		System.out.println("Address1:" + request.getParameter("address"));
		System.out.println("Address2:" + request.getParameter("address2"));
		System.out.println("street:" + request.getParameter("street"));
		System.out.println("town:" + request.getParameter("town"));
		System.out.println("zipcode:" + request.getParameter("zipcode"));
		System.out.println("description:" + request.getParameter("descriptionhtml"));
		System.out.println("description:" + request.getParameter(""));
		System.out.println("user:" + request.getParameter("user"));
		System.out.println("country:" + request.getParameter("country"));
		System.out.println("siteid:" + request.getParameter("siteId"));
		System.out.println("logo:" + request.getFile("logo"));
		System.out.println("hotelLogo:" + request.getFile("hotelLogo"));
		System.out.println("hotelFooter:" + request.getFile("hotelFooter"));

		System.out.println("brand " + request.getParameter("brandId"));
		System.out.println("brand color " + request.getParameter("brandBGColor"));
		System.out.println("brand font " + request.getParameter("brandColor"));
		System.out.println("brand font " + request.getParameter("brandFont"));

		System.out.println("footer " + request.getParameter("footerid"));
		System.out.println("footer color " + request.getParameter("footerbgColor"));
		System.out.println("footer font " + request.getParameter("footerColor"));
		System.out.println("footer font " + request.getParameter("footerFont"));

		System.out.println("address " + request.getParameter("addressId"));
		System.out.println("address color " + request.getParameter("addressbgColor"));
		System.out.println("address font " + request.getParameter("addressColor"));
		System.out.println("address font " + request.getParameter("addressFont"));

		System.out.println("style id " + request.getParameter("styleId"));

		System.out.println("admin:" + request.getParameter("admin"));
		ParseQuery<ParseObject> sty = ParseQuery.getQuery("Location");
		sty.whereEqualTo("objectId", request.getParameter("locId"));
		List<ParseObject> styList = null;
		String style = "";
		try {
			styList = sty.find();
		} catch (Exception e) {
		e.printStackTrace();
		}
		Iterator<ParseObject> stt = styList.listIterator();
		while (stt.hasNext()) {
			ParseObject sssst = stt.next();
			ParseObject StyleIdPO = sssst.getParseObject("StyleId");
			try{
			style = StyleIdPO.getObjectId();
			}
			catch(Exception e){
				ParseObject postyle= new ParseObject("Style");
				
				 if(request.getParameter("brandBGColor")!=null&&request.getParameter("brandBGColor")!="3623DB"){
					 postyle.put("LocationBackground", request.getParameter("brandBGColor"));
					 }
					 if(request.getParameter("brandFont")!=null){
					 postyle.put("LocationTextFont", request.getParameter("brandFont"));
					 }
					 if(request.getParameter("footerbgColor")!=null&&request.getParameter("footerbgColor")!="3623DB"){
					 postyle.put("LocationFooterBackground", request.getParameter("footerbgColor"));
					 }
					 if(request.getParameter("addressFont")!=null){
					 postyle.put("LocationAddressFont", request.getParameter("addressFont"));
					 }
					 if(request.getParameter("addressColor")!=null&&request.getParameter("addressColor")!="3623DB"){
					 postyle.put("LocationAddressFontColor", request.getParameter("addressColor"));
					 }	
					 try{
						 postyle.save();						 
					 }
					 catch(Exception ee){
						 ee.printStackTrace();
					 }
					 style=postyle.getObjectId();
				
			}
			
			}
		System.out.println("style id is " + style);

		 ParseObject styleClass = ParseObject.createWithoutData("Style",style);
		 if(request.getParameter("brandBGColor")!=null){
		 styleClass.put("LocationBackground", request.getParameter("brandBGColor"));
		 }
		 if(request.getParameter("brandFont")!=null){
		 styleClass.put("LocationTextFont", request.getParameter("brandFont"));
		 }
		 if(request.getParameter("footerbgColor")!=null){
		 styleClass.put("LocationFooterBackground", request.getParameter("footerbgColor"));
		 }
		 if(request.getParameter("addressFont")!=null){
		 styleClass.put("LocationAddressFont", request.getParameter("addressFont"));
		 }
		 if(request.getParameter("addressColor")!=null){
		 styleClass.put("LocationAddressFontColor", request.getParameter("addressColor"));
		 }
		 try{
			 
			 styleClass.save(); 
		 }
		 catch(Exception e){
			 
			 e.printStackTrace();
		 }

		ParseObject parseObjectForLocation = ParseObject.createWithoutData("Location", request.getParameter("locId"));
		if(style!=null&&!style.equals("")){
			parseObjectForLocation.put("StyleId", ParseObject.createWithoutData("Style",style));
			
		}
		if (request.getParameter("name") != null)
			parseObjectForLocation.put("Name", request.getParameter("name"));
		if (request.getParameter("address") != null)
			parseObjectForLocation.put("Address1", request.getParameter("address"));
		if (request.getParameter("address2") != null)
			parseObjectForLocation.put("Address2", request.getParameter("address2"));
		if (request.getParameter("street") != null)
			parseObjectForLocation.put("Street", request.getParameter("street"));
		if (request.getParameter("town") != null)
			parseObjectForLocation.put("Town", request.getParameter("town"));
		if (request.getParameter("zipcode") != null)
			parseObjectForLocation.put("zipcode", request.getParameter("zipcode"));
		if (request.getParameter("country") != null)
			parseObjectForLocation.put("Country", request.getParameter("country"));
		if (request.getParameter("siteId") != null)
			parseObjectForLocation.put("GroupSiteId", request.getParameter("siteId"));
		if (request.getParameter("description") != null)
			parseObjectForLocation.put("description", request.getParameter("description"));

		ParseFile pf = null;
		MultipartFile multiFile = request.getFile("logo");
		String imageType = multiFile.getContentType();
		// just to show that we have actually received the file
		try {
			System.out.println("File Length:" + multiFile.getBytes().length);
			System.out.println("File Type:" + multiFile.getContentType());
			String fileName = multiFile.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile.getBytes().length > 0) {
				pf = new ParseFile("logo.jpg", multiFile.getBytes());
				try {
					pf.save();
					parseObjectForLocation.put("Logo", pf);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		ParseFile pf1 = null;
		MultipartFile multiFile1 = request.getFile("hotelLogo");
		String imageType1 = multiFile.getContentType();
		// just to show that we have actually received the file
		try {
			System.out.println("File Length:" + multiFile1.getBytes().length);
			System.out.println("File Type:" + multiFile1.getContentType());
			String fileName = multiFile1.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile1.getBytes().length > 0) {
				pf1 = new ParseFile("logo.jpg", multiFile1.getBytes());
				try {
					pf1.save();
					parseObjectForLocation.put("HotelLogo", pf1);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		ParseFile pf2 = null;
		MultipartFile multiFile2 = request.getFile("hotelFooter");
		String imageType2 = multiFile2.getContentType();
		// just to show that we have actually received the file
		try {
			System.out.println("File Length:" + multiFile2.getBytes().length);
			System.out.println("File Type:" + multiFile2.getContentType());
			String fileName = multiFile2.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile2.getBytes().length > 0) {
				pf2 = new ParseFile("logo.jpg", multiFile2.getBytes());
				try {
					pf2.save();
					parseObjectForLocation.put("FooterImage", pf2);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			parseObjectForLocation.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// redirecting to home page

		System.out.println("edit location is redireting to getDataFromParse()");
		// EgsdController.getDataFromParse(request);
		// adminLoad(request);
		try {
			select(request);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("getDataFromParse() is redireting to edit location ");

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationDetails");

		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdmin");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdmin");

		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("ITAdmin");

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		return mav;

	}

	@RequestMapping(value = "/viewLocation")
	public ModelAndView redirectsToIndividualLocation(HttpServletRequest request) {

		System.out.println("user:" + request.getParameter("user"));
		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("locId:" + request.getParameter("locId"));

		viewLocation(request);

		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdminIndividualHotel");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdminIndividualHotel");

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		return mav;
	}

	public static void viewLocation(HttpServletRequest request) {

		System.out.println("In viewLoc()");
		mav.clear();

		System.out.println("user:" + request.getParameter("user"));
		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("locId:" + request.getParameter("locId"));

		List<ParseObject> results = null;
		List<ParseObject> changeLocresults = null;

		ParseQuery<ParseObject> queryForLocationAdminWasEmpty = ParseQuery.getQuery("_User");
		queryForLocationAdminWasEmpty.whereEqualTo("user", "Location Admin");
		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfEmptyAdmins = null;

		try {
			listOfEmptyAdmins = queryForLocationAdminWasEmpty.find();
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("user"), parseObjectHavingEmptyAdmins.getString("email"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));
			}

		} catch (NullPointerException npe) {

			listOfUserObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfEmptyLocationAdmins", listOfUserObjects);

		// list of Templates
		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
		queryForTemplateObjects.whereNotEqualTo("type", "group");

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list of Groups
		ParseQuery<ParseObject> queryForGroupObjects = ParseQuery.getQuery("Template");
		queryForGroupObjects.whereEqualTo("type", "group");

		List<ParseObject> listOfGroupObjects = null;

		try {
			listOfGroupObjects = queryForGroupObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();

				listOfEgsdGroupObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));
			}

			mav.addObject("listOfEgsdGroupObjects", listOfEgsdGroupObjects);

		} catch (NullPointerException npe) {

		}

		ParseQuery<ParseObject> changeLocquery = ParseQuery.getQuery("Location");
		// changeLocquery.whereEqualTo("user",
		// request.getParameter("name"));
		try {
			changeLocresults = changeLocquery.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(changeLocresults);
		List<EgsdLoctionObject> changeLoc = new ArrayList<EgsdLoctionObject>(20);

		try {
			Iterator<ParseObject> changeLocIterator = changeLocresults.listIterator();
			while (changeLocIterator.hasNext()) {
				ParseObject locchange = changeLocIterator.next();

				changeLoc.add(new EgsdLoctionObject(locchange.getObjectId(), locchange.getString("Directories"),
						locchange.getString("Name"), locchange.getString("zipcode"), locchange.getString("Address1"),
						locchange.getString("Address2"), locchange.getString("Street"), locchange.getString("Town"),
						locchange.getString("GroupSiteId"), locchange.getString("GroupName"),
						locchange.getString("Country"), null, null, locchange.getString("ParentLocationID"),
						locchange.getString("description")));

			}
		} catch (NullPointerException npe) {

		}

		// System.out.println(changeLoc);
		mav.addObject("changeLoc", changeLoc);
		mav.addObject("selectLocObj", changeLoc);

		String directoryIdForLocationId = null;

		if (request.getParameter("objectId") != null) {
			ParseQuery<ParseObject> queryForDirectoryId = ParseQuery.getQuery("DirectoryItem");
			queryForDirectoryId.whereEqualTo("objectId", request.getParameter("objectId"));
			List<ParseObject> listObjectHavingRequiredDirectoryId = null;

			try {
				listObjectHavingRequiredDirectoryId = queryForDirectoryId.find();
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			Iterator<ParseObject> iteratorHavingDirectoryId = listObjectHavingRequiredDirectoryId.listIterator();

			ParseObject parseObjectHavingDirectoryId = iteratorHavingDirectoryId.next();

			directoryIdForLocationId = parseObjectHavingDirectoryId.getString("LocationId");
		}

		System.out.println("Location id:" + directoryIdForLocationId);

		ParseQuery<ParseObject> query = ParseQuery.getQuery("Location");
		if (request.getParameter("locId") != null)
			query.whereEqualTo("objectId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			query.whereEqualTo("objectId", request.getAttribute("locId"));
		try {
			results = query.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(results);
		List<EgsdLoctionObject> hlobj = new ArrayList<EgsdLoctionObject>();
		try {
			Iterator<ParseObject> hlit = results.listIterator();
			ParseObject p = null;
			while (hlit.hasNext()) {
				p = hlit.next();
				/*
				 * System.out.println(p.getObjectId());
				 * System.out.println(p.getString("Directories"));
				 * System.out.println(p.getString("Name"));
				 * System.out.println(p.getString("zipcode"));
				 * System.out.println(p.getString("Address1"));
				 */

				String logo = "No Image To Display";
				if (p.getParseFile("Logo") != null)
					logo = p.getParseFile("Logo").getUrl();

				String qRCode = "No Image To Display";
				if (p.getParseFile("QRCode") != null)
					qRCode = p.getParseFile("QRCode").getUrl();

				String hotelLogo = "No Image To Display";
				if (p.getParseFile("HotelLogo") != null)
					hotelLogo = p.getParseFile("HotelLogo").getUrl();

				String footerImage = "No Image To Display";
				if (p.getParseFile("FooterImage") != null)
					footerImage = p.getParseFile("FooterImage").getUrl();

				EgsdLoctionObject e = new EgsdLoctionObject();

				e.setObjectId(p.getObjectId());
				e.setDirectory(p.getString("Directories"));
				e.setName(p.getString("Name"));
				e.setZipcode(p.getString("zipcode"));
				e.setAddress(p.getString("Address1"));
				e.setAddress2(p.getString("Address2"));
				e.setStreet(p.getString("Street"));
				e.setTown(p.getString("Town"));
				e.setSiteId(p.getString("siteId"));
				e.setGroupName(p.getString("GroupName"));
				e.setCountry(p.getString("Country"));
				e.setLogo(logo);
				e.setqRCode(qRCode);
				e.setParentDirectoryId(p.getString("ParentLocationID"));
				e.setDescription(p.getString("description"));

				hlobj.add(e);

				// hlobj.add(new EgsdLoctionObject(p.getObjectId(),
				// p.getString("Directories"), p.getString("Name"),
				// p.getString("zipcode"), p.getString("Address1"),
				// p.getString("Address2"), p.getString("Street"),
				// p.getString("Town"),p.getString("GroupSiteId"),p.getString("GroupName"),p.getString("Country"),logo,qRCode,p.getString("ParentLocationID"),p.getString("description")));

				// hlobj.add(new
				// EgsdHotelAndLocObj(p.getString("hotel_name"),p.getString("location")));
			}
		} catch (NullPointerException npe) {

		}
		System.out.println(hlobj);

		mav.addObject("locObj", hlobj);
		mav.addObject("locObjForEdit", hlobj);
		mav.addObject("locObjForAddDirectoryItems", hlobj);
		mav.addObject("locObjForEditLocation", hlobj);
		mav.addObject("locObjForDeleteLocation", hlobj);
		mav.addObject("locObjForParentHotel", hlobj);

		// this is for directory items objects

		ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
		if (request.getParameter("locId") != null)
			queryForDirectoryItem.whereEqualTo("LocationId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			queryForDirectoryItem.whereEqualTo("LocationId", request.getAttribute("locId"));

		// queryForDirectoryItem.whereEqualTo("DirectoryID",p.getString("Directories"));
		queryForDirectoryItem.orderByAscending("Title");
		queryForDirectoryItem.limit(1000);
		List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
		try {
			directoryItemParseObjectsList = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(300);
		System.out.println("Directory items are loaded:");
		try {
			Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
			System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->"
					+ "getTitle" + "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->"
					+ "getEmail" + "--->" + "getPhones");
			int count = 1;
			while (iterator.hasNext()) {

				EgsdDirectoryItemParseObject egsd = iterator.next();
				// System.out.println( count++ +" "+ egsd.getObjectId()
				// + "---> " + egsd.getDirectoryId()
				// + "--->" + egsd.getParentDirectoryId()
				// + "--->" + egsd.getTitle()
				// + "--->" + egsd.getCaption()
				// + "--->" + egsd.getTimings()
				// + "--->" + egsd.getWebsite()
				// + "--->" + egsd.getEmail()
				// + "--phoneId->" + egsd.getPhones()
				// + "--->" + egsd.getStyleID() +"<--StyleID ");
				String img = "No Image To Display";
				if (egsd.getParseFile("Picture") != null)
					img = egsd.getParseFile("Picture").getUrl();
				// System.out.print(img);
				String styleId = null;
				ParseObject StyleIdPO = egsd.getParseObject("StyleId");
				if (egsd.getParseObject("StyleId") != null)
					styleId = StyleIdPO.getObjectId();
				// System.out.println(styleId);

				/*
				 * if(StyleIdPO.getObjectId()!=null) System.out.println(
				 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
				 */

				directoryItemObjectsList.add(new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(),
						egsd.getTitle(), egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
						egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
						egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

			}
		} catch (NullPointerException npe) {

		}

		System.out.println("before adding dir objs");
		mav.addObject("direcObjList", directoryItemObjectsList);
		mav.addObject("subDirObj", directoryItemObjectsList);
		mav.addObject("subsubDirObj", directoryItemObjectsList);
		mav.addObject("DirObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjId", directoryItemObjectsList);
		// adding DirectiryItems for editing values
		mav.addObject("showSubDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("showDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjForNavBar", directoryItemObjectsList);
		mav.addObject("subDiscriptionObjForNavBar", directoryItemObjectsList);
		// addind directory Items for Adding DirectoryItems
		mav.addObject("subDiscriptionObjForAddDirItems", directoryItemObjectsList);
		mav.addObject("showSubDiscriptionObjIdForDelete", directoryItemObjectsList);

		System.out.println("aftr adding dir objs");

		System.out.println("in select b4 Phones");

		ParseQuery<ParseObject> queryForPhones = ParseQuery.getQuery("Phones");
		if (request.getParameter("locId") != null)
			queryForPhones.whereEqualTo("LocationId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			queryForPhones.whereEqualTo("LocationId", request.getAttribute("locId"));

		queryForPhones.limit(1000);
		List<ParseObject> phonesParseObjectsList = null;
		try {
			phonesParseObjectsList = queryForPhones.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdPhonesObjects> phonesObjectsList = new ArrayList<EgsdPhonesObjects>(200);
		System.out.println("Phone Objects  are loaded:");
		// System.out.println(phonesParseObjectsList);
		try {
			Iterator<ParseObject> phoneIterator = phonesParseObjectsList.listIterator();
			int i = 0;
			while (phoneIterator.hasNext()) {

				ParseObject egsdPhonePO = phoneIterator.next();

				// System.out.println(egsdPhonePO.getObjectId()
				// +"-->"+egsdPhonePO.getString("PhoneId")
				// +"-->"+egsdPhonePO.getString("Type")
				// +"-->"+egsdPhonePO.getString("Ext"));
				phonesObjectsList.add(new EgsdPhonesObjects(egsdPhonePO.getObjectId(), egsdPhonePO.getString("PhoneId"),
						egsdPhonePO.getString("Type"), egsdPhonePO.getString("Ext")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(phonesObjectsList);
		mav.addObject("phonesObjectsList", phonesObjectsList);
		mav.addObject("phonesObjectsListForEdit", phonesObjectsList);
		mav.addObject("phonesObjectsListForDelete", phonesObjectsList);

		ParseQuery<ParseObject> queryForMenu = ParseQuery.getQuery("Menu");
		List<ParseObject> menuParseObjectsList = null;
		try {
			menuParseObjectsList = queryForMenu.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdMenuObjects> menuObjectsList = new ArrayList<EgsdMenuObjects>(200);
		System.out.println("Menu Items are loaded:");
		// System.out.println(menuParseObjectsList);
		try {
			Iterator<ParseObject> menuIterator = menuParseObjectsList.listIterator();
			while (menuIterator.hasNext()) {

				ParseObject egsdMenuPO = menuIterator.next();
				// System.out.println(egsdMenuPO.getObjectId() + "---> " +
				// egsdMenuPO.getString("MenuId") + "--->"
				// + egsdMenuPO.getString("Description") + "--->" +
				// egsdMenuPO.getString("Price"));
				// System.out.println(egsdMenuPO.getParseObject("StyleID"));
				// ParseObject styleIdObj=egsdMenuPO.getParseObject("StyleID");

				ParseObject ppp = egsdMenuPO.getParseObject("StyleID");
				// System.out.println("menu o.i:
				// "+egsdMenuPO.getObjectId()+"::styleId o.i:
				// "+ppp.getObjectId());

				menuObjectsList.add(new EgsdMenuObjects(egsdMenuPO.getObjectId(), egsdMenuPO.getString("MenuId"),
						egsdMenuPO.getString("Description"), egsdMenuPO.getString("Price"), ppp.getObjectId()));
			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(menuObjectsList);
		mav.addObject("menuObjectsList", menuObjectsList);
		mav.addObject("menuObjectsListForEdit", menuObjectsList);
		mav.addObject("menuObjectsListForDelete", menuObjectsList);

		// loading StyleId objs
		ParseQuery<ParseObject> queryForStyleID = ParseQuery.getQuery("Style");
		if (request.getParameter("locId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getParameter("locId"));
		if (request.getAttribute("locId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getAttribute("locId"));
		queryForStyleID.limit(1000);
		List<ParseObject> styleIdObjParseObj = null;
		try {
			styleIdObjParseObj = queryForStyleID.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdStyleObjects> styleObjects = new ArrayList<EgsdStyleObjects>(200);
		try {
			Iterator<ParseObject> styleIterator = styleIdObjParseObj.listIterator();
			// System.out.println(styleIdObjParseObj);

			while (styleIterator.hasNext()) {
				ParseObject sp = styleIterator.next();
				/*
				 * System.out.println(sp.getObjectId()
				 * +"-->"+sp.getString("TitleFont")
				 * +"-->"+sp.getString("TitleColor")
				 * +"-->"+sp.getString("CaptionFont")
				 * +"-->"+sp.getString("CaptionColor")
				 * +"-->"+sp.getString("DescriptionFont")
				 * +"-->"+sp.getString("DescriptionColor")
				 * +"-->"+sp.getString("PhonesFont")
				 * +"-->"+sp.getString("PhonesColor")
				 * +"-->"+sp.getString("TimingsFont")
				 * +"-->"+sp.getString("TimingsColor")
				 * +"-->"+sp.getString("WebsiteFont")
				 * +"-->"+sp.getString("WebsiteColor")
				 * +"-->"+sp.getString("EmailFont")
				 * +"-->"+sp.getString("EmailColor")
				 * +"-->"+sp.getString("StyleID")
				 * +"-->"+sp.getString("PriceFont")
				 * +"-->"+sp.getString("PriceColor"));
				 */

				styleObjects.add(new EgsdStyleObjects(sp.getObjectId(), sp.getString("TitleFont"),
						sp.getString("TitleColor"), sp.getString("TitleFamily"), sp.getString("CaptionFont"),
						sp.getString("CaptionColor"), sp.getString("CaptionFamily"), sp.getString("DescriptionFont"),
						sp.getString("DescriptionColor"), sp.getString("DescriptionFamily"), sp.getString("PhonesFont"),
						sp.getString("PhonesColor"), sp.getString("PhonesFamily"), sp.getString("TimingsFont"),
						sp.getString("TimingsColor"), sp.getString("TimingsFamily"), sp.getString("WebsiteFont"),
						sp.getString("WebsiteColor"), sp.getString("WebsiteFamily"), sp.getString("EmailFont"),
						sp.getString("EmailColor"), sp.getString("EmailFamily"), sp.getString("StyleID"),
						sp.getString("PriceFont"), sp.getString("PriceColor"), sp.getString("PriceFamily")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(styleObjects);
		System.out.println("Style items are Loaded");
		mav.addObject("styleObjects", styleObjects);
		mav.addObject("styleObjectsForEdit", styleObjects);
		mav.addObject("styleObjectsForMenu", styleObjects);
		mav.addObject("styleObjectsForAddDirItems", styleObjects);
		mav.addObject("styleObjectsForDelete", styleObjects);

	}

	@RequestMapping(value = "/addDirectory", headers = "content-type=multipart/*", method = RequestMethod.POST)
	public ModelAndView addDirectory(MultipartHttpServletRequest request) {

		System.out.println(request.getParameter("objectId"));

		System.out.println("Entered into Add Directories");

		System.out.println("objectId:" + request.getParameter("objectIdOfLocation"));
		System.out.println("directoryId:" + request.getParameter("directoryId"));
		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("styleId:" + request.getParameter("styleId"));
		System.out.println("phones:" + request.getParameter("phones"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Title");
		System.out.println("title:" + request.getParameter("title"));
		System.out.println("titleColor:" + request.getParameter("titleColor"));
		System.out.println("titleFont:" + request.getParameter("titleFont"));
		System.out.println("---------------------------------------------");
		System.out.println("Displaying Caption");
		System.out.println("caption:" + request.getParameter("caption"));
		System.out.println("captionColor:" + request.getParameter("captionColor"));
		System.out.println("captionFont:" + request.getParameter("captionFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Timings");
		System.out.println("timings:" + request.getParameter("timings"));
		System.out.println("timingsColor:" + request.getParameter("timingsColor"));
		System.out.println("timingsFont:" + request.getParameter("timingsFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Website");
		System.out.println("website:" + request.getParameter("website"));
		System.out.println("websiteColor:" + request.getParameter("websiteColor"));
		System.out.println("websiteFont:" + request.getParameter("websiteFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Email");
		System.out.println("email:" + request.getParameter("email"));
		System.out.println("emailColor:" + request.getParameter("emailColor"));
		System.out.println("emailFont:" + request.getParameter("emailFont"));
		System.out.println("---------------------------------------------");

		System.out.println("description:" + request.getParameter("description"));
		System.out.println("descriptionFont:" + request.getParameter("descriptionFont"));
		System.out.println("descriptionColor:" + request.getParameter("descriptionColor"));
		System.out.println("---------------------------------------------");

		System.out.println("phonesFont:" + request.getParameter("phonesFont"));
		System.out.println("phonesColor:" + request.getParameter("phonesColor"));
		System.out.println("phonesType:" + request.getParameter("type"));
		System.out.println("phonesext:" + request.getParameter("ext"));

		System.out.println("---------------------------------------------");
		System.out.println("priceFont:" + request.getParameter("customizeNumber"));
		System.out.println("priceFont:" + request.getParameter("priceFont"));
		System.out.println("priceColor:" + request.getParameter("priceColor"));
		System.out.println("---------------------------------------------");

		// Adding Style object
		ParseObject styleObject = new ParseObject("Style");
		if (request.getParameter("titleFont") != null)
			styleObject.put("TitleFont", request.getParameter("titleFont"));

		if (request.getParameter("titleColor") != null)
			styleObject.put("TitleColor", request.getParameter("titleColor"));

		if (request.getParameter("titleFamily") != null)
			styleObject.put("TitleFamily", request.getParameter("titleFamily"));

		if (request.getParameter("captionFont") != null)
			styleObject.put("CaptionFont", request.getParameter("captionFont"));

		if (request.getParameter("captionFamily") != null)
			styleObject.put("CaptionFamily", request.getParameter("captionFamily"));

		if (request.getParameter("captionColor") != null)
			styleObject.put("CaptionColor", request.getParameter("captionColor"));

		if (request.getParameter("descriptionFont") != null)
			styleObject.put("DescriptionFont", request.getParameter("descriptionFont"));

		if (request.getParameter("descriptionColor") != null)
			styleObject.put("DescriptionColor", request.getParameter("descriptionColor"));

		if (request.getParameter("descriptionFamily") != null)
			styleObject.put("DescriptionFamily", request.getParameter("descriptionFamily"));

		if (request.getParameter("phonesFont") != null)
			styleObject.put("PhonesFont", request.getParameter("phonesFont"));

		if (request.getParameter("phonesColor") != null)
			styleObject.put("PhonesColor", request.getParameter("phonesColor"));

		if (request.getParameter("phonesFamily") != null)
			styleObject.put("PhonesFamily", request.getParameter("phonesFamily"));

		if (request.getParameter("timingsFont") != null)
			styleObject.put("TimingsFont", request.getParameter("timingsFont"));

		if (request.getParameter("timingsColor") != null)
			styleObject.put("TimingsColor", request.getParameter("timingsColor"));

		if (request.getParameter("timingsFamily") != null)
			styleObject.put("TimingsFamily", request.getParameter("timingsFamily"));

		if (request.getParameter("websiteFont") != null)
			styleObject.put("WebsiteFont", request.getParameter("websiteFont"));

		if (request.getParameter("websiteColor") != null)
			styleObject.put("WebsiteColor", request.getParameter("websiteColor"));

		if (request.getParameter("websiteFamily") != null)
			styleObject.put("WebsiteFamily", request.getParameter("websiteFamily"));

		if (request.getParameter("emailFont") != null)
			styleObject.put("EmailFont", request.getParameter("emailFont"));

		if (request.getParameter("emailColor") != null)
			styleObject.put("EmailColor", request.getParameter("emailColor"));

		if (request.getParameter("emailFamily") != null)
			styleObject.put("EmailFamily", request.getParameter("emailFamily"));

		styleObject.put("LocationId", request.getParameter("objectIdOfLocation"));

		// styleObject.put("PriceFont", request.getParameter("priceFont"));
		// styleObject.put("PriceColor", request.getParameter("priceColor"));
		System.out.println(styleObject);

		try {
			styleObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(styleObject.getObjectId());

		ParseObject parseObjectForDirectoryItem = new ParseObject("DirectoryItem");

		if (request.getParameter("objectIdOfLocation") != null)
			parseObjectForDirectoryItem.put("DirectoryID", request.getParameter("objectIdOfLocation"));
		parseObjectForDirectoryItem.put("ParentReferrence", request.getParameter("objectIdOfLocation"));
		if (request.getParameter("title") != null)
			parseObjectForDirectoryItem.put("Title", request.getParameter("title"));
		if (request.getParameter("caption") != null)
			parseObjectForDirectoryItem.put("Caption", request.getParameter("caption"));
		if (request.getParameter("description") != null)
			parseObjectForDirectoryItem.put("Description", request.getParameter("description"));
		if (request.getParameter("timings") != null)
			parseObjectForDirectoryItem.put("Timings", request.getParameter("timings"));
		if (request.getParameter("website") != null)
			parseObjectForDirectoryItem.put("Website", request.getParameter("website"));
		if (request.getParameter("email") != null)
			parseObjectForDirectoryItem.put("Email", request.getParameter("email"));
		if (request.getParameter("customizeNumber") != null)
			parseObjectForDirectoryItem.put("CustomizedOrder", request.getParameter("customizeNumber"));

		parseObjectForDirectoryItem.put("StyleId", styleObject);

		parseObjectForDirectoryItem.put("LocationId", request.getParameter("objectIdOfLocation"));

		ParseFile pf = null;
		MultipartFile multiFile = request.getFile("logo");
		String imageType = multiFile.getContentType();
		// just to show that we have actually received the file
		try {
			System.out.println("File Length:" + multiFile.getBytes().length);
			System.out.println("File Type:" + multiFile.getContentType());
			String fileName = multiFile.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile.getBytes().length > 0) {
				pf = new ParseFile("Picture.jpg", multiFile.getBytes());

				try {
					pf.save();
					parseObjectForDirectoryItem.put("Picture", pf);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		// parseObjectForDirectoryItem.put("Phones",parseObjectForPhones.getObjectId()
		// );

		try {
			parseObjectForDirectoryItem.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String contactCount = request.getParameter("manageCount");

		int count0 = Integer.parseInt(contactCount);
		for (int i = 0; i < count0; i++) {
			System.out.println();
			ParseObject parseObjectForPhoneItem = new ParseObject("Phones");
			if (request.getParameter("manageType" + i) != null) {
				parseObjectForPhoneItem.put("Type", request.getParameter("manageType" + i));
			}
			if (request.getParameter("manageDetails" + i) != null) {
				parseObjectForPhoneItem.put("Ext", request.getParameter("manageDetails" + i));
			}
			if ((request.getParameter("manageType" + i) != null)
					|| (request.getParameter("manageDetails" + i) != null)) {
				parseObjectForPhoneItem.put("PhoneId", parseObjectForDirectoryItem.getObjectId());
				parseObjectForPhoneItem.put("LocationId", request.getParameter("objectIdOfLocation"));
			}
			try {
				parseObjectForPhoneItem.save();
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		if (request.getParameter("priceFont") != null) {
			styleObject.put("PriceFont", request.getParameter("priceFont"));
		}
		if (request.getParameter("priceColor") != null) {
			styleObject.put("PriceColor", request.getParameter("priceColor"));
		}
		if (request.getParameter("priceFamily") != null) {
			styleObject.put("PriceFamily", request.getParameter("priceFamily"));
		}
		try {
			styleObject.save();
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		String count = request.getParameter("counter");

		int count1 = Integer.parseInt(count);
		for (int i = 1; i < count1; i++) {
			ParseObject parseObjectForMenuItem = new ParseObject("Menu");
			if (request.getParameter("menuDescription" + i) != null) {
				parseObjectForMenuItem.put("Description", request.getParameter("menuDescription" + i));
			}
			if (request.getParameter("menuPrice" + i) != null) {
				parseObjectForMenuItem.put("Price", request.getParameter("menuPrice" + i));
			}
			if ((request.getParameter("menuDescription" + i) != null)
					|| (request.getParameter("menuPrice" + i) != null)) {
				parseObjectForMenuItem.put("MenuId", parseObjectForDirectoryItem.getObjectId());
				parseObjectForMenuItem.put("LocationId", request.getParameter("objectIdOfLocation"));
				parseObjectForMenuItem.put("StyleID", styleObject);
			}
			try {
				parseObjectForMenuItem.save();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("locId", request.getParameter("objectIdOfLocation"));
		try {
			select(request);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));
		if (request.getParameter("tempId") != null) {
			System.out.println(request.getParameter("tempId"));
			ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
			queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

			List<ParseObject> listOfTemplateObjects = null;

			try {
				listOfTemplateObjects = queryForTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
				List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForTemplateObjects.next();

					listOfEgsdTemplateObjects.add(
							new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
									templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

				}

				mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

			} catch (NullPointerException npe) {

			}

			// list for selecting Templates
			ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
			// queryForSelectingTemplateObjects.whereEqualTo("objectId",
			// request.getParameter("tempId"));
			queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

			List<ParseObject> listOfSelectingTemplateObjects = null;

			try {
				listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
						.listIterator();
				List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForSelectingTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

					listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
							templateObjects.getString("Name"), null, false));

				}

				mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

			} catch (NullPointerException npe) {

			}
			if (request.getParameter("userName").equals("Super Admin"))
				mav.setViewName("SuperAdminTemplates");

			if (request.getParameter("userName").equals("IT Admin"))
				mav.setViewName("ITAdminTemplates");

			if (request.getParameter("userName").equals("CS Admin"))
				mav.setViewName("CSAdminTemplates");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		} else {
			if (request.getParameter("userName").equals("Super Admin"))
				// mav.setViewName("SuperAdminIndividualHotel");
				mav.setViewName("SuperAdmin");

			if (request.getParameter("userName").equals("IT Admin"))
				// mav.setViewName("SuperAdminIndividualHotel");
				mav.setViewName("ITAdmin");

			if (request.getParameter("userName").equals("Location Admin"))
				mav.setViewName("LocationDetails");

			if (request.getParameter("userName").equals("CS Admin"))
				// mav.setViewName("CSAdminIndividualHotel");
				mav.setViewName("CSAdmin");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}

		return mav;

	}

	@RequestMapping(value = "/deleteLocationxx")
	public ModelAndView deleteLocationxx(HttpServletRequest request) {

		System.out.println("objectIdFor delete location: " + request.getParameter("objectIdForDeleteLocation"));

		HashMap<String, String> params = new HashMap<String, String>();
		params.put("objectIdForDeleteLocation", request.getParameter("objectIdForDeleteLocation"));

		try {
			ParseCloud.callFunction("deletingLocation", params);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@RequestMapping(value = "/deleteLocation")
	public ModelAndView deleteLocation(HttpServletRequest request) {

		System.out.println("objectIdFor delete location: " + request.getParameter("objectIdForDeleteLocation"));

		ParseQuery<ParseObject> queryForLocationObject = ParseQuery.getQuery("Location");
		queryForLocationObject.whereEqualTo("objectId", request.getParameter("objectIdForDeleteLocation"));

		List<ParseObject> listForLocationObject = null;

		try {
			listForLocationObject = queryForLocationObject.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Iterator<ParseObject> iteratorForLocationOnject = listForLocationObject.listIterator();

		ParseObject locationObject = iteratorForLocationOnject.next();

		System.out.println("location object:" + locationObject.getObjectId());

		/*
		 * HashMap<String, String> param = new HashMap<String, String>();
		 * param.put("objectIdForDeleteLocation",
		 * request.getParameter("objectIdForDeleteLocation"));
		 * 
		 * try { ParseCloud.callFunction("deletingLocation", param); } catch
		 * (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

		/*
		 * //getting directoryItems
		 * 
		 * ParseQuery<ParseObject>
		 * queryForDirectoryItems=ParseQuery.getQuery("DirectoryItem");
		 * queryForDirectoryItems.whereEqualTo("LocationId",request.getParameter
		 * ("objectIdForDeleteLocation"));
		 * 
		 * List<ParseObject> listForDirectoryitems=null;
		 * 
		 * try { listForDirectoryitems=queryForDirectoryItems.find(); } catch
		 * (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 * 
		 * 
		 * try{ Iterator<ParseObject>
		 * iteratorForDirectoryItems=listForDirectoryitems.listIterator();
		 * 
		 * while(iteratorForDirectoryItems.hasNext()){
		 * 
		 * ParseObject
		 * parseObjectForDirectoryItem=iteratorForDirectoryItems.next();
		 * 
		 * System.out.println(parseObjectForDirectoryItem.getString("Title"));
		 * 
		 * deleteDirectoryObject(parseObjectForDirectoryItem.getObjectId()); }
		 * }catch(NullPointerException npe){
		 * 
		 * System.out.println("No records to be Found"); }
		 */

		HashMap<String, String> params = new HashMap<String, String>();

		// params.put("adminId", request.getParameter("adminId"));
		params.put("locationId", locationObject.getObjectId());

		String result = null;

		try {
			result = ParseCloud.callFunction("removingLocationId", params);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			result = "there is error in adding location id";
			e.printStackTrace();
		}

		System.out.println(result);

		// deleting Location object

		try {
			locationObject.delete();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		adminLoad(request);

		if (request.getParameter("userName").equals("Super Admin")) {
			mav.setViewName("SuperHotelList");
		}
		if (request.getParameter("userName").equals("IT Admin")) {
			mav.setViewName("ITHotelList");
		}
		if (request.getParameter("userName").equals("Location Admin")) {
			mav.setViewName("LocationList");
		}
		if (request.getParameter("userName").equals("CS Admin")) {
			mav.setViewName("CSHotelList");
		}

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		return mav;
	}

	@RequestMapping(value = "/deleteTemplate")
	public ModelAndView deleteTemplate(HttpServletRequest request) {

		System.out.println("objectIdFor delete location: " + request.getParameter("objectIdForDeleteLocation"));

		ParseQuery<ParseObject> queryForLocationObject = ParseQuery.getQuery("Template");
		queryForLocationObject.whereEqualTo("objectId", request.getParameter("objectIdForDeleteLocation"));

		List<ParseObject> listForLocationObject = null;

		try {
			listForLocationObject = queryForLocationObject.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Iterator<ParseObject> iteratorForLocationOnject = listForLocationObject.listIterator();

		ParseObject locationObject = iteratorForLocationOnject.next();

		System.out.println("location object:" + locationObject.getObjectId());

		/*
		 * HashMap<String, String> param = new HashMap<String, String>();
		 * param.put("objectIdForDeleteLocation",
		 * request.getParameter("objectIdForDeleteLocation"));
		 * 
		 * try { ParseCloud.callFunction("deletingLocation", param); } catch
		 * (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

		/*
		 * //getting directoryItems
		 * 
		 * ParseQuery<ParseObject>
		 * queryForDirectoryItems=ParseQuery.getQuery("DirectoryItem");
		 * queryForDirectoryItems.whereEqualTo("LocationId",request.getParameter
		 * ("objectIdForDeleteLocation"));
		 * 
		 * List<ParseObject> listForDirectoryitems=null;
		 * 
		 * try { listForDirectoryitems=queryForDirectoryItems.find(); } catch
		 * (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 * 
		 * 
		 * try{ Iterator<ParseObject>
		 * iteratorForDirectoryItems=listForDirectoryitems.listIterator();
		 * 
		 * while(iteratorForDirectoryItems.hasNext()){
		 * 
		 * ParseObject
		 * parseObjectForDirectoryItem=iteratorForDirectoryItems.next();
		 * 
		 * System.out.println(parseObjectForDirectoryItem.getString("Title"));
		 * 
		 * deleteDirectoryObject(parseObjectForDirectoryItem.getObjectId()); }
		 * }catch(NullPointerException npe){
		 * 
		 * System.out.println("No records to be Found"); }
		 */

		HashMap<String, String> params = new HashMap<String, String>();

		// params.put("adminId", request.getParameter("adminId"));
		params.put("locationId", locationObject.getObjectId());

		String result = null;

		try {
			result = ParseCloud.callFunction("removingLocationId", params);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			result = "there is error in adding location id";
			e.printStackTrace();
		}

		System.out.println(result);

		// deleting Location object

		try {
			locationObject.delete();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		adminLoad(request);

		if (request.getParameter("userName").equals("Super Admin")) {
			mav.setViewName("SuperHotelList");
		}
		if (request.getParameter("userName").equals("IT Admin")) {
			mav.setViewName("ITHotelList");
		}
		if (request.getParameter("userName").equals("Location Admin")) {
			mav.setViewName("HotelList");
		}
		if (request.getParameter("userName").equals("CS Admin")) {
			mav.setViewName("CSHotelList");
		}

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		return mav;
	}

	@RequestMapping(value = "/delete")
	public ModelAndView delete(HttpServletRequest request) {

		System.out.println("objectIdFor delete: " + request.getParameter("objectIdForDelete"));
		System.out.println("locationId delete: " + request.getParameter("locationId"));
		System.out.println("directoryId delete: " + request.getParameter("directoryId"));
		System.out.println("parent directoryId delete: " + request.getParameter("parentDirectoryId"));
		System.out.println("userName : " + request.getParameter("userName"));
		System.out.println("user :" + request.getParameter("user"));
		//// ParseObject po=ParseObject.createWithoutData("DirectoryItem",
		//// request.getParameter("objectId"));

		ParseQuery<ParseObject> queryForDiretoryItem = ParseQuery.getQuery("DirectoryItem");
		queryForDiretoryItem.whereEqualTo("objectId", request.getParameter("objectIdForDelete"));
		List<ParseObject> directoryItemListObject = null;
		try {
			directoryItemListObject = queryForDiretoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Iterator<ParseObject> iteratorDirectoryItemListObject = directoryItemListObject.listIterator();

		ParseObject object = iteratorDirectoryItemListObject.next();

		System.out.println("DirectoryId " + object.getString("DirectoryID"));
		System.out.println("Title " + object.getString("Title"));
		System.out.println("Caption " + object.getString("Caption"));
		System.out.println("Description " + object.getString("Description"));
		System.out.println("Timings " + object.getString("Timings"));
		System.out.println("Website " + object.getString("Website"));
		System.out.println("Email " + object.getString("Email"));
		System.out.println("Phones " + object.getString("Phones"));

		request.setAttribute("locationId", object.getString("LocationId"));

		checkChildRoot(request.getParameter("objectIdForDelete"));

		deleteDirectoryObject(request.getParameter("objectIdForDelete"));

		// EgsdController.getDataFromParse(request);
		// adminLoad(request);

		// viewLocation(request);

		request.setAttribute("locId", request.getParameter("locationId"));

		// EgsdController.getDataFromParse(request);
		// adminLoad(request);
		// viewLocation(request);

		try {
			select(request);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));
		if (request.getParameter("tempId") != null) {
			System.out.println(request.getParameter("tempId"));
			ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
			queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

			List<ParseObject> listOfTemplateObjects = null;

			try {
				listOfTemplateObjects = queryForTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
				List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForTemplateObjects.next();

					listOfEgsdTemplateObjects.add(
							new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
									templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

				}

				mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

			} catch (NullPointerException npe) {

			}

			// list for selecting Templates
			ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
			// queryForSelectingTemplateObjects.whereEqualTo("objectId",
			// request.getParameter("tempId"));
			queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

			List<ParseObject> listOfSelectingTemplateObjects = null;

			try {
				listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
						.listIterator();
				List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForSelectingTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

					listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
							templateObjects.getString("Name"), null, false));

				}

				mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

			} catch (NullPointerException npe) {

			}
			if (request.getParameter("userName").equals("Super Admin"))
				mav.setViewName("SuperAdminTemplates");

			if (request.getParameter("userName").equals("IT Admin"))
				mav.setViewName("ITAdminTemplates");

			if (request.getParameter("userName").equals("CS Admin"))
				mav.setViewName("CSAdminTemplates");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		} else {
			if (request.getParameter("userName").equals("Super Admin"))
				// mav.setViewName("SuperAdminIndividualHotel");
				mav.setViewName("SuperAdmin");

			if (request.getParameter("userName").equals("IT Admin"))
				// mav.setViewName("SuperAdminIndividualHotel");
				mav.setViewName("ITAdmin");

			if (request.getParameter("userName").equals("CS Admin"))
				// mav.setViewName("CSAdminIndividualHotel");
				mav.setViewName("CSAdmin");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}

		return mav;

	}

	@RequestMapping(value = "/deleteDirectory")
	public ModelAndView deleteDirectory(HttpServletRequest request) {

		System.out.println("objectIdFor delete: " + request.getParameter("objectIdForDelete"));
		System.out.println("locationId delete: " + request.getParameter("locationId"));
		System.out.println("directoryId delete: " + request.getParameter("directoryId"));
		System.out.println("parent directoryId delete: " + request.getParameter("parentDirectoryId"));
		System.out.println("userName : " + request.getParameter("userName"));
		System.out.println("user :" + request.getParameter("user"));
		//// ParseObject po=ParseObject.createWithoutData("DirectoryItem",
		//// request.getParameter("objectId"));

		ParseQuery<ParseObject> queryForDiretoryItem = ParseQuery.getQuery("DirectoryItem");
		queryForDiretoryItem.whereEqualTo("objectId", request.getParameter("objectIdForDelete"));
		List<ParseObject> directoryItemListObject = null;
		try {
			directoryItemListObject = queryForDiretoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Iterator<ParseObject> iteratorDirectoryItemListObject = directoryItemListObject.listIterator();

		ParseObject object = iteratorDirectoryItemListObject.next();

		System.out.println("DirectoryId " + object.getString("DirectoryID"));
		System.out.println("Title " + object.getString("Title"));
		System.out.println("Caption " + object.getString("Caption"));
		System.out.println("Description " + object.getString("Description"));
		System.out.println("Timings " + object.getString("Timings"));
		System.out.println("Website " + object.getString("Website"));
		System.out.println("Email " + object.getString("Email"));
		System.out.println("Phones " + object.getString("Phones"));

		request.setAttribute("locationId", object.getString("LocationId"));

		checkChildRoot(request.getParameter("objectIdForDelete"));

		deleteDirectoryObject(request.getParameter("objectIdForDelete"));

		// EgsdController.getDataFromParse(request);
		// adminLoad(request);

		// viewLocation(request);

		request.setAttribute("locId", request.getParameter("locationId"));

		try {
			select(request);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdminTemplates");

		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("SuperAdminTemplates");

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationList");

		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdminTemplates");

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		return mav;

	}

	public static void checkChildRoot(String id) {

		System.out.println("checking child roots");

		ParseQuery<ParseObject> queryForChildRoot = ParseQuery.getQuery("DirectoryItem");
		queryForChildRoot.whereEqualTo("DirectoryID", id);

		List<ParseObject> listOfChildRoots = null;

		try {
			listOfChildRoots = queryForChildRoot.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			if (!listOfChildRoots.isEmpty())
				System.out.println(listOfChildRoots.size());

			Iterator<ParseObject> iteratorForChildRoots = listOfChildRoots.listIterator();

			while (iteratorForChildRoots.hasNext()) {

				ParseObject childObject = iteratorForChildRoots.next();

				System.out.println(childObject.getString("Title"));
				checkChildRoot(childObject.getObjectId());
				deleteDirectoryObject(childObject.getObjectId());

			}

		} catch (NullPointerException npe) {

			System.out.println("no data to be display");

		} finally {

			System.out.println("end of checkChildRoot ");
		}

	}

	public static void deleteDirectoryObject(String objectId) {

		ParseQuery<ParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
		queryForDirectoryItem.whereEqualTo("objectId", objectId);

		List<ParseObject> listOfParseObjectsForDeleteDirectoryItem = null;

		try {
			listOfParseObjectsForDeleteDirectoryItem = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			if (!listOfParseObjectsForDeleteDirectoryItem.isEmpty())

				System.out.println(listOfParseObjectsForDeleteDirectoryItem.size());

			Iterator<ParseObject> iteratorForChildRoots = listOfParseObjectsForDeleteDirectoryItem.listIterator();

			while (iteratorForChildRoots.hasNext()) {

				ParseObject objectToBeDeleted = iteratorForChildRoots.next();

				// deleting phones object

				/*
				 * ParseQuery<ParseObject> parseQueryForPhones =
				 * ParseQuery.getQuery("Phones");
				 * parseQueryForPhones.whereEqualTo("PhoneId",
				 * objectToBeDeleted.getParseObject("PhoneId"));
				 * List<ParseObject> phonesParseObject = null; try {
				 * phonesParseObject = parseQueryForPhones.find(); } catch
				 * (ParseException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); }
				 * 
				 * Iterator<ParseObject> iteratorForPhones =
				 * phonesParseObject.listIterator();
				 * 
				 * ParseObject parseObjectForPhones = iteratorForPhones.next();
				 * 
				 * System.out.println("PhoneId in 'Phones':" +
				 * parseObjectForPhones.getString("PhoneId"));
				 * System.out.println("type':" +
				 * parseObjectForPhones.getString("Type"));
				 * System.out.println("ext':" +
				 * parseObjectForPhones.getString("Ext"));
				 * 
				 * try { parseObjectForPhones.delete(); } catch (ParseException
				 * e) { // TODO Auto-generated catch block e.printStackTrace();
				 * }
				 */

				// delete Menu Items
				ParseQuery<ParseObject> parseQueryForMenuItems = ParseQuery.getQuery("Menu");
				parseQueryForMenuItems.whereEqualTo("MenuId", objectToBeDeleted.getObjectId());

				List<ParseObject> listOfMenuObjects = null;

				try {
					listOfMenuObjects = parseQueryForMenuItems.find();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForMenuObjects = listOfMenuObjects.listIterator();

					while (iteratorForMenuObjects.hasNext()) {

						ParseObject menuObject = iteratorForMenuObjects.next();

						try {
							menuObject.delete();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				} catch (NullPointerException npe) {

					System.out.println("No menu Items to delete");

				}

				// deleting styles

				String style_Id = null;
				ParseObject StyleId_PO = objectToBeDeleted.getParseObject("StyleId");
				if (objectToBeDeleted.getParseObject("StyleId") != null)
					style_Id = StyleId_PO.getObjectId();
				System.out.println("StyleId of sub dir:" + style_Id);

				ParseQuery<ParseObject> parseQueryForStyles = ParseQuery.getQuery("Style");
				parseQueryForStyles.whereEqualTo("objectId", style_Id);
				List<ParseObject> styleParseObject = null;

				try {
					styleParseObject = parseQueryForStyles.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForStyleObject = styleParseObject.listIterator();

				ParseObject parseObjectForStyle = iteratorForStyleObject.next();

				System.out.println("objectId in Style: " + parseObjectForStyle.getObjectId());

				try {
					parseObjectForStyle.delete();
				} catch (ParseException e) {
					e.printStackTrace();
				}

				// deleting directory items

				try {
					objectToBeDeleted.delete();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		} catch (NullPointerException npe) {

			System.out.println("no data to be display");

		}

	}

	@RequestMapping(value = "/preview", headers = "content-type=multipart/*", method = RequestMethod.POST)
	public ModelAndView preview(MultipartHttpServletRequest request) {

		System.out.println("objectId:" + request.getParameter("objectId"));
		System.out.println("directoryId:" + request.getParameter("directoryId"));
		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("user:" + request.getParameter("user"));
		System.out.println("styleId:" + request.getParameter("styleId"));
		System.out.println("phones:" + request.getParameter("phones"));
		System.out.println("picture:" + request.getParameter("picture"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Title");
		System.out.println("title:" + request.getParameter("title"));
		System.out.println("titleColor:" + request.getParameter("titleColor"));
		System.out.println("titleFont:" + request.getParameter("titleFont"));
		System.out.println("---------------------------------------------");
		System.out.println("Displaying Caption");
		System.out.println("caption:" + request.getParameter("caption"));
		System.out.println("captionColor:" + request.getParameter("captionColor"));
		System.out.println("captionFont:" + request.getParameter("captionFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Timings");
		System.out.println("timings:" + request.getParameter("timings"));
		System.out.println("timingsColor:" + request.getParameter("timingsColor"));
		System.out.println("timingsFont:" + request.getParameter("timingsFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Website");
		System.out.println("website:" + request.getParameter("website"));
		System.out.println("websiteColor:" + request.getParameter("websiteColor"));
		System.out.println("websiteFont:" + request.getParameter("websiteFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Email");
		System.out.println("email:" + request.getParameter("email"));
		System.out.println("emailColor:" + request.getParameter("emailColor"));
		System.out.println("emailFont:" + request.getParameter("emailFont"));
		System.out.println("---------------------------------------------");

		System.out.println("description:" + request.getParameter("description"));
		System.out.println("descriptionFont:" + request.getParameter("descriptionFont"));
		System.out.println("descriptionColor:" + request.getParameter("descriptionColor"));
		System.out.println("---------------------------------------------");

		System.out.println("phonesFont:" + request.getParameter("phonesFont"));
		System.out.println("phonesColor:" + request.getParameter("phonesColor"));
		System.out.println("type:" + request.getParameter("type"));
		System.out.println("ext:" + request.getParameter("ext"));

		System.out.println("---------------------------------------------");

		System.out.println("priceFont:" + request.getParameter("priceFont"));
		System.out.println("priceColor:" + request.getParameter("priceColor"));
		System.out.println("---------------------------------------------");

		mav.addObject("objectId", request.getParameter("objectId"));
		mav.addObject("directoryId", request.getParameter("directoryId"));
		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));
		mav.addObject("styleId", request.getParameter("styleId"));
		mav.addObject("phones", request.getParameter("phones"));
		mav.addObject("picture", request.getParameter("picture"));

		mav.addObject("title", request.getParameter("title"));
		mav.addObject("titleColor", request.getParameter("titleColor"));
		mav.addObject("titleFont", request.getParameter("titleFont"));

		mav.addObject("caption", request.getParameter("caption"));
		mav.addObject("captionColor", request.getParameter("captionColor"));
		mav.addObject("captionFont", request.getParameter("captionFont"));

		mav.addObject("timings", request.getParameter("timings"));
		mav.addObject("timingsColor", request.getParameter("timingsColor"));
		mav.addObject("timingsFont", request.getParameter("timingsFont"));

		mav.addObject("website", request.getParameter("website"));
		mav.addObject("websiteColor", request.getParameter("websiteColor"));
		mav.addObject("websiteFont", request.getParameter("websiteFont"));

		mav.addObject("email", request.getParameter("email"));
		mav.addObject("emailColor", request.getParameter("emailColor"));
		mav.addObject("emailFont", request.getParameter("emailFont"));

		mav.addObject("description", request.getParameter("description"));
		mav.addObject("descriptionFont", request.getParameter("descriptionFont"));
		mav.addObject("descriptionColor", request.getParameter("descriptionColor"));

		mav.addObject("phonesFont", request.getParameter("phonesFont"));
		mav.addObject("phonesColor", request.getParameter("phonesColor"));
		mav.addObject("type", request.getParameter("type"));
		mav.addObject("ext", request.getParameter("ext"));

		mav.addObject("priceFont", request.getParameter("priceFont"));
		mav.addObject("phonesColor", request.getParameter("priceColor"));

		mav.setViewName("AdminPreview");

		return mav;

	}

	@RequestMapping(value = "/edit1", headers = "content-type=multipart/*", method = RequestMethod.POST)
	public ModelAndView edit1(MultipartHttpServletRequest request) {

		// updating menu items

		String contactCount = request.getParameter("editmenuCount");
		String menuCount = request.getParameter("editcontactCount");
		int count0 = Integer.parseInt(contactCount);
		int count1 = Integer.parseInt(menuCount);
		System.out.println("menu" + count1);
		System.out.println("contact" + count0);
		for (int i = 1; i <= count0; i++) {

			System.out.println(
					request.getParameter("editmenuDescription" + i) + " " + request.getParameter("editmenuPrice" + i));

		}
		for (int i = 0; i <= count1; i++) {
			System.out.println(
					request.getParameter("editmanageType" + i) + " " + request.getParameter("editmanageDetails" + i));
		}

		return mav;

	}

	/*
	 * @RequestMapping(value = "/edit1", headers = "content-type=multipart/*",
	 * method = RequestMethod.POST) public ModelAndView
	 * edit1(MultipartHttpServletRequest request) {
	 * 
	 * // updating menu items
	 * 
	 * 
	 * String contactCount = request.getParameter("editmenuCount"); int count0 =
	 * Integer.parseInt(contactCount); for(int i=1;i<=count0;i++) {
	 * if(request.getParameter("editmenuObject"+i) != null) { ParseObject
	 * contactObject = ParseObject.createWithoutData("Menu",
	 * request.getParameter("editmenuObject"+i));
	 * if(request.getParameter("editmenuDescription"+i) == null &&
	 * request.getParameter("editmenuPrice"+i) == null) {
	 * ParseQuery<ParseObject> parseQueryForMenu = ParseQuery.getQuery("Menu");
	 * parseQueryForMenu.whereEqualTo("objectId",
	 * request.getParameter("editmenuObject"+i)); List<ParseObject>
	 * menuParseObject = null; try { menuParseObject = parseQueryForMenu.find();
	 * } catch (ParseException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * Iterator<ParseObject> iteratorForMenu = menuParseObject.listIterator();
	 * 
	 * ParseObject parseObjectForMenu = iteratorForMenu.next();
	 * 
	 * 
	 * 
	 * try { parseObjectForMenu.delete(); } catch (ParseException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * }
	 * 
	 * 
	 * 
	 * if(request.getParameter("editmanageType"+i) != null)
	 * contactObject.put("Type", request.getParameter("editmanageType"+i));
	 * if(request.getParameter("editmanageDetails"+i) != null)
	 * contactObject.put("Ext", request.getParameter("editmanageDetails"+i));
	 * 
	 * try { contactObject.save(); } catch (ParseException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } }
	 * 
	 * }
	 * 
	 * return mav;
	 * 
	 * }
	 */

	@RequestMapping(value = "/edit", headers = "content-type=multipart/*", method = RequestMethod.POST)
	public ModelAndView edit(MultipartHttpServletRequest request) {

		System.out.println("objectId:" + request.getParameter("objectId"));
		System.out.println("directoryId:" + request.getParameter("directoryId"));
		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("styleId:" + request.getParameter("styleId"));
		System.out.println("phones:" + request.getParameter("phones"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Title");
		System.out.println("title:" + request.getParameter("title"));
		System.out.println("titleColor:" + request.getParameter("titleColor"));
		System.out.println("titleFont:" + request.getParameter("titleFont"));
		System.out.println("---------------------------------------------");
		System.out.println("Displaying Caption");
		System.out.println("caption:" + request.getParameter("caption"));
		System.out.println("captionColor:" + request.getParameter("captionColor"));
		System.out.println("captionFont:" + request.getParameter("captionFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Timings");
		System.out.println("timings:" + request.getParameter("timings"));
		System.out.println("timingsColor:" + request.getParameter("timingsColor"));
		System.out.println("timingsFont:" + request.getParameter("timingsFont"));
		System.out.println("---------------------------------------------");

		System.out.println("description:" + request.getParameter("description"));
		System.out.println("descriptionFont:" + request.getParameter("descriptionFont"));
		System.out.println("descriptionColor:" + request.getParameter("descriptionColor"));
		System.out.println("---------------------------------------------");

		System.out.println("---------------------------------------------");

		System.out.println("priceFont:" + request.getParameter("priceFont"));
		System.out.println("priceColor:" + request.getParameter("priceColor"));
		System.out.println("---------------------------------------------");

		// Updating Directory Items

		ParseObject diretoryItemObject = ParseObject.createWithoutData("DirectoryItem",
				request.getParameter("objectId"));
		if (request.getParameter("title") != null)
			diretoryItemObject.put("Title", request.getParameter("title"));
		if (request.getParameter("caption") != null)
			diretoryItemObject.put("Caption", request.getParameter("caption"));
		if (request.getParameter("description") != null)
			diretoryItemObject.put("Description", request.getParameter("description"));
		if (request.getParameter("timings") != null)
			diretoryItemObject.put("Timings", request.getParameter("timings"));
		if (request.getParameter("editCustomizeNumber") != null)
			diretoryItemObject.put("CustomizedOrder", request.getParameter("editCustomizeNumber"));

		ParseFile pf = null;

		MultipartFile multiFile = request.getFile("logo");
		String imageType = multiFile.getContentType();
		// just to show that we have actually received the file

		try {
			System.out.println("File Length:" + multiFile.getBytes().length);
			System.out.println("File Type:" + multiFile.getContentType());
			String fileName = multiFile.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile.getBytes().length > 0) {
				pf = new ParseFile("Picture.jpg", multiFile.getBytes());

				try {
					pf.save();
					diretoryItemObject.put("Picture", pf);

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		try {
			diretoryItemObject.save();
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		// diretoryItemObject.put("DirectoryID",
		// request.getParameter("directoryId"));

		// System.out.println(diretoryItemObject.getString("StyleID"));

		// Updating Style
		ParseObject styleObject = ParseObject.createWithoutData("Style", request.getParameter("styleId"));
		if (request.getParameter("titleFont") != null)
			styleObject.put("TitleFont", request.getParameter("titleFont"));

		if (request.getParameter("titleColor") != null)
			styleObject.put("TitleColor", request.getParameter("titleColor"));

		if (request.getParameter("titleFamily") != null)
			styleObject.put("TitleFamily", request.getParameter("titleFamily"));

		if (request.getParameter("captionFont") != null)
			styleObject.put("CaptionFont", request.getParameter("captionFont"));

		if (request.getParameter("captionColor") != null)
			styleObject.put("CaptionColor", request.getParameter("captionColor"));

		if (request.getParameter("captionFamily") != null)
			styleObject.put("CaptionFamily", request.getParameter("captionFamily"));

		if (request.getParameter("descriptionFont") != null)
			styleObject.put("DescriptionFont", request.getParameter("descriptionFont"));

		if (request.getParameter("descriptionColor") != null)
			styleObject.put("DescriptionColor", request.getParameter("descriptionColor"));

		if (request.getParameter("descriptionFamily") != null)
			styleObject.put("DescriptionFamily", request.getParameter("descriptionFamily"));

		if (request.getParameter("timingsFont") != null)
			styleObject.put("TimingsFont", request.getParameter("timingsFont"));

		if (request.getParameter("timingsColor") != null)
			styleObject.put("TimingsColor", request.getParameter("timingsColor"));

		if (request.getParameter("timingsFamily") != null)
			styleObject.put("TimingsFamily", request.getParameter("timingsFamily"));

		// styleObject.put("PriceFont", request.getParameter("priceFont"));
		// styleObject.put("PriceColor", request.getParameter("priceColor"));
		System.out.println(styleObject);
		try {
			styleObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// updating phone items
		String contactCount = request.getParameter("manageCount");
		int count0 = Integer.parseInt(contactCount);
		for (int i = 0; i < count0; i++) {
			if (request.getParameter("editphoneObjectId" + i) != null) {
				ParseObject contactObject = ParseObject.createWithoutData("Phones",
						request.getParameter("editphoneObjectId" + i));
				if (request.getParameter("manageType" + i) == null
						&& request.getParameter("manageDetails" + i) == null) {
					ParseQuery<ParseObject> parseQueryForPhones = ParseQuery.getQuery("Phones");
					parseQueryForPhones.whereEqualTo("objectId", request.getParameter("editphoneObjectId" + i));
					List<ParseObject> phonesParseObject = null;
					try {
						phonesParseObject = parseQueryForPhones.find();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					Iterator<ParseObject> iteratorForPhones = phonesParseObject.listIterator();

					ParseObject parseObjectForPhones = iteratorForPhones.next();

					System.out.println("PhoneId in 'Phones':" + parseObjectForPhones.getString("PhoneId"));
					System.out.println("type':" + parseObjectForPhones.getString("Type"));
					System.out.println("ext':" + parseObjectForPhones.getString("Ext"));

					try {
						parseObjectForPhones.delete();
					} catch (ParseException e) { // TODO Auto-generated catch
													// block
						e.printStackTrace();
					}

				}
				if (request.getParameter("manageType" + i) != null)
					contactObject.put("Type", request.getParameter("manageType" + i));
				if (request.getParameter("manageDetails" + i) != null)
					contactObject.put("Ext", request.getParameter("manageDetails" + i));

				try {
					contactObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				ParseObject parseObjectForPhoneItem = new ParseObject("Phones");
				if (request.getParameter("manageType" + i) != null)
					parseObjectForPhoneItem.put("Type", request.getParameter("manageType" + i));
				if (request.getParameter("manageDetails" + i) != null)
					parseObjectForPhoneItem.put("Ext", request.getParameter("manageDetails" + i));
				if (request.getParameter("manageType" + i) != null
						|| request.getParameter("manageDetails" + i) != null) {
					parseObjectForPhoneItem.put("PhoneId", diretoryItemObject.getObjectId());
					parseObjectForPhoneItem.put("LocationId", request.getParameter("locationId"));
				}

				try {
					parseObjectForPhoneItem.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

		// updating menu items
		if (request.getParameter("priceFont") != null)
			styleObject.put("PriceFont", request.getParameter("priceFont"));

		if (request.getParameter("priceColor") != null)
			styleObject.put("PriceColor", request.getParameter("priceColor"));

		if (request.getParameter("priceFamily") != null)
			styleObject.put("PriceFamily", request.getParameter("priceFamily"));
		try {
			styleObject.save();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String menuCount = request.getParameter("counter");
		int count = Integer.parseInt(menuCount);

		for (int i = 0; i < count; i++) {
			if (request.getParameter("editmenuObject" + i) != null) {
				ParseObject menuObject = ParseObject.createWithoutData("Menu",
						request.getParameter("editmenuObject" + i));
				if (request.getParameter("menuDescription" + i) == null
						&& request.getParameter("menuPrice" + i) == null) {
					ParseQuery<ParseObject> parseQueryForMenu = ParseQuery.getQuery("Menu");
					parseQueryForMenu.whereEqualTo("objectId", request.getParameter("editmenuObject" + i));
					List<ParseObject> menuParseObject = null;
					try {
						menuParseObject = parseQueryForMenu.find();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					Iterator<ParseObject> iteratorForMenu = menuParseObject.listIterator();

					ParseObject parseObjectForMenu = iteratorForMenu.next();

					try {
						parseObjectForMenu.delete();
					} catch (ParseException e) { // TODO Auto-generated catch
													// block
						e.printStackTrace();
					}

				}
				menuObject.put("LocationId", request.getParameter("locationId"));
				if (request.getParameter("menuDescription" + i) != null)
					menuObject.put("Description", request.getParameter("menuDescription" + i));
				if (request.getParameter("menuPrice" + i) != null)
					menuObject.put("Price", request.getParameter("menuPrice" + i));

				try {
					menuObject.save();
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				ParseObject parseObjectForMenuItem = new ParseObject("Menu");

				if (request.getParameter("menuDescription" + i) != null)
					parseObjectForMenuItem.put("Description", request.getParameter("menuDescription" + i));

				if (request.getParameter("menuPrice" + i) != null)
					parseObjectForMenuItem.put("Price", request.getParameter("menuPrice" + i));

				if (request.getParameter("menuDescription" + i) != null
						|| request.getParameter("menuPrice" + i) != null) {
					parseObjectForMenuItem.put("MenuId", diretoryItemObject.getObjectId());
					parseObjectForMenuItem.put("LocationId", request.getParameter("locationId"));
					parseObjectForMenuItem.put("StyleID", styleObject);
				}

				try {

					parseObjectForMenuItem.save();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("user:" + request.getParameter("user"));

		System.out.println("edit is redireting to getDataFromParse()");
		request.setAttribute("locId", request.getParameter("locationId"));

		// EgsdController.getDataFromParse(request);
		// adminLoad(request);
		// viewLocation(request);

		try {
			select(request);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));
		if (request.getParameter("tempId") != null) {
			System.out.println(request.getParameter("tempId"));
			ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
			queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

			List<ParseObject> listOfTemplateObjects = null;

			try {
				listOfTemplateObjects = queryForTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
				List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForTemplateObjects.next();

					listOfEgsdTemplateObjects.add(
							new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
									templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

				}

				mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

			} catch (NullPointerException npe) {

			}

			// list for selecting Templates
			ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
			// queryForSelectingTemplateObjects.whereEqualTo("objectId",
			// request.getParameter("tempId"));
			queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

			List<ParseObject> listOfSelectingTemplateObjects = null;

			try {
				listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
						.listIterator();
				List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForSelectingTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

					listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
							templateObjects.getString("Name"), null, false));

				}

				mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

			} catch (NullPointerException npe) {

			}
			if (request.getParameter("userName").equals("Super Admin"))
				mav.setViewName("SuperAdminTemplates");

			if (request.getParameter("userName").equals("IT Admin"))
				mav.setViewName("ITAdminTemplates");

			if (request.getParameter("userName").equals("CS Admin"))
				mav.setViewName("CSAdminTemplates");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		} else {
			if (request.getParameter("userName").equals("Super Admin"))
				// mav.setViewName("SuperAdminIndividualHotel");
				mav.setViewName("SuperAdmin");

			if (request.getParameter("userName").equals("IT Admin"))
				// mav.setViewName("SuperAdminIndividualHotel");
				mav.setViewName("ITAdmin");

			if (request.getParameter("userName").equals("CS Admin"))
				// mav.setViewName("CSAdminIndividualHotel");
				mav.setViewName("CSAdmin");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}
		return mav;

	}

	@RequestMapping(value = "/addDirectoryItems", headers = "content-type=multipart/*", method = RequestMethod.POST)
	public ModelAndView addDirectoryItems(MultipartHttpServletRequest request) {

		System.out.println("Entered into Add Directories");

		System.out.println("objectId:" + request.getParameter("objectId"));
		System.out.println("directoryId:" + request.getParameter("directoryId"));
		System.out.println("directoryId:" + request.getParameter("tempId"));
		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("styleId:" + request.getParameter("styleId"));
		System.out.println("phones:" + request.getParameter("phones"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Title");
		System.out.println("title:" + request.getParameter("title"));
		System.out.println("titleColor:" + request.getParameter("titleColor"));
		System.out.println("titleFont:" + request.getParameter("titleFont"));
		System.out.println("---------------------------------------------");
		System.out.println("Displaying Caption");
		System.out.println("caption:" + request.getParameter("caption"));
		System.out.println("captionColor:" + request.getParameter("captionColor"));
		System.out.println("captionFont:" + request.getParameter("captionFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Timings");
		System.out.println("timings:" + request.getParameter("timings"));
		System.out.println("timingsColor:" + request.getParameter("timingsColor"));
		System.out.println("timingsFont:" + request.getParameter("timingsFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Website");
		System.out.println("website:" + request.getParameter("website"));
		System.out.println("websiteColor:" + request.getParameter("websiteColor"));
		System.out.println("websiteFont:" + request.getParameter("websiteFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Email");
		System.out.println("email:" + request.getParameter("email"));
		System.out.println("emailColor:" + request.getParameter("emailColor"));
		System.out.println("emailFont:" + request.getParameter("emailFont"));
		System.out.println("---------------------------------------------");

		System.out.println("description:" + request.getParameter("description"));
		System.out.println("descriptionFont:" + request.getParameter("descriptionFont"));
		System.out.println("descriptionColor:" + request.getParameter("descriptionColor"));
		System.out.println("---------------------------------------------");

		System.out.println("phonesFont:" + request.getParameter("phonesFont"));
		System.out.println("phonesColor:" + request.getParameter("phonesColor"));
		System.out.println("phonesType:" + request.getParameter("type"));
		System.out.println("phonesext:" + request.getParameter("ext"));

		System.out.println("---------------------------------------------");

		System.out.println("priceFont:" + request.getParameter("priceFont"));
		System.out.println("priceFont:" + request.getParameter("priceFamily"));
		System.out.println("priceColor:" + request.getParameter("priceColor"));
		System.out.println("---------------------------------------------");
		System.out.println("object Id: " + request.getParameter("objectIdOfLocation"));

		if (request.getParameter("objectIdOfLocation").equals("")
				|| request.getParameter("objectIdOfLocation").equals("null")) {
			// Adding Style object
			ParseObject styleObject = new ParseObject("Style");
			if (request.getParameter("titleFont") != null)
				styleObject.put("TitleFont", request.getParameter("titleFont"));

			if (request.getParameter("titleColor") != null)
				styleObject.put("TitleColor", request.getParameter("titleColor"));

			if (request.getParameter("titleFamily") != null)
				styleObject.put("TitleFamily", request.getParameter("titleFamily"));

			if (request.getParameter("captionFont") != null)
				styleObject.put("CaptionFont", request.getParameter("captionFont"));

			if (request.getParameter("captionColor") != null)
				styleObject.put("CaptionColor", request.getParameter("captionColor"));

			if (request.getParameter("captionFamily") != null)
				styleObject.put("CaptionFamily", request.getParameter("captionFamily"));

			if (request.getParameter("descriptionFont") != null)
				styleObject.put("DescriptionFont", request.getParameter("descriptionFont"));

			if (request.getParameter("descriptionColor") != null)
				styleObject.put("DescriptionColor", request.getParameter("descriptionColor"));

			if (request.getParameter("descriptionFamily") != null)
				styleObject.put("DescriptionFamily", request.getParameter("descriptionFamily"));

			if (request.getParameter("timingsFont") != null)
				styleObject.put("TimingsFont", request.getParameter("timingsFont"));

			if (request.getParameter("timingsColor") != null)
				styleObject.put("TimingsColor", request.getParameter("timingsColor"));

			if (request.getParameter("timingsFamily") != null)
				styleObject.put("TimingsFamily", request.getParameter("timingsFamily"));

			styleObject.put("LocationId", request.getParameter("locationId"));

			// styleObject.put("PriceFont", request.getParameter("priceFont"));
			// styleObject.put("PriceColor",
			// request.getParameter("priceColor"));
			System.out.println(styleObject);
			try {
				styleObject.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println(styleObject.getObjectId());

			ParseObject parseObjectForDirectoryItem = new ParseObject("DirectoryItem");

			parseObjectForDirectoryItem.put("ParentDirectoryId", request.getParameter("objectId"));
			parseObjectForDirectoryItem.put("ParentReferrence", request.getParameter("locationId"));
			parseObjectForDirectoryItem.put("LocationId", request.getParameter("locationId"));
			parseObjectForDirectoryItem.put("DirectoryID", request.getParameter("objectId"));
			if (request.getParameter("title") != null)
				parseObjectForDirectoryItem.put("Title", request.getParameter("title"));
			if (request.getParameter("caption") != null)
				parseObjectForDirectoryItem.put("Caption", request.getParameter("caption"));
			if (request.getParameter("description") != null)
				parseObjectForDirectoryItem.put("Description", request.getParameter("description"));
			if (request.getParameter("timings") != null)
				parseObjectForDirectoryItem.put("Timings", request.getParameter("timings"));
			if (request.getParameter("website") != null)
				parseObjectForDirectoryItem.put("Website", request.getParameter("website"));
			if (request.getParameter("email") != null)
				parseObjectForDirectoryItem.put("Email", request.getParameter("email"));
			if (request.getParameter("customizeNumber") != null)
				parseObjectForDirectoryItem.put("CustomizedOrder", request.getParameter("customizeNumber"));

			ParseFile pf = null;
			MultipartFile multiFile = request.getFile("logo");
			String imageType = multiFile.getContentType();
			// just to show that we have actually received the file
			try {
				System.out.println("File Length:" + multiFile.getBytes().length);
				System.out.println("File Type:" + multiFile.getContentType());
				String fileName = multiFile.getOriginalFilename();
				System.out.println("File Name:" + fileName);
				if (multiFile.getBytes().length > 0) {
					pf = new ParseFile("Picture.jpg", multiFile.getBytes());

					try {
						pf.save();
						parseObjectForDirectoryItem.put("Picture", pf);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

			parseObjectForDirectoryItem.put("StyleId", styleObject);
			// parseObjectForDirectoryItem.put("Phones",parseObjectForPhones.getObjectId()
			// );

			try {
				parseObjectForDirectoryItem.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// Adding contact details

			String contactCount = request.getParameter("manageCount");

			int count0 = Integer.parseInt(contactCount);

			for (int i = 0; i < count0; i++) {

				System.out.println();
				ParseObject parseObjectForPhoneItem = new ParseObject("Phones");
				if (request.getParameter("manageType" + i) != null)
					parseObjectForPhoneItem.put("Type", request.getParameter("manageType" + i));
				if (request.getParameter("manageDetails" + i) != null)
					parseObjectForPhoneItem.put("Ext", request.getParameter("manageDetails" + i));
				if (request.getParameter("manageType" + i) != null
						|| request.getParameter("manageDetails" + i) != null) {
					parseObjectForPhoneItem.put("PhoneId", parseObjectForDirectoryItem.getObjectId());
					parseObjectForPhoneItem.put("LocationId", request.getParameter("locationId"));
				}

				try {
					parseObjectForPhoneItem.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

			// Adding Menu Objects

			if (request.getParameter("priceFont") != null)
				styleObject.put("PriceFont", request.getParameter("priceFont"));

			if (request.getParameter("priceColor") != null)
				styleObject.put("PriceColor", request.getParameter("priceColor"));

			if (request.getParameter("priceFamily") != null)
				styleObject.put("PriceFamily", request.getParameter("priceFamily"));
			try {
				styleObject.save();
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			String count = request.getParameter("counter");

			int count1 = Integer.parseInt(count);

			for (int i = 0; i < count1; i++) {
				ParseObject parseObjectForMenuItem = new ParseObject("Menu");

				if (request.getParameter("menuDescription" + i) != null)
					parseObjectForMenuItem.put("Description", request.getParameter("menuDescription" + i));

				if (request.getParameter("menuPrice" + i) != null)
					parseObjectForMenuItem.put("Price", request.getParameter("menuPrice" + i));

				if (request.getParameter("menuDescription" + i) != null
						|| request.getParameter("menuPrice" + i) != null) {
					parseObjectForMenuItem.put("MenuId", parseObjectForDirectoryItem.getObjectId());
					parseObjectForMenuItem.put("LocationId", request.getParameter("locationId"));
					parseObjectForMenuItem.put("StyleID", styleObject);
				}

				try {

					parseObjectForMenuItem.save();

				} catch (Exception e) {
					e.printStackTrace();
				}

			}

			// redirecting to CSAdmin with the required models

			System.out.println();

			request.setAttribute("locId", request.getParameter("locationId"));

			// EgsdController.getDataFromParse(request);
			// adminLoad(request);
			// viewLocation(request);

			System.out.println(request.getParameter("locId"));
			System.out.println(request.getAttribute("locId"));

			try {
				select(request);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
			if (request.getParameter("tempId") != null) {
				System.out.println(request.getParameter("tempId"));
				ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
				queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

				List<ParseObject> listOfTemplateObjects = null;

				try {
					listOfTemplateObjects = queryForTemplateObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {
					Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
					List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

					while (iteratorForTemplateObjects.hasNext()) {

						ParseObject templateObjects = iteratorForTemplateObjects.next();

						listOfEgsdTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
								templateObjects.getString("Name"), templateObjects.getObjectId(),
								templateObjects.getBoolean("Customized")));

					}

					mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

				} catch (NullPointerException npe) {

				}

				// list for selecting Templates
				ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
				// queryForSelectingTemplateObjects.whereEqualTo("objectId",
				// request.getParameter("tempId"));
				queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

				List<ParseObject> listOfSelectingTemplateObjects = null;

				try {
					listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {
					Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
							.listIterator();
					List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(
							20);

					while (iteratorForSelectingTemplateObjects.hasNext()) {

						ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

						listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
								templateObjects.getString("Name"), null, false));

					}

					mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

				} catch (NullPointerException npe) {

				}
				if (request.getParameter("userName").equals("Super Admin"))
					mav.setViewName("SuperAdminTemplates");

				if (request.getParameter("userName").equals("IT Admin"))
					mav.setViewName("ITAdminTemplates");

				if (request.getParameter("userName").equals("CS Admin"))
					mav.setViewName("CSAdminTemplates");

				mav.addObject("userName", request.getParameter("userName"));
				mav.addObject("user", request.getParameter("user"));
			} else {
				if (request.getParameter("userName").equals("Super Admin"))
					// mav.setViewName("SuperAdminIndividualHotel");
					mav.setViewName("SuperAdmin");

				if (request.getParameter("userName").equals("IT Admin"))
					// mav.setViewName("SuperAdminIndividualHotel");
					mav.setViewName("ITAdmin");

				if (request.getParameter("userName").equals("CS Admin"))
					// mav.setViewName("CSAdminIndividualHotel");
					mav.setViewName("CSAdmin");

				if (request.getParameter("userName").equals("Location Admin"))
					// mav.setViewName("CSAdminIndividualHotel");
					mav.setViewName("LocationDetails");

				mav.addObject("userName", request.getParameter("userName"));
				mav.addObject("user", request.getParameter("user"));
			}
		} else {
			// Adding Style object
			ParseObject styleObject = new ParseObject("Style");
			if (request.getParameter("titleFont") != null)
				styleObject.put("TitleFont", request.getParameter("titleFont"));

			if (request.getParameter("titleColor") != null)
				styleObject.put("TitleColor", request.getParameter("titleColor"));

			if (request.getParameter("titleFamily") != null)
				styleObject.put("TitleFamily", request.getParameter("titleFamily"));

			if (request.getParameter("captionFont") != null)
				styleObject.put("CaptionFont", request.getParameter("captionFont"));

			if (request.getParameter("captionFamily") != null)
				styleObject.put("CaptionFamily", request.getParameter("captionFamily"));

			if (request.getParameter("captionColor") != null)
				styleObject.put("CaptionColor", request.getParameter("captionColor"));

			if (request.getParameter("descriptionFont") != null)
				styleObject.put("DescriptionFont", request.getParameter("descriptionFont"));

			if (request.getParameter("descriptionColor") != null)
				styleObject.put("DescriptionColor", request.getParameter("descriptionColor"));

			if (request.getParameter("descriptionFamily") != null)
				styleObject.put("DescriptionFamily", request.getParameter("descriptionFamily"));

			if (request.getParameter("phonesFont") != null)
				styleObject.put("PhonesFont", request.getParameter("phonesFont"));

			if (request.getParameter("phonesColor") != null)
				styleObject.put("PhonesColor", request.getParameter("phonesColor"));

			if (request.getParameter("phonesFamily") != null)
				styleObject.put("PhonesFamily", request.getParameter("phonesFamily"));

			if (request.getParameter("timingsFont") != null)
				styleObject.put("TimingsFont", request.getParameter("timingsFont"));

			if (request.getParameter("timingsColor") != null)
				styleObject.put("TimingsColor", request.getParameter("timingsColor"));

			if (request.getParameter("timingsFamily") != null)
				styleObject.put("TimingsFamily", request.getParameter("timingsFamily"));

			if (request.getParameter("websiteFont") != null)
				styleObject.put("WebsiteFont", request.getParameter("websiteFont"));

			if (request.getParameter("websiteColor") != null)
				styleObject.put("WebsiteColor", request.getParameter("websiteColor"));

			if (request.getParameter("websiteFamily") != null)
				styleObject.put("WebsiteFamily", request.getParameter("websiteFamily"));

			if (request.getParameter("emailFont") != null)
				styleObject.put("EmailFont", request.getParameter("emailFont"));

			if (request.getParameter("emailColor") != null)
				styleObject.put("EmailColor", request.getParameter("emailColor"));

			if (request.getParameter("emailFamily") != null)
				styleObject.put("EmailFamily", request.getParameter("emailFamily"));

			styleObject.put("LocationId", request.getParameter("objectIdOfLocation"));

			// styleObject.put("PriceFont", request.getParameter("priceFont"));
			// styleObject.put("PriceColor",
			// request.getParameter("priceColor"));
			System.out.println(styleObject);

			try {
				styleObject.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println(styleObject.getObjectId());

			ParseObject parseObjectForDirectoryItem = new ParseObject("DirectoryItem");

			if (request.getParameter("objectIdOfLocation") != null)
				parseObjectForDirectoryItem.put("DirectoryID", request.getParameter("objectIdOfLocation"));
			parseObjectForDirectoryItem.put("ParentReferrence", request.getParameter("objectIdOfLocation"));
			if (request.getParameter("title") != null)
				parseObjectForDirectoryItem.put("Title", request.getParameter("title"));
			if (request.getParameter("caption") != null)
				parseObjectForDirectoryItem.put("Caption", request.getParameter("caption"));
			if (request.getParameter("description") != null)
				parseObjectForDirectoryItem.put("Description", request.getParameter("description"));
			if (request.getParameter("timings") != null)
				parseObjectForDirectoryItem.put("Timings", request.getParameter("timings"));
			if (request.getParameter("website") != null)
				parseObjectForDirectoryItem.put("Website", request.getParameter("website"));
			if (request.getParameter("email") != null)
				parseObjectForDirectoryItem.put("Email", request.getParameter("email"));
			if (request.getParameter("customizeNumber") != null)
				parseObjectForDirectoryItem.put("CustomizedOrder", request.getParameter("customizeNumber"));

			parseObjectForDirectoryItem.put("StyleId", styleObject);

			parseObjectForDirectoryItem.put("LocationId", request.getParameter("objectIdOfLocation"));

			ParseFile pf = null;
			MultipartFile multiFile = request.getFile("logo");
			String imageType = multiFile.getContentType();
			// just to show that we have actually received the file
			try {
				System.out.println("File Length:" + multiFile.getBytes().length);
				System.out.println("File Type:" + multiFile.getContentType());
				String fileName = multiFile.getOriginalFilename();
				System.out.println("File Name:" + fileName);
				if (multiFile.getBytes().length > 0) {
					pf = new ParseFile("Picture.jpg", multiFile.getBytes());

					try {
						pf.save();
						parseObjectForDirectoryItem.put("Picture", pf);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

			// parseObjectForDirectoryItem.put("Phones",parseObjectForPhones.getObjectId()
			// );

			try {
				parseObjectForDirectoryItem.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String contactCount = request.getParameter("manageCount");

			int count0 = Integer.parseInt(contactCount);
			for (int i = 0; i < count0; i++) {
				System.out.println();
				ParseObject parseObjectForPhoneItem = new ParseObject("Phones");
				if (request.getParameter("manageType" + i) != null) {
					parseObjectForPhoneItem.put("Type", request.getParameter("manageType" + i));
				}
				if (request.getParameter("manageDetails" + i) != null) {
					parseObjectForPhoneItem.put("Ext", request.getParameter("manageDetails" + i));
				}
				if ((request.getParameter("manageType" + i) != null)
						|| (request.getParameter("manageDetails" + i) != null)) {
					parseObjectForPhoneItem.put("PhoneId", parseObjectForDirectoryItem.getObjectId());
					parseObjectForPhoneItem.put("LocationId", request.getParameter("objectIdOfLocation"));
				}
				try {
					parseObjectForPhoneItem.save();
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			if (request.getParameter("priceFont") != null) {
				styleObject.put("PriceFont", request.getParameter("priceFont"));
			}
			if (request.getParameter("priceColor") != null) {
				styleObject.put("PriceColor", request.getParameter("priceColor"));
			}
			if (request.getParameter("priceFamily") != null) {
				styleObject.put("PriceFamily", request.getParameter("priceFamily"));
			}
			try {
				styleObject.save();
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			String count = request.getParameter("counter");

			int count1 = Integer.parseInt(count);
			System.out.println("count1 :"+count1);
			for (int i = 0; i < count1; i++) {
				ParseObject parseObjectForMenuItem = new ParseObject("Menu");
				if (request.getParameter("menuDescription" + i) != null) {
					parseObjectForMenuItem.put("Description", request.getParameter("menuDescription" + i));
				}
				if (request.getParameter("menuPrice" + i) != null) {
					parseObjectForMenuItem.put("Price", request.getParameter("menuPrice" + i));
				}
				if ((request.getParameter("menuDescription" + i) != null)
						|| (request.getParameter("menuPrice" + i) != null)) {
					parseObjectForMenuItem.put("MenuId", parseObjectForDirectoryItem.getObjectId());
					parseObjectForMenuItem.put("LocationId", request.getParameter("objectIdOfLocation"));
					parseObjectForMenuItem.put("StyleID", styleObject);
				}
				try {
					parseObjectForMenuItem.save();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			request.setAttribute("locId", request.getParameter("objectIdOfLocation"));
			try {
				select(request);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
			if (request.getParameter("tempId") != null) {
				System.out.println(request.getParameter("tempId"));
				ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
				queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

				List<ParseObject> listOfTemplateObjects = null;

				try {
					listOfTemplateObjects = queryForTemplateObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {
					Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
					List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

					while (iteratorForTemplateObjects.hasNext()) {

						ParseObject templateObjects = iteratorForTemplateObjects.next();

						listOfEgsdTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
								templateObjects.getString("Name"), templateObjects.getObjectId(),
								templateObjects.getBoolean("Customized")));

					}

					mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

				} catch (NullPointerException npe) {

				}

				// list for selecting Templates
				ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
				// queryForSelectingTemplateObjects.whereEqualTo("objectId",
				// request.getParameter("tempId"));
				queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

				List<ParseObject> listOfSelectingTemplateObjects = null;

				try {
					listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {
					Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
							.listIterator();
					List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(
							20);

					while (iteratorForSelectingTemplateObjects.hasNext()) {

						ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

						listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
								templateObjects.getString("Name"), null, false));

					}

					mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

				} catch (NullPointerException npe) {

				}
				if (request.getParameter("userName").equals("Super Admin"))
					mav.setViewName("SuperAdminTemplates");

				if (request.getParameter("userName").equals("IT Admin"))
					mav.setViewName("ITAdminTemplates");

				if (request.getParameter("userName").equals("CS Admin"))
					mav.setViewName("CSAdminTemplates");

				mav.addObject("userName", request.getParameter("userName"));
				mav.addObject("user", request.getParameter("user"));
			} else {
				if (request.getParameter("userName").equals("Super Admin"))
					// mav.setViewName("SuperAdminIndividualHotel");
					mav.setViewName("SuperAdmin");

				if (request.getParameter("userName").equals("IT Admin"))
					// mav.setViewName("SuperAdminIndividualHotel");
					mav.setViewName("ITAdmin");

				if (request.getParameter("userName").equals("Location Admin"))
					mav.setViewName("LocationDetails");

				if (request.getParameter("userName").equals("CS Admin"))
					// mav.setViewName("CSAdminIndividualHotel");
					mav.setViewName("CSAdmin");

				mav.addObject("userName", request.getParameter("userName"));
				mav.addObject("user", request.getParameter("user"));
			}
		}

		return mav;

	}

	/*
	 * @RequestMapping(value = "/registerCSAdminForm") public ModelAndView
	 * registerCSAdminForm(HttpServletRequest request) {
	 * 
	 * 
	 * System.out.println(request.getParameter("user"));
	 * System.out.println(request.getParameter("userName"));
	 * 
	 * 
	 * mav.setViewName("RegisterCSAdminForm");
	 * mav.addObject("user",request.getParameter("user") );
	 * mav.addObject("userName",request.getParameter("userName") );
	 * 
	 * return mav; }
	 */

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/searchHotels", method = RequestMethod.POST)
	public @ResponseBody List searchHotel(HttpServletRequest request) {

		System.out.println(request.getParameter("searchId"));
		System.out.println(request.getParameter("username"));
		String pattern = "^.*" + request.getParameter("searchId") + ".*$";
		String searchId = request.getParameter("searchId");
		System.out.println("searchId is " + searchId);
		ParseQuery<ParseObject> queryForSearchName = ParseQuery.getQuery("Location");
		List<ParseObject> listOfSearchNames = null;
		List<EgsdHotelObjects> listOfEgsdHotelObjects = null;
		String userObjectId = null;
		listOfEgsdHotelObjects = new ArrayList<EgsdHotelObjects>(100);
		List<EgsdHotelObjects> listOfEgsdHotelObjects2 = new ArrayList<EgsdHotelObjects>(100);
		List<EgsdHotelObjects> listOfEgsdHotelObjects3 = new ArrayList<EgsdHotelObjects>(100);
		List<EgsdHotelObjects> listOfEgsdHotelObjects4 = new ArrayList<EgsdHotelObjects>(100);
		List<EgsdHotelObjects> listOfEgsdHotelObjects5 = new ArrayList<EgsdHotelObjects>(100);
		List<EgsdHotelObjects> listOfEgsdHotelObjects6 = new ArrayList<EgsdHotelObjects>(100);
		List<EgsdHotelObjects> listOfEgsdHotelObjectsMain = new ArrayList<EgsdHotelObjects>(100);
		HashSet<EgsdHotelObjects> set = new HashSet<EgsdHotelObjects>();
		if (!request.getParameter("username").equals("null") || request.getParameter("username") == "") {

			ParseQuery<ParseObject> queryForLocationAdmin = ParseQuery.getQuery("_User");
			queryForLocationAdmin.whereEqualTo("username", request.getParameter("username"));

			List<ParseObject> listOfEmptyAdmins = null;

			try {

				listOfEmptyAdmins = queryForLocationAdmin.find();
				try {
					Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

					while (iteratorForEmptyAdmins.hasNext()) {

						ParseObject parseObjectAdmins = iteratorForEmptyAdmins.next();
						System.out.println(parseObjectAdmins.getObjectId());
						userObjectId = parseObjectAdmins.getObjectId();
						System.out.println("userObjectId is " + userObjectId);
					}

					queryForSearchName.whereMatches("GroupSiteId", pattern, "i");
					queryForSearchName.whereEqualTo("GroupId", userObjectId);

					List<ParseObject> listOfLocationsFromParse = null;

					try {
						listOfSearchNames = queryForSearchName.find();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} catch (Exception npe) {
					System.out.println(npe);
				}

				try {
					Iterator<ParseObject> iteratorForSearchObjects = listOfSearchNames.listIterator();

					while (iteratorForSearchObjects.hasNext()) {

						ParseObject hotelObjects = iteratorForSearchObjects.next();

						listOfEgsdHotelObjects.add(new EgsdHotelObjects(hotelObjects.getString("Name"),
								hotelObjects.getObjectId(), hotelObjects.getString("GroupSiteId"),
								hotelObjects.getString("zipcode"), hotelObjects.getString("GroupName")));

					}

				} catch (NullPointerException npe) {
					listOfEgsdHotelObjects.clear();

				}
			} catch (ParseException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			return listOfEgsdHotelObjects;
		} else

		{

			queryForSearchName.whereEqualTo("GroupSiteId", request.getParameter("searchId"));

			queryForSearchName.addAscendingOrder("Name");

			try {
				listOfSearchNames = queryForSearchName.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchNames.listIterator();

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects.add(new EgsdHotelObjects(hotelObjects.getString("Name"),
						hotelObjects.getObjectId(), hotelObjects.getString("GroupSiteId"),
						hotelObjects.getString("zipcode"), hotelObjects.getString("GroupName")));

			}

		} catch (NullPointerException npe) {
			listOfEgsdHotelObjects.clear();

		}

		finally {

			listOfEgsdHotelObjects2 = searchingNames(pattern);
			listOfEgsdHotelObjects3 = searchingObjects(searchId);
			listOfEgsdHotelObjects4 = searchingZipcode(searchId);
			listOfEgsdHotelObjects6 = searchingGroupname(pattern);
			listOfEgsdHotelObjects5.clear();
			System.out.println("listOfEgsdHotelObjects size is " + listOfEgsdHotelObjects.size());
			System.out.println("listOfEgsdHotelObjects2 size is " + listOfEgsdHotelObjects2.size());
			System.out.println("listOfEgsdHotelObjects3 size is " + listOfEgsdHotelObjects3.size());
			System.out.println("listOfEgsdHotelObjects4 size is " + listOfEgsdHotelObjects4.size());
			System.out.println("listOfEgsdHotelObjects6 size is " + listOfEgsdHotelObjects6.size());

			if (listOfEgsdHotelObjects.size() != 0) {
				listOfEgsdHotelObjects5.addAll(listOfEgsdHotelObjects);
			}
			if (listOfEgsdHotelObjects2.size() != 0) {
				listOfEgsdHotelObjects5.addAll(listOfEgsdHotelObjects2);
			}
			if (listOfEgsdHotelObjects3.size() != 0) {
				listOfEgsdHotelObjects5.addAll(listOfEgsdHotelObjects3);
			}

			if (listOfEgsdHotelObjects4.size() != 0) {
				listOfEgsdHotelObjects5.addAll(listOfEgsdHotelObjects4);
			}
			if (listOfEgsdHotelObjects6.size() != 0) {
				listOfEgsdHotelObjects5.addAll(listOfEgsdHotelObjects6);
			}
			System.out.println("listOfEgsdHotelObjects5 size is " + listOfEgsdHotelObjects5.size());
			for (int i = 0; i < listOfEgsdHotelObjects5.size() - 1; i++) {
				for (int j = 1 + i; j < listOfEgsdHotelObjects5.size(); j++) {
					System.out.println("in i for loop " + listOfEgsdHotelObjects5.get(i).getName().toString());
					System.out.println("in j for loop " + listOfEgsdHotelObjects5.get(j).getName().toString());
					System.out.println("listOfEgsdHotelObjects5 size is " + listOfEgsdHotelObjects5.size());
					if (listOfEgsdHotelObjects5.get(i).getName().toString()
							.equals(listOfEgsdHotelObjects5.get(j).getName().toString())) {
						listOfEgsdHotelObjects5.remove(j);
						j--;
					}
				}
			}
			Collections.sort(listOfEgsdHotelObjects5, new GenericComparator("name", true));
		}

		System.out.println(listOfEgsdHotelObjects5.size());

		return listOfEgsdHotelObjects5;
	}

	public List searchingNames(String pattern) {
		ParseQuery<ParseObject> queryForSearchObjectId = ParseQuery.getQuery("Location");

		System.out.println("pattern is " + pattern);
		queryForSearchObjectId.whereMatches("Name", pattern, "i");
		queryForSearchObjectId.addAscendingOrder("Name");

		List<ParseObject> listOfSearchObjectId = null;
		List<EgsdHotelObjects> listOfEgsdHotelObjects = new ArrayList<EgsdHotelObjects>(100);

		try {
			listOfSearchObjectId = queryForSearchObjectId.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchObjectId.listIterator();

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects.add(new EgsdHotelObjects(hotelObjects.getString("Name"),
						hotelObjects.getObjectId(), hotelObjects.getString("GroupSiteId"),
						hotelObjects.getString("zipcode"), hotelObjects.getString("GroupName")));

			}

		} catch (NullPointerException npe) {
			listOfEgsdHotelObjects.clear();
			return listOfEgsdHotelObjects;

		}

		return listOfEgsdHotelObjects;

	}

	public List searchingGroupname(String pattern) {
		ParseQuery<ParseObject> queryForSearchObjectId = ParseQuery.getQuery("Location");

		System.out.println("pattern is " + pattern);
		queryForSearchObjectId.whereMatches("GroupName", pattern, "i");
		queryForSearchObjectId.addAscendingOrder("Name");

		List<ParseObject> listOfSearchObjectId = null;
		List<EgsdHotelObjects> listOfEgsdHotelObjects = new ArrayList<EgsdHotelObjects>(100);

		try {
			listOfSearchObjectId = queryForSearchObjectId.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchObjectId.listIterator();

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects.add(new EgsdHotelObjects(hotelObjects.getString("Name"),
						hotelObjects.getObjectId(), hotelObjects.getString("GroupSiteId"),
						hotelObjects.getString("zipcode"), hotelObjects.getString("GroupName")));

			}

		} catch (NullPointerException npe) {
			listOfEgsdHotelObjects.clear();
			return listOfEgsdHotelObjects;

		}

		return listOfEgsdHotelObjects;

	}

	public List searchingObjects(String searchId) {
		ParseQuery<ParseObject> queryForSearchObjectId = ParseQuery.getQuery("Location");
		System.out.println("searchId is " + searchId);
		queryForSearchObjectId.addAscendingOrder("Name");
		// queryForSearchObjectId.whereMatches("GroupSiteId",pattern,"i");
		queryForSearchObjectId.whereEqualTo("objectId", searchId);

		List<ParseObject> listOfSearchObjectId = null;
		List<EgsdHotelObjects> listOfEgsdHotelObjects = new ArrayList<EgsdHotelObjects>(100);

		try {
			listOfSearchObjectId = queryForSearchObjectId.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchObjectId.listIterator();

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects.add(new EgsdHotelObjects(hotelObjects.getString("Name"),
						hotelObjects.getObjectId(), hotelObjects.getString("GroupSiteId"),
						hotelObjects.getString("zipcode"), hotelObjects.getString("GroupName")));

			}

		} catch (NullPointerException npe) {
			listOfEgsdHotelObjects.clear();
			return listOfEgsdHotelObjects;
		}

		return listOfEgsdHotelObjects;
	}

	public List searchingZipcode(String searchId) {
		ParseQuery<ParseObject> queryForSearchObjectId = ParseQuery.getQuery("Location");

		queryForSearchObjectId.addAscendingOrder("Name");
		queryForSearchObjectId.whereEqualTo("zipcode", searchId);

		List<ParseObject> listOfSearchObjectId = null;
		List<EgsdHotelObjects> listOfEgsdHotelObjects = new ArrayList<EgsdHotelObjects>(100);

		try {
			listOfSearchObjectId = queryForSearchObjectId.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchObjectId.listIterator();

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects.add(new EgsdHotelObjects(hotelObjects.getString("Name"),
						hotelObjects.getObjectId(), hotelObjects.getString("GroupSiteId"),
						hotelObjects.getString("zipcode"), hotelObjects.getString("GroupName")));

			}

		} catch (NullPointerException npe) {
			listOfEgsdHotelObjects.clear();
			return listOfEgsdHotelObjects;

		}

		return listOfEgsdHotelObjects;

	}

	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
	public @ResponseBody String deleteUser(HttpServletRequest request) {

		String userId = request.getParameter("searchId");
		String status = "";
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("objectId", userId);
		String result = "";
		try {
			result = ParseCloud.callFunction("deleteAdminInformation", params);
			status = "deleted";
			System.out.println("admin update :" + result);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			status = "notdeleted";
			e.printStackTrace();

		}

		return status;

	}

	@RequestMapping(value = "/searchUsers", method = RequestMethod.POST)
	public @ResponseBody List searchUsers(HttpServletRequest request) {

		String userName = request.getParameter("userName");
		System.out.println(userName);
		String admin = "^.*" + request.getParameter("searchId") + ".*$";
		ParseQuery<ParseObject> queryForAdmin = ParseQuery.getQuery("_User");
		queryForAdmin.orderByAscending("username");
		queryForAdmin.whereMatches("email", admin, "i");
		queryForAdmin.whereEqualTo("Status", true);
		List<ParseObject> listOfAdmins = null;

		try {

			listOfAdmins = queryForAdmin.find();

		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);
		List<EgsdUserObjects> listOfUserObjects2 = new ArrayList<EgsdUserObjects>(100);
		List<EgsdUserObjects> listOfUserObjects3 = new ArrayList<EgsdUserObjects>(100);
		List<EgsdUserObjects> listOfUserObjects4 = new ArrayList<EgsdUserObjects>(100);
		List<EgsdUserObjects> listOfUserObjects5 = new ArrayList<EgsdUserObjects>(100);
		List<EgsdUserObjects> listOfUserObjects6 = new ArrayList<EgsdUserObjects>(100);
		List<EgsdUserObjects> listOfUserObjects7 = new ArrayList<EgsdUserObjects>(100);
		Set<EgsdUserObjects> set = new HashSet<EgsdUserObjects>();
		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));

			}

		} catch (NullPointerException npe) {

			listOfUserObjects.clear();

		} finally {

			listOfUserObjects2 = searchingFirstName(admin);
			listOfUserObjects3 = searchingLastName(admin);
			listOfUserObjects4.clear();
			System.out.println("listOfUserObjects size is " + listOfUserObjects.size());
			System.out.println("listOfUserObjects2 size is " + listOfUserObjects2.size());
			System.out.println("listOfUserObjects3 size is " + listOfUserObjects3.size());
			if (listOfUserObjects.size() != 0) {
				listOfUserObjects4.addAll(listOfUserObjects);
			}
			if (listOfUserObjects2.size() != 0) {
				listOfUserObjects4.addAll(listOfUserObjects2);
			}
			if (listOfUserObjects3.size() != 0) {
				listOfUserObjects4.addAll(listOfUserObjects3);
			}
			System.out.println(listOfUserObjects4.size());
			for (int i = 0; i < listOfUserObjects4.size() - 1; i++) {
				for (int j = 1 + i; j < listOfUserObjects4.size(); j++) {
					// System.out.println("in i loop
					// "+i+""+listOfUserObjects4.get(i).getUsername().toString());
					// System.out.println(listOfUserObjects4.get(i).getFirstname().toString().equals(listOfUserObjects4.get(j).getFirstname().toString()));
					// System.out.println("in i loop
					// "+i+""+listOfUserObjects4.get(i).getUsername().toString());
					if (listOfUserObjects4.get(i).getUsername().toString()
							.equals(listOfUserObjects4.get(j).getUsername().toString())
							&& (listOfUserObjects4.get(i).getObjectId().toString()
									.equals(listOfUserObjects4.get(j).getObjectId().toString()))) {
						System.out.println("in i loop " + i + "" + listOfUserObjects4.get(i).getUsername().toString());
						System.out.println("in i loop " + j + "" + listOfUserObjects4.get(j).getUsername().toString());
						System.out.println("removed " + listOfUserObjects4.get(j).getUsername());
						listOfUserObjects4.remove(j);
						System.out.println(listOfUserObjects4.size());

					}
				}
			}
			System.out.println(listOfUserObjects4.size());
			set.addAll(listOfUserObjects4);
			listOfUserObjects4.clear();
			listOfUserObjects4.addAll(set);
			System.out.println(listOfUserObjects4.size());

			Iterator<EgsdUserObjects> iterator = listOfUserObjects4.iterator();
			while (iterator.hasNext()) {
				EgsdUserObjects egsdUserObjects = iterator.next();
				egsdUserObjects.setUsername(egsdUserObjects.getUsername().toString().toLowerCase());
				egsdUserObjects.setFirstname(egsdUserObjects.getFirstname().toString().toLowerCase());
				egsdUserObjects.setLastname(egsdUserObjects.getLastname().toString().toLowerCase());
				egsdUserObjects.setUser(egsdUserObjects.getUser().toString().toLowerCase());
				egsdUserObjects.setEmail(egsdUserObjects.getEmail().toString().toLowerCase());
				egsdUserObjects.setObjectId(egsdUserObjects.getObjectId().toString());
				listOfUserObjects5.add(egsdUserObjects);
			}

			listOfUserObjects6.clear();
			if (userName.equals("IT Admin")) {

				for (int k = 0; k < listOfUserObjects5.size(); k++) {
					if (listOfUserObjects5.get(k).getUser().toString().equals("it admin")) {
						listOfUserObjects6.add(listOfUserObjects5.get(k));
					}
				}
				for (int k = 0; k < listOfUserObjects5.size(); k++) {
					if (listOfUserObjects5.get(k).getUser().toString().equals("super admin")) {
						listOfUserObjects6.add(listOfUserObjects5.get(k));
					}
				}

				for (int k = 0; k < listOfUserObjects5.size(); k++) {
					if (listOfUserObjects5.get(k).getUser().toString().equals("cs admin")) {
						listOfUserObjects6.add(listOfUserObjects5.get(k));
					}
				}
				for (int k = 0; k < listOfUserObjects5.size(); k++) {
					if (listOfUserObjects5.get(k).getUser().toString().equals("location admin")) {
						listOfUserObjects6.add(listOfUserObjects5.get(k));
					}
				}
			}
			System.out.println("userName is " + userName);
			if (userName.equals("Super Admin")) {

				for (int k = 0; k < listOfUserObjects5.size(); k++) {
					if (listOfUserObjects5.get(k).getUser().toString().equals("cs admin")) {
						listOfUserObjects6.add(listOfUserObjects5.get(k));
					}
				}
				for (int k = 0; k < listOfUserObjects5.size(); k++) {
					if (listOfUserObjects5.get(k).getUser().toString().equals("location admin")) {
						listOfUserObjects6.add(listOfUserObjects5.get(k));
					}
				}
			}
			if (userName.equals("CS Admin")) {
				for (int k = 0; k < listOfUserObjects5.size(); k++) {
					if (listOfUserObjects5.get(k).getUser().toString().equals("location admin")) {
						listOfUserObjects6.add(listOfUserObjects5.get(k));
					}
				}
			}
			for (EgsdUserObjects e : listOfUserObjects6) {
				System.out.println(e.getUser() + "-->" + e.getUsername());

			}

		}
		return listOfUserObjects6;
	}

	public List searchingFirstName(String admin) {

		ParseQuery<ParseObject> queryForAdmin = ParseQuery.getQuery("_User");
		queryForAdmin.orderByAscending("username");
		queryForAdmin.whereMatches("firstname", admin, "i");
		queryForAdmin.whereEqualTo("Status", true);
		List<ParseObject> listOfAdmins = null;

		try {

			listOfAdmins = queryForAdmin.find();

		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));

			}

		} catch (NullPointerException npe) {
			listOfUserObjects.clear();
			// listOfUserObjects = searchingLastName(admin);
			return listOfUserObjects;
		}
		return listOfUserObjects;

	}

	public List searchingLastName(String admin) {

		ParseQuery<ParseObject> queryForAdmin = ParseQuery.getQuery("_User");
		queryForAdmin.orderByAscending("username");
		queryForAdmin.whereMatches("lastname", admin, "i");
		queryForAdmin.whereEqualTo("Status", true);
		List<ParseObject> listOfAdmins = null;
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);
		try {

			listOfAdmins = queryForAdmin.find();

		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));

			}

		} catch (NullPointerException npe) {
			listOfUserObjects.clear();
			// listOfUserObjects = searchingUsername(admin);
			return listOfUserObjects;
		}
		return listOfUserObjects;

	}

	@RequestMapping(value = "/searchTemplates", method = RequestMethod.POST)
	public @ResponseBody List searchTemplates(HttpServletRequest request) {

		System.out.println(request.getParameter("username"));
		String pattern = "^.*" + request.getParameter("searchId") + ".*$";
		ParseQuery<ParseObject> queryForSearchName = ParseQuery.getQuery("Template");
		List<ParseObject> listOfSearchNames = null;
		List<EgsdSearchTemplateObjects> listOfEgsdHotelObjects = null;
		// queryForSearchName.addAscendingOrder("Name");
		queryForSearchName.whereNotEqualTo("type", "group");

		queryForSearchName.whereMatches("Name", pattern, "i");

		try {
			listOfSearchNames = queryForSearchName.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchNames.listIterator();
			listOfEgsdHotelObjects = new ArrayList<EgsdSearchTemplateObjects>(100);

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects
						.add(new EgsdSearchTemplateObjects(hotelObjects.getString("Name"), hotelObjects.getObjectId()));

			}

		} catch (NullPointerException npe) {

			System.out.println(npe);
			listOfEgsdHotelObjects = searchingTemplateId(pattern);

		}

		return listOfEgsdHotelObjects;

	}

	public List searchingTemplateId(String pattern) {
		ParseQuery<ParseObject> queryForSearchObjectId = ParseQuery.getQuery("Template");

		queryForSearchObjectId.whereMatches("objectId", pattern, "i");

		List<ParseObject> listOfSearchObjectId = null;
		List<EgsdSearchTemplateObjects> listOfEgsdHotelObjects = null;

		try {
			listOfSearchObjectId = queryForSearchObjectId.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchObjectId.listIterator();
			listOfEgsdHotelObjects = new ArrayList<EgsdSearchTemplateObjects>(100);

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects
						.add(new EgsdSearchTemplateObjects(hotelObjects.getString("Name"), hotelObjects.getObjectId()));

			}

		} catch (NullPointerException npe) {

			System.out.println(npe);
			listOfEgsdHotelObjects = searchingObjects(pattern);

		}
		return listOfEgsdHotelObjects;

	}
	
	@RequestMapping(value = "/hotelMenuItems", method = RequestMethod.POST,produces="application/json")
	public @ResponseBody 
	String hotelMenuItems(@RequestBody Object[] resp) {
		
		ObjectMapper mapper = new ObjectMapper();
		String str="";
		try{
		 str = mapper.writeValueAsString(resp);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		System.out.println(str);
		
		JSONArray array = new JSONArray(str);
		JSONObject jsonObj;
		JSONObject jsonObj1=array.getJSONObject(0);
		String hotelMenuId = jsonObj1.getString("HotelId");
		ParseQuery<ParseObject> parseQueryForMenuItems = ParseQuery.getQuery("HotelMenuList");
	    parseQueryForMenuItems.whereEqualTo("HotelId", hotelMenuId);
        
        List<ParseObject> listOfMenuObjects = null;

		try {
			listOfMenuObjects = parseQueryForMenuItems.find();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {

			Iterator<ParseObject> iteratorForMenuObjects = listOfMenuObjects.listIterator();

			while (iteratorForMenuObjects.hasNext()) {

				ParseObject menuObject = iteratorForMenuObjects.next();

				try {
					menuObject.delete();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		} catch (NullPointerException npe) {

			System.out.println("No menu Items to delete");

		}
		
		
		
		for(int i=0; i<array.length(); i++){
			jsonObj  = array.getJSONObject(i);	        
	        
	        
			ParseObject parseObjectForMenuItem = new ParseObject("HotelMenuList");
				
				
				parseObjectForMenuItem.put("HotelId", jsonObj.getString("HotelId"));	
			
				parseObjectForMenuItem.put("MenuDescription", jsonObj.getString("MenuDesc"));
			
				parseObjectForMenuItem.put("MenuSequence", Integer.parseInt(jsonObj.getString("MenuQuan")));
				
				
				if(jsonObj.getString("ItemQuan").equals(""))
				{
					System.out.println("empty");
				}
				else
				{
					parseObjectForMenuItem.put("IconSequence", Integer.parseInt(jsonObj.getString("ItemQuan")));
				}				
				
				parseObjectForMenuItem.put("IconAction", jsonObj.getString("ItemAction"));
				
				
				try {
					parseObjectForMenuItem.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
	        
	        
	    }		
		
		return "success";
		
	}
	
	@RequestMapping(value = "/findHotelMenuList", method = RequestMethod.POST)
	public @ResponseBody List searchHotelMenuList(HttpServletRequest request) {
		
		System.out.println(request.getParameter("id"));
		String dirId = request.getParameter("id");
		ParseQuery<ParseObject> queryForSearchName = ParseQuery.getQuery("HotelMenuList");
		List<ParseObject> listOfSearchNames = null;
		List<HotelMenuListModel> listOfEgsdHotelMenuObjects = null;

		queryForSearchName.whereEqualTo("HotelId", dirId);

		try {
			listOfSearchNames = queryForSearchName.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchNames.listIterator();
			listOfEgsdHotelMenuObjects = new ArrayList<HotelMenuListModel>(100);

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();				

				listOfEgsdHotelMenuObjects.add(new HotelMenuListModel(hotelObjects.getString("MenuDescription"),hotelObjects.getInt("MenuSequence") , hotelObjects.getString("IconAction"),hotelObjects.getInt("IconSequence")));

			}
			
			

		} catch (NullPointerException npe) {

			
			System.out.println(npe);

		}

		return listOfEgsdHotelMenuObjects;

	}
	

	@RequestMapping(value = "/getDirectoryDetails", method = RequestMethod.POST)
	public @ResponseBody List searchDirectory(HttpServletRequest request) {

		System.out.println(request.getParameter("username"));
		String dirId = request.getParameter("searchId");
		ParseQuery<ParseObject> queryForSearchName = ParseQuery.getQuery("DirectoryItem");
		List<ParseObject> listOfSearchNames = null;
		List<DirectoryDetails> listOfEgsdHotelObjects = null;

		queryForSearchName.whereEqualTo("objectId", dirId);

		try {
			listOfSearchNames = queryForSearchName.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchNames.listIterator();
			listOfEgsdHotelObjects = new ArrayList<DirectoryDetails>(100);

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();
				ParseObject StyleIdPO = hotelObjects.getParseObject("StyleId");
				String styleId = null;
				if (hotelObjects.getParseObject("StyleId") != null)
					styleId = StyleIdPO.getObjectId();

				listOfEgsdHotelObjects.add(new DirectoryDetails(hotelObjects.getObjectId(),
						hotelObjects.getString("DirectoryID"), styleId, hotelObjects.getString("LocationId")));

			}

		} catch (NullPointerException npe) {

			System.out.println(npe);

		}

		return listOfEgsdHotelObjects;

	}

	@RequestMapping(value = "/editDirectoryDetails", method = RequestMethod.POST)
	public @ResponseBody DirectoryDetailsModel searchDirectoryDetails(HttpServletRequest request) {
		String styleId = null;
		System.out.println(request.getParameter("username"));
		String dirId = request.getParameter("searchId");
		DirectoryDetailsModel dModel = new DirectoryDetailsModel();
		ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
		Map<String, List> myMap = new HashMap<String, List>();
		queryForDirectoryItem.whereEqualTo("objectId", dirId);

		queryForDirectoryItem.orderByAscending("Title");
		queryForDirectoryItem.limit(1000);
		List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
		List listAll = new ArrayList();
		listAll.clear();
		try {
			directoryItemParseObjectsList = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(1000);
		System.out.println("Directory items are loaded:");
		try {
			Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
			System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->"
					+ "getTitle" + "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->"
					+ "getEmail" + "--->" + "getPhones");
			int count = 1;
			while (iterator.hasNext()) {

				EgsdDirectoryItemParseObject egsd = iterator.next();
				String img = "No Image To Display";
				if (egsd.getParseFile("Picture") != null)
					img = egsd.getParseFile("Picture").getUrl();
				// System.out.print(img);
				styleId = null;
				ParseObject StyleIdPO = egsd.getParseObject("StyleId");
				if (egsd.getParseObject("StyleId") != null)
					styleId = StyleIdPO.getObjectId();
				// System.out.println(styleId);

				/*
				 * if(StyleIdPO.getObjectId()!=null) System.out.println(
				 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
				 */

				directoryItemObjectsList.add(new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(),
						egsd.getTitle(), egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
						egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
						egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

			}
		} catch (NullPointerException npe) {

		}
		dModel.setDirectoryList(directoryItemObjectsList);

		ParseQuery<ParseObject> queryForStyleID = ParseQuery.getQuery("Style");
		queryForStyleID.limit(1000);
		queryForStyleID.whereEqualTo("objectId", styleId);

		List<ParseObject> styleIdObjParseObj = null;
		try {
			styleIdObjParseObj = queryForStyleID.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdStyleObjects> styleObjects = new ArrayList<EgsdStyleObjects>(200);
		try {
			Iterator<ParseObject> styleIterator = styleIdObjParseObj.listIterator();
			// System.out.println(styleIdObjParseObj);

			while (styleIterator.hasNext()) {
				ParseObject sp = styleIterator.next();

				styleObjects.add(new EgsdStyleObjects(sp.getObjectId(), sp.getString("TitleFont"),
						sp.getString("TitleColor"), sp.getString("TitleFamily"), sp.getString("CaptionFont"),
						sp.getString("CaptionColor"), sp.getString("CaptionFamily"), sp.getString("DescriptionFont"),
						sp.getString("DescriptionColor"), sp.getString("DescriptionFamily"), sp.getString("PhonesFont"),
						sp.getString("PhonesColor"), sp.getString("PhonesFamily"), sp.getString("TimingsFont"),
						sp.getString("TimingsColor"), sp.getString("TimingsFamily"), sp.getString("WebsiteFont"),
						sp.getString("WebsiteColor"), sp.getString("WebsiteFamily"), sp.getString("EmailFont"),
						sp.getString("EmailColor"), sp.getString("EmailFamily"), sp.getString("StyleID"),
						sp.getString("PriceFont"), sp.getString("PriceColor"), sp.getString("PriceFamily")));

			}
		} catch (NullPointerException npe) {

		}

		dModel.setStyleList(styleObjects);

		ParseQuery<ParseObject> queryForPhones = ParseQuery.getQuery("Phones");
		queryForPhones.limit(1000);
		queryForPhones.whereEqualTo("PhoneId", dirId);

		List<ParseObject> phonesParseObjectsList = null;
		try {
			phonesParseObjectsList = queryForPhones.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdPhonesObjects> phonesObjectsList = new ArrayList<EgsdPhonesObjects>(1000);
		System.out.println("Phone Objects  are loaded:");
		// System.out.println(phonesParseObjectsList);
		try {
			Iterator<ParseObject> phoneIterator = phonesParseObjectsList.listIterator();
			int i = 0;
			while (phoneIterator.hasNext()) {

				ParseObject egsdPhonePO = phoneIterator.next();

				// System.out.println(egsdPhonePO.getObjectId()
				// +"-->"+egsdPhonePO.getString("PhoneId")
				// +"-->"+egsdPhonePO.getString("Type")
				// +"-->"+egsdPhonePO.getString("Ext"));
				phonesObjectsList.add(new EgsdPhonesObjects(egsdPhonePO.getObjectId(), egsdPhonePO.getString("PhoneId"),
						egsdPhonePO.getString("Type"), egsdPhonePO.getString("Ext")));

			}
		} catch (NullPointerException npe) {
			System.out.println(npe);
		}

		dModel.setPhoneList(phonesObjectsList);

		ParseQuery<ParseObject> queryForMenu = ParseQuery.getQuery("Menu");
		queryForMenu.whereEqualTo("MenuId", dirId);
		List<ParseObject> menuParseObjectsList = null;
		try {
			menuParseObjectsList = queryForMenu.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdMenuObjects> menuObjectsList = new ArrayList<EgsdMenuObjects>(1000);
		System.out.println("Menu Items are loaded:");
		// System.out.println(menuParseObjectsList);
		try {
			Iterator<ParseObject> menuIterator = menuParseObjectsList.listIterator();
			while (menuIterator.hasNext()) {

				ParseObject egsdMenuPO = menuIterator.next();
				// System.out.println(egsdMenuPO.getObjectId() + "---> " +
				// egsdMenuPO.getString("MenuId") + "--->"
				// + egsdMenuPO.getString("Description") + "--->" +
				// egsdMenuPO.getString("Price"));
				// System.out.println(egsdMenuPO.getParseObject("StyleID"));
				// ParseObject styleIdObj=egsdMenuPO.getParseObject("StyleID");

				ParseObject ppp = egsdMenuPO.getParseObject("StyleID");
				// System.out.println("menu o.i:
				// "+egsdMenuPO.getObjectId()+"::styleId o.i:
				// "+ppp.getObjectId());

				menuObjectsList.add(new EgsdMenuObjects(egsdMenuPO.getObjectId(), egsdMenuPO.getString("MenuId"),
						egsdMenuPO.getString("Description"), egsdMenuPO.getString("Price"), ppp.getObjectId()));
			}
		} catch (NullPointerException npe) {

		}
		dModel.setMenuList(menuObjectsList);

		return dModel;

	}

	@RequestMapping(value = "/searchGroups", method = RequestMethod.POST)
	public @ResponseBody List searchGroups(HttpServletRequest request) {

		System.out.println(request.getParameter("username"));
		String pattern = "^.*" + request.getParameter("searchId") + ".*$";
		ParseQuery<ParseObject> queryForSearchName = ParseQuery.getQuery("Template");
		List<ParseObject> listOfSearchNames = null;
		List<EgsdSearchTemplateObjects> listOfEgsdHotelObjects = null;
		queryForSearchName.addAscendingOrder("Name");
		queryForSearchName.whereEqualTo("type", "group");

		queryForSearchName.whereMatches("Name", pattern, "i");

		try {
			listOfSearchNames = queryForSearchName.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchNames.listIterator();
			listOfEgsdHotelObjects = new ArrayList<EgsdSearchTemplateObjects>(100);

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects
						.add(new EgsdSearchTemplateObjects(hotelObjects.getString("Name"), hotelObjects.getObjectId()));

			}

		} catch (NullPointerException npe) {

			System.out.println(npe);
			listOfEgsdHotelObjects = searchingGroupId(request.getParameter("searchId"));

		}

		return listOfEgsdHotelObjects;

	}

	public List searchingGroupId(String pattern) {
		ParseQuery<ParseObject> queryForSearchObjectId = ParseQuery.getQuery("Template");

		queryForSearchObjectId.whereEqualTo("objectId", pattern);

		List<ParseObject> listOfSearchObjectId = null;
		List<EgsdSearchTemplateObjects> listOfEgsdHotelObjects = null;

		try {
			listOfSearchObjectId = queryForSearchObjectId.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		try {
			Iterator<ParseObject> iteratorForSearchObjects = listOfSearchObjectId.listIterator();
			listOfEgsdHotelObjects = new ArrayList<EgsdSearchTemplateObjects>(100);

			while (iteratorForSearchObjects.hasNext()) {

				ParseObject hotelObjects = iteratorForSearchObjects.next();

				listOfEgsdHotelObjects
						.add(new EgsdSearchTemplateObjects(hotelObjects.getString("Name"), hotelObjects.getObjectId()));

			}

		} catch (NullPointerException npe) {

			System.out.println(npe);
			listOfEgsdHotelObjects = searchingObjects(pattern);

		}
		return listOfEgsdHotelObjects;

	}

	@RequestMapping(value = "/registerSuperAdmin", method = RequestMethod.POST)
	public @ResponseBody String registerSuperAdmin(HttpServletRequest request) throws ParseException {

		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("userName"));
		System.out.println(request.getParameter("locId"));
		String locAdminId = "";
		ParseQuery<ParseObject> queryForLocationAdmin = ParseQuery.getQuery("_User");
		System.out.println();
		if (request.getParameter("sEmail") == "" || request.getParameter("sEmail") == null) {

			queryForLocationAdmin.whereEqualTo("username", request.getParameter("username"));

			List<ParseObject> listOfEmptyAdmins = null;
			try {
				listOfEmptyAdmins = queryForLocationAdmin.find();

			} catch (NullPointerException e) {
				// TODO: handle exception
				System.out.println(e);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (listOfEmptyAdmins == null) {
				ParseQuery<ParseObject> queryForEmail = ParseQuery.getQuery("_User");
				queryForEmail.whereEqualTo("email", request.getParameter("email"));
				List<ParseObject> listOfEmptyEmail = null;
				try {
					listOfEmptyEmail = queryForEmail.find();

				} catch (NullPointerException e) {
					// TODO: handle exception
					System.out.println(e);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (listOfEmptyEmail == null) {
					HashMap<String, String> params = new HashMap<String, String>();
					params.put("username", request.getParameter("username"));
					params.put("firstname", request.getParameter("firstname"));
					params.put("lastname", request.getParameter("lastname"));
					params.put("password", "superadmin");
					params.put("email", request.getParameter("email"));
					params.put("user", "Super Admin");
					params.put("locationId", "");

					String result = null;
					try {
						result = ParseCloud.callFunction("signUpForLocationAdmin", params);

						SendEmail email = new SendEmail();
						String res = email.sendEmail(request.getParameter("firstname"), request.getParameter("email"),
								request.getParameter("username"), "superadmin", "Super Admin");
						System.out.println(res);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					locAdminId = "emailExisted";
				}

			} else {
				locAdminId = "userExisted";
			}

		} else {
			HashMap<String, String> params = new HashMap<String, String>();
			params.put("username", request.getParameter("username"));
			params.put("firstname", request.getParameter("firstname"));
			params.put("lastname", request.getParameter("lastname"));
			params.put("email", request.getParameter("email"));
			params.put("objectId", request.getParameter("sEmail"));
			String result = "";
			try {
				result = ParseCloud.callFunction("updateAdminInformation", params);

				System.out.println("admin update :" + result);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			locAdminId = "userUpdated";
		}

		// EgsdController.getDataFromParse(request);
		/*
		 * try { select(request); } catch (ParseException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */

		/*
		 * mav.addObject("userName", request.getParameter("userName"));
		 * mav.addObject("user", request.getParameter("user"));
		 * 
		 * if (request.getParameter("userName").equals("IT Admin"))
		 * mav.setViewName("ITAdmin");
		 * 
		 * if (request.getParameter("userName").equals("Super Admin"))
		 * mav.setViewName("SuperAdmin");
		 * 
		 * if (request.getParameter("userName").equals("CS Admin"))
		 * mav.setViewName("CSAdmin"); return mav;
		 */

		return locAdminId;

	}

	@RequestMapping(value = "/registerCSAdmin", method = RequestMethod.POST)
	public @ResponseBody String registerCSAdmin(HttpServletRequest request) {

		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("userName"));
		System.out.println(request.getParameter("locId"));

		ParseQuery<ParseObject> queryForLocationAdmin = ParseQuery.getQuery("_User");
		queryForLocationAdmin.whereEqualTo("username", request.getParameter("username"));
		String locAdminId = "";
		if (request.getParameter("sEmail") == "" || request.getParameter("sEmail") == null) {
			List<ParseObject> listOfEmptyAdmins = null;
			try {
				listOfEmptyAdmins = queryForLocationAdmin.find();

			} catch (NullPointerException e) {
				// TODO: handle exception
				System.out.println(e);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (listOfEmptyAdmins == null) {
				ParseQuery<ParseObject> queryForEmail = ParseQuery.getQuery("_User");
				queryForEmail.whereEqualTo("email", request.getParameter("email"));
				List<ParseObject> listOfEmptyEmail = null;
				try {
					listOfEmptyEmail = queryForEmail.find();

				} catch (NullPointerException e) {
					// TODO: handle exception
					System.out.println(e);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (listOfEmptyEmail == null) {
					HashMap<String, String> params = new HashMap<String, String>();
					params.put("username", request.getParameter("username"));
					params.put("firstname", request.getParameter("firstname"));
					params.put("lastname", request.getParameter("lastname"));
					params.put("password", "csadmin");
					params.put("email", request.getParameter("email"));
					params.put("user", "CS Admin");
					params.put("locationId", "");

					String result = null;
					try {
						result = ParseCloud.callFunction("signUpForLocationAdmin", params);
						SendEmail email = new SendEmail();
						String res = email.sendEmail(request.getParameter("firstname"), request.getParameter("email"),
								request.getParameter("username"), "csadmin", "CS Admin");
						System.out.println(res);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					locAdminId = "emailExisted";
				}

			} else {
				locAdminId = "userExisted";
			}
		} else {
			HashMap<String, String> params = new HashMap<String, String>();
			params.put("username", request.getParameter("username"));
			params.put("firstname", request.getParameter("firstname"));
			params.put("lastname", request.getParameter("lastname"));
			params.put("email", request.getParameter("email"));
			params.put("objectId", request.getParameter("sEmail"));
			String result = "";
			try {
				result = ParseCloud.callFunction("updateAdminInformation", params);

				System.out.println("admin update :" + result);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			locAdminId = "userUpdated";
		}

		// EgsdController.getDataFromParse(request);
		/*
		 * try { select(request); } catch (ParseException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */

		return locAdminId;

		/*
		 * mav.addObject("userName", request.getParameter("userName"));
		 * mav.addObject("user", request.getParameter("user"));
		 * 
		 * if (request.getParameter("userName").equals("Super Admin"))
		 * mav.setViewName("SuperAdmin");
		 * 
		 * if (request.getParameter("userName").equals("CS Admin"))
		 * mav.setViewName("CSAdmin"); return mav;
		 */
	}

	@RequestMapping(value = "/verifyHotel", method = RequestMethod.POST)
	public @ResponseBody String verifyHotel(HttpServletRequest request) {
		String result = "";
		String name = request.getParameter("hotelName");
		System.out.println(name);

		ParseQuery<ParseObject> queryForHotels = ParseQuery.getQuery("Location");
		queryForHotels.whereEqualTo("Name", name);

		List<ParseObject> listOfLocationsFromParse = null;

		try {
			listOfLocationsFromParse = queryForHotels.find();

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (listOfLocationsFromParse == null) {
			result = "noduplicate";
		} else {
			result = "duplicate";
		}

		return result;

	}

	@RequestMapping(value = "/verifyTemplate", method = RequestMethod.POST)
	public @ResponseBody String verifyTemplate(HttpServletRequest request) {
		String result = "";
		String name = request.getParameter("templateName");
		System.out.println(name);

		ParseQuery<ParseObject> queryForTemplates = ParseQuery.getQuery("Template");
		queryForTemplates.whereEqualTo("Name", name);

		List<ParseObject> listOfLocationsFromParse = null;

		try {
			listOfLocationsFromParse = queryForTemplates.find();

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (listOfLocationsFromParse == null) {
			result = "noduplicate";
		} else {
			result = "duplicate";
		}
		System.out.println(result);
		return result;

	}

	@RequestMapping(value = "/verifyGroup", method = RequestMethod.POST)
	public @ResponseBody String verifyGroup(HttpServletRequest request) {
		String result = "";
		String name = request.getParameter("groupName");
		System.out.println(name);

		ParseQuery<ParseObject> queryForGroups = ParseQuery.getQuery("Template");
		queryForGroups.whereEqualTo("type", "group");
		queryForGroups.whereEqualTo("Name", name);

		List<ParseObject> listOfLocationsFromParse = null;

		try {
			listOfLocationsFromParse = queryForGroups.find();

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (listOfLocationsFromParse == null) {
			result = "noduplicate";
		} else {
			result = "duplicate";
		}
		System.out.println(result);
		return result;

	}

	@RequestMapping(value = "/registerLocationAdmin", method = RequestMethod.POST)
	public @ResponseBody String registerLocationAdmin(HttpServletRequest request) {

		String locAdminId = "";
		System.out.println("Fields dat got from Form");
		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("userName"));

		ParseQuery<ParseObject> queryForLocationAdmin = ParseQuery.getQuery("_User");
		queryForLocationAdmin.whereEqualTo("username", request.getParameter("username"));
		if (request.getParameter("sEmail") == "" || request.getParameter("sEmail") == null) {
			List<ParseObject> listOfEmptyAdmins = null;
			try {
				listOfEmptyAdmins = queryForLocationAdmin.find();

			} catch (NullPointerException e) {
				// TODO: handle exception
				System.out.println(e);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (listOfEmptyAdmins == null) {
				ParseQuery<ParseObject> queryForEmail = ParseQuery.getQuery("_User");
				queryForEmail.whereEqualTo("email", request.getParameter("email"));
				List<ParseObject> listOfEmptyEmail = null;
				try {
					listOfEmptyEmail = queryForEmail.find();

				} catch (NullPointerException e) {
					// TODO: handle exception
					System.out.println(e);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (listOfEmptyEmail == null) {
					ParseObject locationObject = new ParseObject("_User");
					locationObject.put("username", request.getParameter("username"));
					locationObject.put("firstname", request.getParameter("firstname"));
					locationObject.put("lastname", request.getParameter("lastname"));
					locationObject.put("password", "locationadmin");
					locationObject.put("Status", true);
					locationObject.put("email", request.getParameter("email"));
					locationObject.put("user", "Location Admin");
					locationObject.put("locationId", "empty");

					try {
						locationObject.save();
						SendEmail email = new SendEmail();
						String res = email.sendEmail(request.getParameter("firstname"), request.getParameter("email"),
								request.getParameter("username"), "locationadmin", "Location Admin");
						System.out.println(res);
						locAdminId = locationObject.getObjectId();
						System.out.println(locAdminId);

					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} else {
					locAdminId = "emailExisted";
				}

			} else {
				locAdminId = "userExisted";
			}
		} else {
			HashMap<String, String> params = new HashMap<String, String>();
			params.put("username", request.getParameter("username"));
			params.put("firstname", request.getParameter("firstname"));
			params.put("lastname", request.getParameter("lastname"));
			params.put("email", request.getParameter("email"));
			params.put("objectId", request.getParameter("sEmail"));
			String result = "";
			try {
				result = ParseCloud.callFunction("updateAdminInformation", params);

				System.out.println("admin update :" + result);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			locAdminId = "userUpdated";
		}

		/*
		 * HashMap<String, String> params = new HashMap<String, String>();
		 * params.put("username", request.getParameter("username"));
		 * params.put("firstname", request.getParameter("firstname"));
		 * params.put("lastname", request.getParameter("lastname"));
		 * params.put("password", "locationadmin"); params.put("email",
		 * request.getParameter("email")); params.put("user", "Location Admin");
		 * params.put("locationId","empty" );
		 * 
		 * 
		 * String result=null; try { result =
		 * ParseCloud.callFunction("signUpForLocationAdmin", params); SendEmail
		 * email = new SendEmail(); String res =
		 * email.sendEmail(request.getParameter("email"),
		 * request.getParameter("username"), "locationadmin", "Location Admin");
		 * System.out.println(res); } catch (ParseException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */

		// EgsdController.getDataFromParse(request);

		// adminLoad(request);

		/*
		 * try { select(request); } catch (ParseException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */

		return locAdminId;

		/*
		 * if (request.getParameter("userName").equals("Super Admin"))
		 * mav.setViewName("SuperAdmin");
		 * 
		 * 
		 * if (request.getParameter("userName").equals("CS Admin"))
		 * mav.setViewName("CSAdmin");
		 * 
		 * mav.addObject("userName", request.getParameter("userName"));
		 * mav.addObject("user", request.getParameter("user"));
		 * 
		 * 
		 * 
		 * mav.setViewName("RegisterLocationAdmin");
		 * mav.addObject("user",request.getParameter("user") );
		 * mav.addObject("userName",request.getParameter("userName") );
		 * 
		 * return mav;
		 */
	}

	@RequestMapping(value = "/newedit", method = RequestMethod.POST)
	public ModelAndView demo(HttpServletRequest request) {

		System.out.println("Entered into Add Directories");

		System.out.println("objectId:" + request.getParameter("objectId"));
		System.out.println("directoryId:" + request.getParameter("directoryId"));
		System.out.println("userName:" + request.getParameter("userName"));
		System.out.println("styleId:" + request.getParameter("styleId"));
		System.out.println("phones:" + request.getParameter("phones"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Title");
		System.out.println("title:" + request.getParameter("title"));
		System.out.println("titleColor:" + request.getParameter("titleColor"));
		System.out.println("titleFont:" + request.getParameter("titleFont"));
		System.out.println("---------------------------------------------");
		System.out.println("Displaying Caption");
		System.out.println("caption:" + request.getParameter("caption"));
		System.out.println("captionColor:" + request.getParameter("captionColor"));
		System.out.println("captionFont:" + request.getParameter("captionFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Timings");
		System.out.println("timings:" + request.getParameter("timings"));
		System.out.println("timingsColor:" + request.getParameter("timingsColor"));
		System.out.println("timingsFont:" + request.getParameter("timingsFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Website");
		System.out.println("website:" + request.getParameter("website"));
		System.out.println("websiteColor:" + request.getParameter("websiteColor"));
		System.out.println("websiteFont:" + request.getParameter("websiteFont"));
		System.out.println("---------------------------------------------");

		System.out.println("Displaying Email");
		System.out.println("email:" + request.getParameter("email"));
		System.out.println("emailColor:" + request.getParameter("emailColor"));
		System.out.println("emailFont:" + request.getParameter("emailFont"));
		System.out.println("---------------------------------------------");

		System.out.println("description:" + request.getParameter("description"));
		System.out.println("descriptionFont:" + request.getParameter("descriptionFont"));
		System.out.println("descriptionColor:" + request.getParameter("descriptionColor"));
		System.out.println("---------------------------------------------");

		System.out.println("phonesFont:" + request.getParameter("phonesFont"));
		System.out.println("phonesColor:" + request.getParameter("phonesColor"));
		System.out.println("phonesType:" + request.getParameter("type"));
		System.out.println("phonesext:" + request.getParameter("ext"));

		System.out.println("---------------------------------------------");

		System.out.println("priceFont:" + request.getParameter("priceFont"));
		System.out.println("priceColor:" + request.getParameter("priceColor"));
		System.out.println("---------------------------------------------");

		String values[] = request.getParameterValues("menuValues");

		return new ModelAndView("Sample");
	}

	@RequestMapping(value = "/logout")
	public synchronized ModelAndView logout() throws ParseException {

		System.out.println("b4 logout");

		ParseUser ps = new ParseUser();
		ps.logout();
		System.out.println("aftr logout");
		return new ModelAndView("Error");
	}

	@RequestMapping(value = "/menu/{objId}")
	public synchronized ModelAndView menu(HttpServletRequest req) throws ParseException {

		System.out.println("b4 insert");

		System.out.println("aftr insert");
		return new ModelAndView("Sample");
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public synchronized ModelAndView forgotPassword(HttpServletRequest req) throws ParseException {

		// ModelAndView mav=new ModelAndView();

		ParseQuery<ParseObject> queryForEmail = ParseQuery.getQuery("_User");
		// queryForEmail.whereEqualTo("email",req.getParameter("email"));
		List<ParseObject> listOfEmails = queryForEmail.find();

		Iterator<ParseObject> listIterator = listOfEmails.listIterator();
		while (listIterator.hasNext()) {
			ParseObject po = listIterator.next();
			if (po.getString("email") != null) {
				if (po.getString("email").equals(req.getParameter("email"))) {
					ParseUser.requestPasswordReset(req.getParameter("email"));
					return new ModelAndView("login", "mailId", req.getParameter("email"));
				}
			}
		}

		System.out.println(req.getParameter("email"));
		System.out.println("aftr insert");
		return new ModelAndView("WrongPassword", "mailId", req.getParameter("email"));
	}

	@RequestMapping(value = "/addTemplateg", method = RequestMethod.POST)
	public ModelAndView createTemplateg(HttpServletRequest request) {

		System.out.println(request.getParameter("templateName"));
		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("userName"));
		System.out.println(request.getParameter("templateId"));

		return null;
	}

	@RequestMapping(value = "/addTemplate", method = RequestMethod.POST)
	public ModelAndView createTemplate(HttpServletRequest request) {

		System.out.println(request.getParameter("templateName"));
		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("userName"));
		System.out.println(request.getParameter("templateId"));

		ParseObject templateObject = new ParseObject("Template");

		templateObject.put("Name", request.getParameter("templateName"));
		templateObject.put("Customized", true);

		try {
			templateObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		templateObject.put("LocationId", templateObject.getObjectId());

		try {
			templateObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ParseQuery<ParseObject> queryDefaultDirectoryItemObjects = ParseQuery.getQuery("DirectoryItem");
		queryDefaultDirectoryItemObjects.whereEqualTo("DirectoryID", request.getParameter("templateId"));

		List<ParseObject> listOfDefaultDirectoryItems = null;

		try {
			listOfDefaultDirectoryItems = queryDefaultDirectoryItemObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForDefaultDirectoryItems = listOfDefaultDirectoryItems.listIterator();

			while (iteratorForDefaultDirectoryItems.hasNext()) {

				ParseObject parseObjectOfParentDirectoryItem = iteratorForDefaultDirectoryItems.next();

				System.out.println(parseObjectOfParentDirectoryItem.getString("Title"));
				System.out.println(parseObjectOfParentDirectoryItem.getString("Caption"));
				System.out.println(parseObjectOfParentDirectoryItem.getString("Description"));
				System.out.println(parseObjectOfParentDirectoryItem.getString("Email"));

				ParseObject directoryItemObject = new ParseObject("DirectoryItem");

				if (parseObjectOfParentDirectoryItem.getString("Title") != null)
					directoryItemObject.put("Title", parseObjectOfParentDirectoryItem.getString("Title"));
				if (parseObjectOfParentDirectoryItem.getString("Caption") != null)
					directoryItemObject.put("Caption", parseObjectOfParentDirectoryItem.getString("Caption"));
				if (parseObjectOfParentDirectoryItem.getString("Description") != null)
					directoryItemObject.put("Description", parseObjectOfParentDirectoryItem.getString("Description"));

				if (parseObjectOfParentDirectoryItem.getString("Email") != null)
					directoryItemObject.put("Email", parseObjectOfParentDirectoryItem.getString("Email"));

				directoryItemObject.put("LocationId", templateObject.getObjectId());
				directoryItemObject.put("DirectoryID", templateObject.getObjectId());

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding styles to chain directory Items

				ParseQuery<ParseObject> queryForStyleObjects = ParseQuery.getQuery("Style");
				queryForStyleObjects.whereEqualTo("objectId",
						parseObjectOfParentDirectoryItem.getParseObject("StyleId").getObjectId());

				List<ParseObject> listOfDirectoryItemStyleObject = null;

				try {
					listOfDirectoryItemStyleObject = queryForStyleObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForDirectoryItemStyleObject = listOfDirectoryItemStyleObject
						.listIterator();

				ParseObject directoryItemStyleObject = iteratorForDirectoryItemStyleObject.next();

				ParseObject directoryItemChainStyleObj = new ParseObject("Style");

				if (directoryItemStyleObject.getString("TitleFont") != null)
					directoryItemChainStyleObj.put("TitleFont", directoryItemStyleObject.getString("TitleFont"));

				if (directoryItemStyleObject.getString("TitleColor") != null)
					directoryItemChainStyleObj.put("TitleColor", directoryItemStyleObject.getString("TitleColor"));

				if (directoryItemStyleObject.getString("TitleFamily") != null)
					directoryItemChainStyleObj.put("TitleFamily", directoryItemStyleObject.getString("TitleFamily"));

				if (directoryItemStyleObject.getString("CaptionFont") != null)
					directoryItemChainStyleObj.put("CaptionFont", directoryItemStyleObject.getString("CaptionFont"));

				if (directoryItemStyleObject.getString("CaptionColor") != null)
					directoryItemChainStyleObj.put("CaptionColor", directoryItemStyleObject.getString("CaptionColor"));

				if (directoryItemStyleObject.getString("CaptionFamily") != null)
					directoryItemChainStyleObj.put("CaptionFamily",
							directoryItemStyleObject.getString("CaptionFamily"));

				if (directoryItemStyleObject.getString("DescriptionFont") != null)
					directoryItemChainStyleObj.put("DescriptionFont",
							directoryItemStyleObject.getString("DescriptionFont"));

				if (directoryItemStyleObject.getString("DescriptionColor") != null)
					directoryItemChainStyleObj.put("DescriptionColor",
							directoryItemStyleObject.getString("DescriptionColor"));

				if (directoryItemStyleObject.getString("DescriptionFamily") != null)
					directoryItemChainStyleObj.put("DescriptionFamily",
							directoryItemStyleObject.getString("DescriptionFamily"));

				if (directoryItemStyleObject.getString("TimingsFont") != null)
					directoryItemChainStyleObj.put("TimingsFont", directoryItemStyleObject.getString("TimingsFont"));

				if (directoryItemStyleObject.getString("TimingsColor") != null)
					directoryItemChainStyleObj.put("TimingsColor", directoryItemStyleObject.getString("TimingsColor"));

				if (directoryItemStyleObject.getString("TimingsFamily") != null)
					directoryItemChainStyleObj.put("TimingsFamily",
							directoryItemStyleObject.getString("TimingsFamily"));

				directoryItemChainStyleObj.put("LocationId", templateObject.getObjectId());

				try {
					directoryItemChainStyleObj.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				directoryItemObject.put("StyleId", directoryItemChainStyleObj);

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding phone Items

				ParseQuery<ParseObject> queryForPhoneObjects = ParseQuery.getQuery("Phones");
				queryForPhoneObjects.whereEqualTo("PhoneId", parseObjectOfParentDirectoryItem.getObjectId());

				List<ParseObject> listOfPhoneObjects = null;

				try {
					listOfPhoneObjects = queryForPhoneObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForPhoneObjects = listOfPhoneObjects.listIterator();

					while (iteratorForPhoneObjects.hasNext()) {

						ParseObject phoneObject = iteratorForPhoneObjects.next();

						ParseObject newPhoneObject = new ParseObject("Phones");

						if (phoneObject.getString("Ext") != null)
							newPhoneObject.put("Ext", phoneObject.getString("Ext"));
						if (phoneObject.getString("Type") != null)
							newPhoneObject.put("Type", phoneObject.getString("Type"));

						newPhoneObject.put("PhoneId", directoryItemObject.getObjectId());
						newPhoneObject.put("LocationId", templateObject.getObjectId());

						try {
							newPhoneObject.save();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				} catch (NullPointerException npe) {

				}

				// adding phone Items

				/*
				 * ParseQuery<ParseObject>
				 * queryForMenuObjects=ParseQuery.getQuery("Menu");
				 * queryForMenuObjects.whereEqualTo("MenuId",
				 * parseObjectOfParentDirectoryItem.getObjectId());
				 * 
				 * List<ParseObject> listOfMenuObjects=null;
				 * 
				 * try { listOfMenuObjects=queryForMenuObjects.find(); } catch
				 * (ParseException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); }
				 * 
				 * 
				 * try{
				 * 
				 * Iterator<ParseObject>
				 * iteratorForMenuObjects=listOfMenuObjects.listIterator();
				 * 
				 * while(iteratorForMenuObjects.hasNext()){
				 * 
				 * ParseObject menuObject=iteratorForMenuObjects.next();
				 * 
				 * ParseObject newMenuObject=new ParseObject("Menu");
				 * 
				 * if(menuObject.getString("Description")!=null ||
				 * menuObject.getString("Description")!= "")
				 * newMenuObject.put("Description",
				 * menuObject.getString("Description"));
				 * if(menuObject.getString("Price")!=null ||
				 * menuObject.getString("Description")!= "")
				 * newMenuObject.put("Price", menuObject.getString("Price"));
				 * 
				 * newMenuObject.put("MenuId",directoryItemObject.getObjectId()
				 * );
				 * newMenuObject.put("LocationId",templateObject.getObjectId()
				 * );
				 * 
				 * try { newMenuObject.save(); } catch (ParseException e) { //
				 * TODO Auto-generated catch block e.printStackTrace(); }
				 * 
				 * }
				 * 
				 * 
				 * }catch(NullPointerException npe){
				 * 
				 * 
				 * }
				 */

				checkChain(parseObjectOfParentDirectoryItem.getObjectId(), directoryItemObject,
						directoryItemObject.getObjectId(), templateObject.getObjectId());

			}

		} catch (NullPointerException npe) {

		}

		// getDataFromParse(request);

		// adminLoad(request);
		request.setAttribute("locId", request.getParameter("templateId"));
		try {
			select(request);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));
		if (request.getParameter("locId") != null) {
			if (request.getParameter("userName").equals("Location Admin")) {
				mav.setViewName("LocationAdmin");
			}
			if (request.getParameter("userName").equals("CS Admin")) {
				mav.setViewName("CSAdmin");
			}
			if (request.getParameter("userName").equals("Super Admin")) {
				mav.setViewName("SuperAdmin");
			}
			if (request.getParameter("userName").equals("IT Admin")) {
				mav.setViewName("ITAdmin");
			}
		}
		if (request.getParameter("tempId") != null) {
			System.out.println(request.getParameter("tempId"));
			ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
			queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

			List<ParseObject> listOfTemplateObjects = null;

			try {
				listOfTemplateObjects = queryForTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
				List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForTemplateObjects.next();

					listOfEgsdTemplateObjects.add(
							new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
									templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

				}

				mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

			} catch (NullPointerException npe) {

			}

			// list for selecting Templates
			ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
			// queryForSelectingTemplateObjects.whereEqualTo("objectId",
			// request.getParameter("tempId"));
			queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

			List<ParseObject> listOfSelectingTemplateObjects = null;

			try {
				listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
						.listIterator();
				List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForSelectingTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

					listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
							templateObjects.getString("Name"), null, false));

				}

				mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

			} catch (NullPointerException npe) {

			}
			if (request.getParameter("userName").equals("Super Admin"))
				mav.setViewName("SuperAdminTemplates");

			if (request.getParameter("userName").equals("IT Admin"))
				mav.setViewName("ITAdminTemplates");

			if (request.getParameter("userName").equals("CS Admin"))
				mav.setViewName("CSAdminTemplates");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		} else {
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
			if (request.getParameter("userName").equals("CS Admin")) {
				mav.setViewName("CSHotelList");
			}
			if (request.getParameter("userName").equals("Super Admin")) {
				mav.setViewName("SuperHotelList");
			}
			if (request.getParameter("userName").equals("IT Admin")) {
				mav.setViewName("ITHotelList");
			}

		}

		return mav;
	}

	@RequestMapping(value = "/addTemplateHotelList1", method = RequestMethod.POST)
	public ModelAndView createTemplateHotelList1(HttpServletRequest request) {

		adminLoad(request);

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationAdmin");

		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdmin");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("HotelList");

		return mav;

	}

	@RequestMapping(value = "/addTemplateHotelList", method = RequestMethod.POST)
	public ModelAndView createTemplateHotelList(HttpServletRequest request) {

		System.out.println(request.getParameter("templateName"));
		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("userName"));
		System.out.println(request.getParameter("templateId"));

		ParseObject templateObject = new ParseObject("Template");

		templateObject.put("Name", request.getParameter("templateName"));
		templateObject.put("Customized", true);

		try {
			templateObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		templateObject.put("LocationId", templateObject.getObjectId());

		try {
			templateObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ParseQuery<ParseObject> queryDefaultDirectoryItemObjects = ParseQuery.getQuery("DirectoryItem");
		queryDefaultDirectoryItemObjects.whereEqualTo("DirectoryID", request.getParameter("templateId"));

		List<ParseObject> listOfDefaultDirectoryItems = null;

		try {
			listOfDefaultDirectoryItems = queryDefaultDirectoryItemObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForDefaultDirectoryItems = listOfDefaultDirectoryItems.listIterator();

			while (iteratorForDefaultDirectoryItems.hasNext()) {

				ParseObject parseObjectOfParentDirectoryItem = iteratorForDefaultDirectoryItems.next();

				System.out.println(parseObjectOfParentDirectoryItem.getString("Title"));

				ParseObject directoryItemObject = new ParseObject("DirectoryItem");

				if (parseObjectOfParentDirectoryItem.getString("Title") != null)
					directoryItemObject.put("Title", parseObjectOfParentDirectoryItem.getString("Title"));
				if (parseObjectOfParentDirectoryItem.getString("Caption") != null)
					directoryItemObject.put("Caption", parseObjectOfParentDirectoryItem.getString("Caption"));
				if (parseObjectOfParentDirectoryItem.getString("Description") != null)
					directoryItemObject.put("Description", parseObjectOfParentDirectoryItem.getString("Description"));
				if (parseObjectOfParentDirectoryItem.getString("Timings") != null)
					directoryItemObject.put("Timings", parseObjectOfParentDirectoryItem.getString("Timings"));
				if (parseObjectOfParentDirectoryItem.getString("Website") != null)
					directoryItemObject.put("Website", parseObjectOfParentDirectoryItem.getString("Website"));
				if (parseObjectOfParentDirectoryItem.getString("Email") != null)
					directoryItemObject.put("Email", parseObjectOfParentDirectoryItem.getString("Email"));

				if (parseObjectOfParentDirectoryItem.getParseObject("Picture") != null)
					directoryItemObject.put("Picture", parseObjectOfParentDirectoryItem.getParseObject("Picture"));

				directoryItemObject.put("LocationId", templateObject.getObjectId());
				directoryItemObject.put("DirectoryID", templateObject.getObjectId());

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding styles to chain directory Items

				ParseQuery<ParseObject> queryForStyleObjects = ParseQuery.getQuery("Style");
				queryForStyleObjects.whereEqualTo("objectId",
						parseObjectOfParentDirectoryItem.getParseObject("StyleId").getObjectId());

				List<ParseObject> listOfDirectoryItemStyleObject = null;

				try {
					listOfDirectoryItemStyleObject = queryForStyleObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForDirectoryItemStyleObject = listOfDirectoryItemStyleObject
						.listIterator();

				ParseObject directoryItemStyleObject = iteratorForDirectoryItemStyleObject.next();

				ParseObject directoryItemChainStyleObj = new ParseObject("Style");

				if (directoryItemStyleObject.getString("TitleFont") != null)
					directoryItemChainStyleObj.put("TitleFont", directoryItemStyleObject.getString("TitleFont"));

				if (directoryItemStyleObject.getString("TitleColor") != null)
					directoryItemChainStyleObj.put("TitleColor", directoryItemStyleObject.getString("TitleColor"));

				if (directoryItemStyleObject.getString("TitleFamily") != null)
					directoryItemChainStyleObj.put("TitleFamily", directoryItemStyleObject.getString("TitleFamily"));

				if (directoryItemStyleObject.getString("CaptionFont") != null)
					directoryItemChainStyleObj.put("CaptionFont", directoryItemStyleObject.getString("CaptionFont"));

				if (directoryItemStyleObject.getString("CaptionColor") != null)
					directoryItemChainStyleObj.put("CaptionColor", directoryItemStyleObject.getString("CaptionColor"));

				if (directoryItemStyleObject.getString("CaptionFamily") != null)
					directoryItemChainStyleObj.put("CaptionFamily",
							directoryItemStyleObject.getString("CaptionFamily"));

				if (directoryItemStyleObject.getString("DescriptionFont") != null)
					directoryItemChainStyleObj.put("DescriptionFont",
							directoryItemStyleObject.getString("DescriptionFont"));

				if (directoryItemStyleObject.getString("DescriptionColor") != null)
					directoryItemChainStyleObj.put("DescriptionColor",
							directoryItemStyleObject.getString("DescriptionColor"));

				if (directoryItemStyleObject.getString("DescriptionFamily") != null)
					directoryItemChainStyleObj.put("DescriptionFamily",
							directoryItemStyleObject.getString("DescriptionFamily"));

				if (directoryItemStyleObject.getString("PhonesFont") != null)
					directoryItemChainStyleObj.put("PhonesFont", directoryItemStyleObject.getString("PhonesFont"));

				if (directoryItemStyleObject.getString("PhonesColor") != null)
					directoryItemChainStyleObj.put("PhonesColor", directoryItemStyleObject.getString("PhonesColor"));

				if (directoryItemStyleObject.getString("PhonesFamily") != null)
					directoryItemChainStyleObj.put("PhonesFamily", directoryItemStyleObject.getString("PhonesFamily"));

				if (directoryItemStyleObject.getString("TimingsFont") != null)
					directoryItemChainStyleObj.put("TimingsFont", directoryItemStyleObject.getString("TimingsFont"));

				if (directoryItemStyleObject.getString("TimingsColor") != null)
					directoryItemChainStyleObj.put("TimingsColor", directoryItemStyleObject.getString("TimingsColor"));

				if (directoryItemStyleObject.getString("TimingsFamily") != null)
					directoryItemChainStyleObj.put("TimingsFamily",
							directoryItemStyleObject.getString("TimingsFamily"));

				if (directoryItemStyleObject.getString("WebsiteFont") != null)
					directoryItemChainStyleObj.put("WebsiteFont", directoryItemStyleObject.getString("WebsiteFont"));

				if (directoryItemStyleObject.getString("WebsiteColor") != null)
					directoryItemChainStyleObj.put("WebsiteColor", directoryItemStyleObject.getString("WebsiteColor"));

				if (directoryItemStyleObject.getString("WebsiteFamily") != null)
					directoryItemChainStyleObj.put("WebsiteFamily",
							directoryItemStyleObject.getString("WebsiteFamily"));

				if (directoryItemStyleObject.getString("EmailFont") != null)
					directoryItemChainStyleObj.put("EmailFont", directoryItemStyleObject.getString("EmailFont"));

				if (directoryItemStyleObject.getString("EmailColor") != null)
					directoryItemChainStyleObj.put("EmailColor", directoryItemStyleObject.getString("EmailColor"));

				if (directoryItemStyleObject.getString("EmailFamily") != null)
					directoryItemChainStyleObj.put("EmailFamily", directoryItemStyleObject.getString("EmailFamily"));

				directoryItemChainStyleObj.put("LocationId", templateObject.getObjectId());

				try {
					directoryItemChainStyleObj.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				directoryItemObject.put("StyleId", directoryItemChainStyleObj);

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding phone Items

				ParseQuery<ParseObject> queryForPhoneObjects = ParseQuery.getQuery("Phones");
				queryForPhoneObjects.whereEqualTo("PhoneId", parseObjectOfParentDirectoryItem.getObjectId());

				List<ParseObject> listOfPhoneObjects = null;

				try {
					listOfPhoneObjects = queryForPhoneObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForPhoneObjects = listOfPhoneObjects.listIterator();

					while (iteratorForPhoneObjects.hasNext()) {

						ParseObject phoneObject = iteratorForPhoneObjects.next();

						ParseObject newPhoneObject = new ParseObject("Phones");

						if (phoneObject.getString("Ext") != null)
							newPhoneObject.put("Ext", phoneObject.getString("Ext"));
						if (phoneObject.getString("Type") != null)
							newPhoneObject.put("Type", phoneObject.getString("Type"));

						newPhoneObject.put("PhoneId", directoryItemObject.getObjectId());
						newPhoneObject.put("LocationId", templateObject.getObjectId());

						try {
							newPhoneObject.save();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				} catch (NullPointerException npe) {

				}

				checkChain(parseObjectOfParentDirectoryItem.getObjectId(), directoryItemObject,
						directoryItemObject.getObjectId(), templateObject.getObjectId());

			}

		} catch (NullPointerException npe) {

		}

		// getDataFromParse(request);

		// adminLoad(request);

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationAdmin");
		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("HotelList");
		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("HotelList");
		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("HotelList");

		return mav;
	}

	@RequestMapping(value = "/viewTemplates")
	public ModelAndView viewTemplates(HttpServletRequest request) {
		final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

		System.out.println("User:" + request.getParameter("user"));
		System.out.println("UserName:" + request.getParameter("userName"));
		System.out.println("Temp Id:" + request.getParameter("tempId"));

		mav.clear();

		ParseQuery<ParseObject> queryForLocationAdminWasEmpty = ParseQuery.getQuery("_User");
		queryForLocationAdminWasEmpty.whereEqualTo("user", "Location Admin");
		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfEmptyAdmins = null;

		try {
			listOfEmptyAdmins = queryForLocationAdminWasEmpty.find();
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));
			}

		} catch (NullPointerException npe) {

			listOfUserObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfEmptyLocationAdmins", listOfUserObjects);

		// list of admins

		ParseQuery<ParseObject> queryForAdmins = ParseQuery.getQuery("_User");
		// queryForLocationAdminWasEmpty.addAscendingOrder("username");

		if (request.getParameter("userName").equals("Super Admin")) {
			queryForAdmins.whereNotEqualTo("user", "IT Admin");
			queryForAdmins.whereNotEqualTo("user", "Super Admin");
		} else if (request.getParameter("userName").equals("CS Admin")) {
			queryForAdmins.whereNotEqualTo("user", "IT Admin");
			queryForAdmins.whereNotEqualTo("user", "Super Admin");
			queryForAdmins.whereNotEqualTo("user", "CS Admin");
		}

		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfAdmins = null;

		try {

			listOfAdmins = queryForAdmins.find();

		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfAdminObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfAdminObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));

			}

		} catch (NullPointerException npe) {

			listOfAdminObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfAdmins", listOfAdminObjects);

		ParseQuery<ParseObject> changeLocquery = ParseQuery.getQuery("Location");
		// changeLocquery.whereEqualTo("user",
		// request.getParameter("name"));
		try {
			changeLocresults = changeLocquery.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(changeLocresults);
		List<EgsdLoctionObject> changeLoc = new ArrayList<EgsdLoctionObject>(20);

		try {
			Iterator<ParseObject> changeLocIterator = changeLocresults.listIterator();
			while (changeLocIterator.hasNext()) {
				ParseObject locchange = changeLocIterator.next();

				changeLoc.add(new EgsdLoctionObject(locchange.getObjectId(), locchange.getString("Directories"),
						locchange.getString("Name"), locchange.getString("zipcode"), locchange.getString("Address1"),
						locchange.getString("Address2"), locchange.getString("Street"), locchange.getString("Town"),
						locchange.getString("GroupSiteId"), locchange.getString("GroupName"),
						locchange.getString("Country"), null, null, locchange.getString("ParentLocationID"),
						locchange.getString("description")));

			}
		} catch (NullPointerException npe) {

		}

		// System.out.println(changeLoc);
		mav.addObject("changeLoc", changeLoc);
		mav.addObject("selectLocObj", changeLoc);

		// list of Templates based on temp Id
		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
		queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>();

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);
			System.out.println(listOfEgsdTemplateObjects.toString());

		} catch (NullPointerException npe) {

		}

		// list for selecting Templates
		ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");

		// queryForSelectingTemplateObjects.whereEqualTo("objectId",
		// request.getParameter("tempId"));
		queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

		List<ParseObject> listOfSelectingTemplateObjects = null;

		try {
			listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForSelectingTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

				listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
						templateObjects.getString("Name"), null, false));

			}

			mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list of Groups
		Calendar now = Calendar.getInstance();
		System.out.println("start" + dateFormat.format(now.getTime()));
		ParseQuery<ParseObject> queryForGroupObjects = ParseQuery.getQuery("Template");

		queryForGroupObjects.whereEqualTo("type", "group");

		List<ParseObject> listOfGroupObjects = null;

		try {
			listOfGroupObjects = queryForGroupObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();

				listOfEgsdGroupObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdGroupObjects", listOfEgsdGroupObjects);
			System.out.println(listOfEgsdGroupObjects);

		} catch (NullPointerException npe) {

		}

		// this is for directory items objects

		ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
		if (request.getParameter("tempId") != null)
			queryForDirectoryItem.whereEqualTo("LocationId", request.getParameter("tempId"));

		// queryForDirectoryItem.whereEqualTo("DirectoryID",p.getString("Directories"));
		queryForDirectoryItem.orderByAscending("Title");
		queryForDirectoryItem.limit(1000);
		List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
		try {
			directoryItemParseObjectsList = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(300);
		System.out.println("Directory items are loaded:");
		try {
			Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
			System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->"
					+ "getTitle" + "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->"
					+ "getEmail" + "--->" + "getPhones");
			int count = 1;
			while (iterator.hasNext()) {

				EgsdDirectoryItemParseObject egsd = iterator.next();
				// System.out.println( count++ +" "+ egsd.getObjectId()
				// + "---> " + egsd.getDirectoryId()
				// + "--->" + egsd.getParentDirectoryId()
				// + "--->" + egsd.getTitle()
				// + "--->" + egsd.getCaption()
				// + "--->" + egsd.getTimings()
				// + "--->" + egsd.getWebsite()
				// + "--->" + egsd.getEmail()
				// + "--phoneId->" + egsd.getPhones()
				// + "--->" + egsd.getStyleID() +"<--StyleID ");
				String img = "No Image To Display";
				if (egsd.getParseFile("Picture") != null)
					img = egsd.getParseFile("Picture").getUrl();
				// System.out.print(img);
				String styleId = null;
				ParseObject StyleIdPO = egsd.getParseObject("StyleId");
				if (egsd.getParseObject("StyleId") != null)
					styleId = StyleIdPO.getObjectId();
				// System.out.println(styleId);

				/*
				 * if(StyleIdPO.getObjectId()!=null) System.out.println(
				 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
				 */

				directoryItemObjectsList.add(new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(),
						egsd.getTitle(), egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
						egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
						egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

			}
		} catch (NullPointerException npe) {

		}
		System.out.println(directoryItemObjectsList.toString());

		System.out.println("before adding dir objs");
		mav.addObject("direcObjList", directoryItemObjectsList);
		mav.addObject("subDirObj", directoryItemObjectsList);
		mav.addObject("subsubDirObj", directoryItemObjectsList);
		mav.addObject("DirObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjId", directoryItemObjectsList);
		// adding DirectiryItems for editing values
		mav.addObject("showSubDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("showDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjForNavBar", directoryItemObjectsList);
		mav.addObject("subDiscriptionObjForNavBar", directoryItemObjectsList);
		// addind directory Items for Adding DirectoryItems
		mav.addObject("locObjForAddDirectoryItems", directoryItemObjectsList);
		mav.addObject("subDiscriptionObjForAddDirItems", directoryItemObjectsList);
		mav.addObject("showSubDiscriptionObjIdForDelete", directoryItemObjectsList);

		System.out.println("aftr adding dir objs");

		System.out.println("in select b4 Phones");

		ParseQuery<ParseObject> queryForPhones = ParseQuery.getQuery("Phones");
		if (request.getParameter("tempId") != null)
			queryForPhones.whereEqualTo("LocationId", request.getParameter("tempId"));

		queryForPhones.limit(1000);
		List<ParseObject> phonesParseObjectsList = null;
		try {
			phonesParseObjectsList = queryForPhones.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdPhonesObjects> phonesObjectsList = new ArrayList<EgsdPhonesObjects>(200);
		System.out.println("Phone Objects  are loaded:");
		// System.out.println(phonesParseObjectsList);
		try {
			Iterator<ParseObject> phoneIterator = phonesParseObjectsList.listIterator();
			int i = 0;
			while (phoneIterator.hasNext()) {

				ParseObject egsdPhonePO = phoneIterator.next();

				// System.out.println(egsdPhonePO.getObjectId()
				// +"-->"+egsdPhonePO.getString("PhoneId")
				// +"-->"+egsdPhonePO.getString("Type")
				// +"-->"+egsdPhonePO.getString("Ext"));
				phonesObjectsList.add(new EgsdPhonesObjects(egsdPhonePO.getObjectId(), egsdPhonePO.getString("PhoneId"),
						egsdPhonePO.getString("Type"), egsdPhonePO.getString("Ext")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(phonesObjectsList);
		mav.addObject("phonesObjectsList", phonesObjectsList);
		mav.addObject("phonesObjectsListForEdit", phonesObjectsList);
		mav.addObject("phonesObjectsListForDelete", phonesObjectsList);

		ParseQuery<ParseObject> queryForMenu = ParseQuery.getQuery("Menu");
		List<ParseObject> menuParseObjectsList = null;
		try {
			menuParseObjectsList = queryForMenu.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdMenuObjects> menuObjectsList = new ArrayList<EgsdMenuObjects>(200);
		System.out.println("Menu Items are loaded:");
		// System.out.println(menuParseObjectsList);
		try {
			Iterator<ParseObject> menuIterator = menuParseObjectsList.listIterator();
			while (menuIterator.hasNext()) {

				ParseObject egsdMenuPO = menuIterator.next();
				// System.out.println(egsdMenuPO.getObjectId() + "---> " +
				// egsdMenuPO.getString("MenuId") + "--->"
				// + egsdMenuPO.getString("Description") + "--->" +
				// egsdMenuPO.getString("Price"));
				// System.out.println(egsdMenuPO.getParseObject("StyleID"));
				// ParseObject styleIdObj=egsdMenuPO.getParseObject("StyleID");

				ParseObject ppp = egsdMenuPO.getParseObject("StyleID");
				// System.out.println("menu o.i:
				// "+egsdMenuPO.getObjectId()+"::styleId o.i:
				// "+ppp.getObjectId());

				menuObjectsList.add(new EgsdMenuObjects(egsdMenuPO.getObjectId(), egsdMenuPO.getString("MenuId"),
						egsdMenuPO.getString("Description"), egsdMenuPO.getString("Price"), ppp.getObjectId()));
			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(menuObjectsList);
		mav.addObject("menuObjectsList", menuObjectsList);
		mav.addObject("menuObjectsListForEdit", menuObjectsList);
		mav.addObject("menuObjectsListForDelete", menuObjectsList);

		// loading StyleId objs
		ParseQuery<ParseObject> queryForStyleID = ParseQuery.getQuery("Style");
		if (request.getParameter("tempId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getParameter("tempId"));
		if (request.getAttribute("locId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getAttribute("locId"));
		queryForStyleID.limit(1000);
		List<ParseObject> styleIdObjParseObj = null;
		try {
			styleIdObjParseObj = queryForStyleID.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdStyleObjects> styleObjects = new ArrayList<EgsdStyleObjects>(200);
		try {
			Iterator<ParseObject> styleIterator = styleIdObjParseObj.listIterator();
			// System.out.println(styleIdObjParseObj);

			while (styleIterator.hasNext()) {
				ParseObject sp = styleIterator.next();
				/*
				 * System.out.println(sp.getObjectId()
				 * +"-->"+sp.getString("TitleFont")
				 * +"-->"+sp.getString("TitleColor")
				 * +"-->"+sp.getString("CaptionFont")
				 * +"-->"+sp.getString("CaptionColor")
				 * +"-->"+sp.getString("DescriptionFont")
				 * +"-->"+sp.getString("DescriptionColor")
				 * +"-->"+sp.getString("PhonesFont")
				 * +"-->"+sp.getString("PhonesColor")
				 * +"-->"+sp.getString("TimingsFont")
				 * +"-->"+sp.getString("TimingsColor")
				 * +"-->"+sp.getString("WebsiteFont")
				 * +"-->"+sp.getString("WebsiteColor")
				 * +"-->"+sp.getString("EmailFont")
				 * +"-->"+sp.getString("EmailColor")
				 * +"-->"+sp.getString("StyleID")
				 * +"-->"+sp.getString("PriceFont")
				 * +"-->"+sp.getString("PriceColor"));
				 */

				styleObjects.add(new EgsdStyleObjects(sp.getObjectId(), sp.getString("TitleFont"),
						sp.getString("TitleColor"), sp.getString("TitleFamily"), sp.getString("CaptionFont"),
						sp.getString("CaptionColor"), sp.getString("CaptionFamily"), sp.getString("DescriptionFont"),
						sp.getString("DescriptionColor"), sp.getString("DescriptionFamily"), sp.getString("PhonesFont"),
						sp.getString("PhonesColor"), sp.getString("PhonesFamily"), sp.getString("TimingsFont"),
						sp.getString("TimingsColor"), sp.getString("TimingsFamily"), sp.getString("WebsiteFont"),
						sp.getString("WebsiteColor"), sp.getString("WebsiteFamily"), sp.getString("EmailFont"),
						sp.getString("EmailColor"), sp.getString("EmailFamily"), sp.getString("StyleID"),
						sp.getString("PriceFont"), sp.getString("PriceColor"), sp.getString("PriceFamily")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(styleObjects);
		System.out.println("Style items are Loaded");
		mav.addObject("styleObjects", styleObjects);
		mav.addObject("styleObjectsForEdit", styleObjects);
		mav.addObject("styleObjectsForMenu", styleObjects);
		mav.addObject("styleObjectsForAddDirItems", styleObjects);
		mav.addObject("styleObjectsForDelete", styleObjects);

		// redirecting
		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationList");
		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdminTemplates");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdminTemplates");
		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("ITAdminTemplates");

		now = Calendar.getInstance();
		System.out.println("end " + dateFormat.format(now.getTime()));

		return mav;
	}

	@RequestMapping(value = "/viewGroups")
	public ModelAndView viewGroups(HttpServletRequest request) {

		System.out.println("User:" + request.getParameter("user"));
		System.out.println("UserName:" + request.getParameter("userName"));
		System.out.println("Temp Id:" + request.getParameter("tempId"));

		mav.clear();

		ParseQuery<ParseObject> queryForLocationAdminWasEmpty = ParseQuery.getQuery("_User");
		queryForLocationAdminWasEmpty.whereEqualTo("user", "Location Admin");
		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfEmptyAdmins = null;

		try {
			listOfEmptyAdmins = queryForLocationAdminWasEmpty.find();
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));
			}

		} catch (NullPointerException npe) {

			listOfUserObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfEmptyLocationAdmins", listOfUserObjects);

		ParseQuery<ParseObject> changeLocquery = ParseQuery.getQuery("Location");
		// changeLocquery.whereEqualTo("user",
		// request.getParameter("name"));
		try {
			changeLocresults = changeLocquery.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(changeLocresults);
		List<EgsdLoctionObject> changeLoc = new ArrayList<EgsdLoctionObject>(20);

		try {
			Iterator<ParseObject> changeLocIterator = changeLocresults.listIterator();
			while (changeLocIterator.hasNext()) {
				ParseObject locchange = changeLocIterator.next();

				changeLoc.add(new EgsdLoctionObject(locchange.getObjectId(), locchange.getString("Directories"),
						locchange.getString("Name"), locchange.getString("zipcode"), locchange.getString("Address1"),
						locchange.getString("Address2"), locchange.getString("Street"), locchange.getString("Town"),
						locchange.getString("GroupSiteId"), locchange.getString("GroupName"),
						locchange.getString("Country"), null, null, locchange.getString("ParentLocationID"),
						locchange.getString("description")));

			}
		} catch (NullPointerException npe) {

		}

		// System.out.println(changeLoc);
		mav.addObject("changeLoc", changeLoc);
		mav.addObject("selectLocObj", changeLoc);

		// list of Templates based on temp Id
		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
		queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list for selecting Templates
		ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
		// queryForSelectingTemplateObjects.whereEqualTo("objectId",
		// request.getParameter("tempId"));
		queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

		List<ParseObject> listOfSelectingTemplateObjects = null;

		try {
			listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForSelectingTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

				listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
						templateObjects.getString("Name"), null, false));

			}

			mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list of Groups
		ParseQuery<ParseObject> queryForGroupObjects = ParseQuery.getQuery("Template");

		queryForGroupObjects.whereEqualTo("type", "group");

		List<ParseObject> listOfGroupObjects = null;

		try {
			listOfGroupObjects = queryForGroupObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();

				listOfEgsdGroupObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdGroupObjects", listOfEgsdGroupObjects);

		} catch (NullPointerException npe) {

		}

		// this is for directory items objects

		ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
		if (request.getParameter("tempId") != null)
			queryForDirectoryItem.whereEqualTo("LocationId", request.getParameter("tempId"));

		// queryForDirectoryItem.whereEqualTo("DirectoryID",p.getString("Directories"));
		queryForDirectoryItem.orderByAscending("Title");
		queryForDirectoryItem.limit(1000);
		List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
		try {
			directoryItemParseObjectsList = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(300);
		System.out.println("Directory items are loaded:");
		try {
			Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
			System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->"
					+ "getTitle" + "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->"
					+ "getEmail" + "--->" + "getPhones");
			int count = 1;
			while (iterator.hasNext()) {

				EgsdDirectoryItemParseObject egsd = iterator.next();
				// System.out.println( count++ +" "+ egsd.getObjectId()
				// + "---> " + egsd.getDirectoryId()
				// + "--->" + egsd.getParentDirectoryId()
				// + "--->" + egsd.getTitle()
				// + "--->" + egsd.getCaption()
				// + "--->" + egsd.getTimings()
				// + "--->" + egsd.getWebsite()
				// + "--->" + egsd.getEmail()
				// + "--phoneId->" + egsd.getPhones()
				// + "--->" + egsd.getStyleID() +"<--StyleID ");
				String img = "No Image To Display";
				if (egsd.getParseFile("Picture") != null)
					img = egsd.getParseFile("Picture").getUrl();
				// System.out.print(img);
				String styleId = null;
				ParseObject StyleIdPO = egsd.getParseObject("StyleId");
				if (egsd.getParseObject("StyleId") != null)
					styleId = StyleIdPO.getObjectId();
				// System.out.println(styleId);

				/*
				 * if(StyleIdPO.getObjectId()!=null) System.out.println(
				 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
				 */

				directoryItemObjectsList.add(new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(),
						egsd.getTitle(), egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
						egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
						egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

			}
		} catch (NullPointerException npe) {

		}

		System.out.println("before adding dir objs");
		mav.addObject("direcObjList", directoryItemObjectsList);
		mav.addObject("subDirObj", directoryItemObjectsList);
		mav.addObject("subsubDirObj", directoryItemObjectsList);
		mav.addObject("DirObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjId", directoryItemObjectsList);
		// adding DirectiryItems for editing values
		mav.addObject("showSubDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("showDiscriptionObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjForNavBar", directoryItemObjectsList);
		mav.addObject("subDiscriptionObjForNavBar", directoryItemObjectsList);
		// addind directory Items for Adding DirectoryItems
		mav.addObject("locObjForAddDirectoryItems", directoryItemObjectsList);
		mav.addObject("subDiscriptionObjForAddDirItems", directoryItemObjectsList);
		mav.addObject("showSubDiscriptionObjIdForDelete", directoryItemObjectsList);

		System.out.println("aftr adding dir objs");

		System.out.println("in select b4 Phones");

		ParseQuery<ParseObject> queryForPhones = ParseQuery.getQuery("Phones");
		if (request.getParameter("tempId") != null)
			queryForPhones.whereEqualTo("LocationId", request.getParameter("tempId"));

		queryForPhones.limit(1000);
		List<ParseObject> phonesParseObjectsList = null;
		try {
			phonesParseObjectsList = queryForPhones.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdPhonesObjects> phonesObjectsList = new ArrayList<EgsdPhonesObjects>(200);
		System.out.println("Phone Objects  are loaded:");
		// System.out.println(phonesParseObjectsList);
		try {
			Iterator<ParseObject> phoneIterator = phonesParseObjectsList.listIterator();
			int i = 0;
			while (phoneIterator.hasNext()) {

				ParseObject egsdPhonePO = phoneIterator.next();

				// System.out.println(egsdPhonePO.getObjectId()
				// +"-->"+egsdPhonePO.getString("PhoneId")
				// +"-->"+egsdPhonePO.getString("Type")
				// +"-->"+egsdPhonePO.getString("Ext"));
				phonesObjectsList.add(new EgsdPhonesObjects(egsdPhonePO.getObjectId(), egsdPhonePO.getString("PhoneId"),
						egsdPhonePO.getString("Type"), egsdPhonePO.getString("Ext")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(phonesObjectsList);
		mav.addObject("phonesObjectsList", phonesObjectsList);
		mav.addObject("phonesObjectsListForEdit", phonesObjectsList);
		mav.addObject("phonesObjectsListForDelete", phonesObjectsList);

		ParseQuery<ParseObject> queryForMenu = ParseQuery.getQuery("Menu");
		List<ParseObject> menuParseObjectsList = null;
		try {
			menuParseObjectsList = queryForMenu.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdMenuObjects> menuObjectsList = new ArrayList<EgsdMenuObjects>(200);
		System.out.println("Menu Items are loaded:");
		// System.out.println(menuParseObjectsList);
		try {
			Iterator<ParseObject> menuIterator = menuParseObjectsList.listIterator();
			while (menuIterator.hasNext()) {

				ParseObject egsdMenuPO = menuIterator.next();
				// System.out.println(egsdMenuPO.getObjectId() + "---> " +
				// egsdMenuPO.getString("MenuId") + "--->"
				// + egsdMenuPO.getString("Description") + "--->" +
				// egsdMenuPO.getString("Price"));
				// System.out.println(egsdMenuPO.getParseObject("StyleID"));
				// ParseObject styleIdObj=egsdMenuPO.getParseObject("StyleID");

				ParseObject ppp = egsdMenuPO.getParseObject("StyleID");
				// System.out.println("menu o.i:
				// "+egsdMenuPO.getObjectId()+"::styleId o.i:
				// "+ppp.getObjectId());

				menuObjectsList.add(new EgsdMenuObjects(egsdMenuPO.getObjectId(), egsdMenuPO.getString("MenuId"),
						egsdMenuPO.getString("Description"), egsdMenuPO.getString("Price"), ppp.getObjectId()));
			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(menuObjectsList);
		mav.addObject("menuObjectsList", menuObjectsList);
		mav.addObject("menuObjectsListForEdit", menuObjectsList);
		mav.addObject("menuObjectsListForDelete", menuObjectsList);

		// loading StyleId objs
		ParseQuery<ParseObject> queryForStyleID = ParseQuery.getQuery("Style");
		if (request.getParameter("tempId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getParameter("tempId"));
		if (request.getAttribute("locId") != null)
			queryForStyleID.whereEqualTo("LocationId", request.getAttribute("locId"));
		queryForStyleID.limit(1000);
		List<ParseObject> styleIdObjParseObj = null;
		try {
			styleIdObjParseObj = queryForStyleID.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdStyleObjects> styleObjects = new ArrayList<EgsdStyleObjects>(200);
		try {
			Iterator<ParseObject> styleIterator = styleIdObjParseObj.listIterator();
			// System.out.println(styleIdObjParseObj);

			while (styleIterator.hasNext()) {
				ParseObject sp = styleIterator.next();
				/*
				 * System.out.println(sp.getObjectId()
				 * +"-->"+sp.getString("TitleFont")
				 * +"-->"+sp.getString("TitleColor")
				 * +"-->"+sp.getString("CaptionFont")
				 * +"-->"+sp.getString("CaptionColor")
				 * +"-->"+sp.getString("DescriptionFont")
				 * +"-->"+sp.getString("DescriptionColor")
				 * +"-->"+sp.getString("PhonesFont")
				 * +"-->"+sp.getString("PhonesColor")
				 * +"-->"+sp.getString("TimingsFont")
				 * +"-->"+sp.getString("TimingsColor")
				 * +"-->"+sp.getString("WebsiteFont")
				 * +"-->"+sp.getString("WebsiteColor")
				 * +"-->"+sp.getString("EmailFont")
				 * +"-->"+sp.getString("EmailColor")
				 * +"-->"+sp.getString("StyleID")
				 * +"-->"+sp.getString("PriceFont")
				 * +"-->"+sp.getString("PriceColor"));
				 */

				styleObjects.add(new EgsdStyleObjects(sp.getObjectId(), sp.getString("TitleFont"),
						sp.getString("TitleColor"), sp.getString("TitleFamily"), sp.getString("CaptionFont"),
						sp.getString("CaptionColor"), sp.getString("CaptionFamily"), sp.getString("DescriptionFont"),
						sp.getString("DescriptionColor"), sp.getString("DescriptionFamily"), sp.getString("PhonesFont"),
						sp.getString("PhonesColor"), sp.getString("PhonesFamily"), sp.getString("TimingsFont"),
						sp.getString("TimingsColor"), sp.getString("TimingsFamily"), sp.getString("WebsiteFont"),
						sp.getString("WebsiteColor"), sp.getString("WebsiteFamily"), sp.getString("EmailFont"),
						sp.getString("EmailColor"), sp.getString("EmailFamily"), sp.getString("StyleID"),
						sp.getString("PriceFont"), sp.getString("PriceColor"), sp.getString("PriceFamily")));

			}
		} catch (NullPointerException npe) {

		}
		// System.out.println(styleObjects);
		System.out.println("Style items are Loaded");
		mav.addObject("styleObjects", styleObjects);
		mav.addObject("styleObjectsForEdit", styleObjects);
		mav.addObject("styleObjectsForMenu", styleObjects);
		mav.addObject("styleObjectsForAddDirItems", styleObjects);
		mav.addObject("styleObjectsForDelete", styleObjects);

		// redirecting
		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationList");
		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdminGroups");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdminGroups");
		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("ITAdminGroups");

		return mav;
	}

	@RequestMapping(value = "/templates")
	public ModelAndView templates(HttpServletRequest request) {

		System.out.println("User:" + request.getParameter("user"));
		System.out.println("UserName:" + request.getParameter("userName"));

		// displayTemplates(request.getParameter("userName"),
		// request.getParameter("user"));

		// getDataFromParse(request);
		loadtemplates(request);

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationList");

		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdminTemplates");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdminTemplates");
		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("SuperAdminTemplates");

		return mav;
	}

	public static void loadtemplates(HttpServletRequest request) {

		mav.clear();

		ParseQuery<ParseObject> queryForLocationAdminWasEmpty = ParseQuery.getQuery("_User");
		queryForLocationAdminWasEmpty.whereEqualTo("user", "Location Admin");
		// queryForLocationAdminWasEmpty.whereEqualTo("locationId", "empty");

		List<ParseObject> listOfEmptyAdmins = null;

		try {
			listOfEmptyAdmins = queryForLocationAdminWasEmpty.find();
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		List<EgsdUserObjects> listOfUserObjects = new ArrayList<EgsdUserObjects>(100);

		try {
			Iterator<ParseObject> iteratorForEmptyAdmins = listOfEmptyAdmins.listIterator();

			while (iteratorForEmptyAdmins.hasNext()) {

				ParseObject parseObjectHavingEmptyAdmins = iteratorForEmptyAdmins.next();

				listOfUserObjects.add(new EgsdUserObjects(parseObjectHavingEmptyAdmins.getObjectId(),
						parseObjectHavingEmptyAdmins.getString("username"), null,
						parseObjectHavingEmptyAdmins.getString("email"), parseObjectHavingEmptyAdmins.getString("user"),
						parseObjectHavingEmptyAdmins.getString("locationId"),
						parseObjectHavingEmptyAdmins.getString("firstname"),
						parseObjectHavingEmptyAdmins.getString("lastname")));
			}

		} catch (NullPointerException npe) {

			listOfUserObjects
					.add(new EgsdUserObjects("empty", "Please Add Location Admin", null, null, null, null, null, null));

		}

		mav.addObject("listOfEmptyLocationAdmins", listOfUserObjects);

		// list of Templates
		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
		queryForTemplateObjects.whereNotEqualTo("type", "group");

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

		} catch (NullPointerException npe) {

		}

		// list of Groups
		ParseQuery<ParseObject> queryForGroupObjects = ParseQuery.getQuery("Template");

		queryForGroupObjects.whereEqualTo("type", "group");

		List<ParseObject> listOfGroupObjects = null;

		try {
			listOfGroupObjects = queryForGroupObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();

				listOfEgsdGroupObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdGroupObjects", listOfEgsdGroupObjects);

		} catch (NullPointerException npe) {

		}

	}

	@RequestMapping(value = "/hotels")
	public ModelAndView hotels(HttpServletRequest request) {

		System.out.println("User:" + request.getParameter("user"));
		System.out.println("UserName:" + request.getParameter("userName"));

		// displayTemplates(request.getParameter("userName"),
		// request.getParameter("user"));

		// getDataFromParse(request);

		adminLoad(request);

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationList");

		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdmin");

		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdmin");

		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("ITAdmin");

		return mav;
	}

	public void displayTemplates(String UserName, String user) {

		mav.clear();

		ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");

		List<ParseObject> listOfTemplateObjects = null;

		try {
			listOfTemplateObjects = queryForTemplateObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
			List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

			while (iteratorForTemplateObjects.hasNext()) {

				ParseObject templateObjects = iteratorForTemplateObjects.next();

				listOfEgsdTemplateObjects
						.add(new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
								templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

			}

			mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);
			mav.addObject("listOfEgsdTemplateObjectsForAddDirectoryItems", listOfEgsdTemplateObjects);

		} catch (NullPointerException npe) {

		}

		/*
		 * ParseQuery<ParseObject>
		 * queryForDirectory=ParseQuery.getQuery("DirectoryItem");
		 * queryForDirectory.limit(1000);
		 * 
		 * List<ParseObject> listOfDirectoryItems=null;
		 * 
		 * try { listOfDirectoryItems=queryForDirectory.find(); } catch
		 * (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 * 
		 * try{ List<EgsdDirectoryItemObjects> listOfEgsdDirectoryItems=new
		 * ArrayList<EgsdDirectoryItemObjects>(); Iterator<ParseObject>
		 * iteratorForDirectoryItem=listOfDirectoryItems.listIterator();
		 * while(iteratorForDirectoryItem.hasNext()){
		 * 
		 * ParseObject
		 * parseObjectForDirectoryItems=iteratorForDirectoryItem.next();
		 * 
		 * 
		 * 
		 * 
		 * }
		 */

		// HttpServletRequest request=null;

		// getDataFromParse(request);

		/*
		 * }catch(NullPointerException npe){
		 * 
		 * }
		 */

	}

	@RequestMapping(value = "/addChainLocation", headers = "content-type=multipart/*")
	public ModelAndView addChainLocation(MultipartHttpServletRequest request) throws WriterException, IOException {

		System.out.println(request.getParameter("chainId"));

		System.out.println(request.getParameter("Name"));
		System.out.println(request.getParameter("Address1"));
		System.out.println(request.getParameter("Address2"));
		System.out.println(request.getParameter("Street"));
		System.out.println(request.getParameter("Town"));
		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("zipcode"));

		ParseObject locationObject = new ParseObject("Location");

		locationObject.put("ParentLocationID", request.getParameter("chainId"));

		locationObject.put("Name", request.getParameter("Name"));
		locationObject.put("Address1", request.getParameter("Address1"));
		locationObject.put("Address2", request.getParameter("Address2"));
		locationObject.put("Street", request.getParameter("Street"));
		locationObject.put("Town", request.getParameter("Town"));
		locationObject.put("zipcode", request.getParameter("zipcode"));
		// locationObject.put("ParentLocationID",
		// request.getParameter("chainId"));
		// locationObject.put("", r);

		try {
			locationObject.save();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// addding directories
		locationObject.put("Directories", locationObject.getObjectId());

		try {
			locationObject.save();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		ParseQuery<ParseObject> queryDirectoryItemObjects = ParseQuery.getQuery("DirectoryItem");
		queryDirectoryItemObjects.whereEqualTo("DirectoryID", request.getParameter("chainId"));

		List<ParseObject> listOfParentDirectoryItems = null;

		try {
			listOfParentDirectoryItems = queryDirectoryItemObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Iterator<ParseObject> iteratorOfParentDirectoryItems = listOfParentDirectoryItems.listIterator();

		while (iteratorOfParentDirectoryItems.hasNext()) {

			ParseObject parseObjectOfParentDirectoryItem = iteratorOfParentDirectoryItems.next();

			System.out.println(parseObjectOfParentDirectoryItem.getString("Title"));

			ParseObject directoryItemObject = new ParseObject("DirectoryItem");

			if (parseObjectOfParentDirectoryItem.getString("Title") != null)
				directoryItemObject.put("Title", parseObjectOfParentDirectoryItem.getString("Title"));
			if (parseObjectOfParentDirectoryItem.getString("Caption") != null)
				directoryItemObject.put("Caption", parseObjectOfParentDirectoryItem.getString("Caption"));
			if (parseObjectOfParentDirectoryItem.getString("Description") != null)
				directoryItemObject.put("Description", parseObjectOfParentDirectoryItem.getString("Description"));
			if (parseObjectOfParentDirectoryItem.getString("Timings") != null)
				directoryItemObject.put("Timings", parseObjectOfParentDirectoryItem.getString("Timings"));
			if (parseObjectOfParentDirectoryItem.getString("Website") != null)
				directoryItemObject.put("Website", parseObjectOfParentDirectoryItem.getString("Website"));
			if (parseObjectOfParentDirectoryItem.getString("Email") != null)
				directoryItemObject.put("Email", parseObjectOfParentDirectoryItem.getString("Email"));

			if (parseObjectOfParentDirectoryItem.getParseObject("Picture") != null)
				directoryItemObject.put("Picture", parseObjectOfParentDirectoryItem.getParseObject("Picture"));

			directoryItemObject.put("LocationId", locationObject.getObjectId());
			directoryItemObject.put("DirectoryID", locationObject.getObjectId());

			try {
				directoryItemObject.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// adding styles to chain directory Items

			ParseQuery<ParseObject> queryForStyleObjects = ParseQuery.getQuery("Style");
			queryForStyleObjects.whereEqualTo("objectId",
					parseObjectOfParentDirectoryItem.getParseObject("StyleId").getObjectId());

			List<ParseObject> listOfDirectoryItemStyleObject = null;

			try {
				listOfDirectoryItemStyleObject = queryForStyleObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Iterator<ParseObject> iteratorForDirectoryItemStyleObject = listOfDirectoryItemStyleObject.listIterator();

			ParseObject directoryItemStyleObject = iteratorForDirectoryItemStyleObject.next();

			ParseObject directoryItemChainStyleObj = new ParseObject("Style");

			if (directoryItemStyleObject.getString("TitleFont") != null)
				directoryItemChainStyleObj.put("TitleFont", directoryItemStyleObject.getString("TitleFont"));

			if (directoryItemStyleObject.getString("TitleColor") != null)
				directoryItemChainStyleObj.put("TitleColor", directoryItemStyleObject.getString("TitleColor"));

			if (directoryItemStyleObject.getString("TitleFamily") != null)
				directoryItemChainStyleObj.put("TitleFamily", directoryItemStyleObject.getString("TitleFamily"));

			if (directoryItemStyleObject.getString("CaptionFont") != null)
				directoryItemChainStyleObj.put("CaptionFont", directoryItemStyleObject.getString("CaptionFont"));

			if (directoryItemStyleObject.getString("CaptionColor") != null)
				directoryItemChainStyleObj.put("CaptionColor", directoryItemStyleObject.getString("CaptionColor"));

			if (directoryItemStyleObject.getString("CaptionFamily") != null)
				directoryItemChainStyleObj.put("CaptionFamily", directoryItemStyleObject.getString("CaptionFamily"));

			if (directoryItemStyleObject.getString("DescriptionFont") != null)
				directoryItemChainStyleObj.put("DescriptionFont",
						directoryItemStyleObject.getString("DescriptionFont"));

			if (directoryItemStyleObject.getString("DescriptionColor") != null)
				directoryItemChainStyleObj.put("DescriptionColor",
						directoryItemStyleObject.getString("DescriptionColor"));

			if (directoryItemStyleObject.getString("DescriptionFamily") != null)
				directoryItemChainStyleObj.put("DescriptionFamily",
						directoryItemStyleObject.getString("DescriptionFamily"));

			if (directoryItemStyleObject.getString("PhonesFont") != null)
				directoryItemChainStyleObj.put("PhonesFont", directoryItemStyleObject.getString("PhonesFont"));

			if (directoryItemStyleObject.getString("PhonesColor") != null)
				directoryItemChainStyleObj.put("PhonesColor", directoryItemStyleObject.getString("PhonesColor"));

			if (directoryItemStyleObject.getString("PhonesFamily") != null)
				directoryItemChainStyleObj.put("PhonesFamily", directoryItemStyleObject.getString("PhonesFamily"));

			if (directoryItemStyleObject.getString("TimingsFont") != null)
				directoryItemChainStyleObj.put("TimingsFont", directoryItemStyleObject.getString("TimingsFont"));

			if (directoryItemStyleObject.getString("TimingsColor") != null)
				directoryItemChainStyleObj.put("TimingsColor", directoryItemStyleObject.getString("TimingsColor"));

			if (directoryItemStyleObject.getString("TimingsFamily") != null)
				directoryItemChainStyleObj.put("TimingsFamily", directoryItemStyleObject.getString("TimingsFamily"));

			if (directoryItemStyleObject.getString("WebsiteFont") != null)
				directoryItemChainStyleObj.put("WebsiteFont", directoryItemStyleObject.getString("WebsiteFont"));

			if (directoryItemStyleObject.getString("WebsiteColor") != null)
				directoryItemChainStyleObj.put("WebsiteColor", directoryItemStyleObject.getString("WebsiteColor"));

			if (directoryItemStyleObject.getString("WebsiteFamily") != null)
				directoryItemChainStyleObj.put("WebsiteFamily", directoryItemStyleObject.getString("WebsiteFamily"));

			if (directoryItemStyleObject.getString("EmailFont") != null)
				directoryItemChainStyleObj.put("EmailFont", directoryItemStyleObject.getString("EmailFont"));

			if (directoryItemStyleObject.getString("EmailColor") != null)
				directoryItemChainStyleObj.put("EmailColor", directoryItemStyleObject.getString("EmailColor"));

			if (directoryItemStyleObject.getString("EmailFamily") != null)
				directoryItemChainStyleObj.put("EmailFamily", directoryItemStyleObject.getString("EmailFamily"));

			try {
				directoryItemChainStyleObj.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			directoryItemObject.put("StyleId", directoryItemChainStyleObj);

			try {
				directoryItemObject.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			checkChain(parseObjectOfParentDirectoryItem.getObjectId(), directoryItemObject,
					directoryItemObject.getObjectId(), locationObject.getObjectId());

		}

		return new ModelAndView("Sample");
	}

	public static void checkChain(String id, ParseObject parseObject, String DirectoryItemOjectId, String locationId) {

		// System.out.println("In checkChain");
		System.out.println(id);

		ParseQuery<ParseObject> queryToCheckChild = ParseQuery.getQuery("DirectoryItem");
		queryToCheckChild.whereEqualTo("ParentDirectoryId", id);

		List<ParseObject> listOfChildObjects = null;

		try {
			listOfChildObjects = queryToCheckChild.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForChildObjects = listOfChildObjects.listIterator();

			while (iteratorForChildObjects.hasNext()) {

				ParseObject childObject = iteratorForChildObjects.next();

				System.out.println(childObject.getString("Title") + "This is ChildIrectoryFor:" + id);

				ParseObject childDirectoryObject = new ParseObject("DirectoryItem");

				if (childDirectoryObject.getString("Title") != null || childDirectoryObject.getString("Title") != "")
					childDirectoryObject.put("Title", childObject.getString("Title"));
				if (childDirectoryObject.getString("Description") != null
						|| childDirectoryObject.getString("Description") != "")
					childDirectoryObject.put("Description", childObject.getString("Description"));
				if (childDirectoryObject.getString("Caption") != null
						|| childDirectoryObject.getString("Caption") != "")
					childDirectoryObject.put("Caption", childObject.getString("Caption"));
				if (childDirectoryObject.getString("Timings") != null
						|| childDirectoryObject.getString("Timings") != "")
					childDirectoryObject.put("Timings", childObject.getString("Timings"));

				childDirectoryObject.put("DirectoryID", DirectoryItemOjectId);
				childDirectoryObject.put("ParentDirectoryId", DirectoryItemOjectId);
				childDirectoryObject.put("LocationId", locationId);

				try {
					childDirectoryObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				ParseQuery<ParseObject> queryForDirectoryStyleObject = ParseQuery.getQuery("Style");
				queryForDirectoryStyleObject.whereEqualTo("objectId",
						childObject.getParseObject("StyleId").getObjectId());

				List<ParseObject> listOfChildStyle = null;

				try {
					listOfChildStyle = queryForDirectoryStyleObject.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForChildStyle = listOfChildStyle.listIterator();

				ParseObject childDirectoryStyles = iteratorForChildStyle.next();

				ParseObject directoryChildStyleObject = new ParseObject("Style");

				if (childDirectoryStyles.getString("TitleFont") != null)
					directoryChildStyleObject.put("TitleFont", childDirectoryStyles.getString("TitleFont"));

				if (childDirectoryStyles.getString("TitleColor") != null)
					directoryChildStyleObject.put("TitleColor", childDirectoryStyles.getString("TitleColor"));

				if (childDirectoryStyles.getString("TitleFamily") != null)
					directoryChildStyleObject.put("TitleFamily", childDirectoryStyles.getString("TitleFamily"));

				if (childDirectoryStyles.getString("CaptionFont") != null)
					directoryChildStyleObject.put("CaptionFont", childDirectoryStyles.getString("CaptionFont"));

				if (childDirectoryStyles.getString("CaptionColor") != null)
					directoryChildStyleObject.put("CaptionColor", childDirectoryStyles.getString("CaptionColor"));

				if (childDirectoryStyles.getString("CaptionFamily") != null)
					directoryChildStyleObject.put("CaptionFamily", childDirectoryStyles.getString("CaptionFamily"));

				if (childDirectoryStyles.getString("DescriptionFont") != null)
					directoryChildStyleObject.put("DescriptionFont", childDirectoryStyles.getString("DescriptionFont"));

				if (childDirectoryStyles.getString("DescriptionColor") != null)
					directoryChildStyleObject.put("DescriptionColor",
							childDirectoryStyles.getString("DescriptionColor"));

				if (childDirectoryStyles.getString("DescriptionFamily") != null)
					directoryChildStyleObject.put("DescriptionFamily",
							childDirectoryStyles.getString("DescriptionFamily"));

				if (childDirectoryStyles.getString("PhonesFont") != null)
					directoryChildStyleObject.put("PhonesFont", childDirectoryStyles.getString("PhonesFont"));

				if (childDirectoryStyles.getString("PhonesColor") != null)
					directoryChildStyleObject.put("PhonesColor", childDirectoryStyles.getString("PhonesColor"));

				if (childDirectoryStyles.getString("PhonesFamily") != null)
					directoryChildStyleObject.put("PhonesFamily", childDirectoryStyles.getString("PhonesFamily"));

				if (childDirectoryStyles.getString("TimingsFont") != null)
					directoryChildStyleObject.put("TimingsFont", childDirectoryStyles.getString("TimingsFont"));

				if (childDirectoryStyles.getString("TimingsColor") != null)
					directoryChildStyleObject.put("TimingsColor", childDirectoryStyles.getString("TimingsColor"));

				if (childDirectoryStyles.getString("TimingsFamily") != null)
					directoryChildStyleObject.put("TimingsFamily", childDirectoryStyles.getString("TimingsFamily"));

				if (childDirectoryStyles.getString("WebsiteFont") != null)
					directoryChildStyleObject.put("WebsiteFont", childDirectoryStyles.getString("WebsiteFont"));

				if (childDirectoryStyles.getString("WebsiteColor") != null)
					directoryChildStyleObject.put("WebsiteColor", childDirectoryStyles.getString("WebsiteColor"));

				if (childDirectoryStyles.getString("WebsiteFamily") != null)
					directoryChildStyleObject.put("WebsiteFamily", childDirectoryStyles.getString("WebsiteFamily"));

				if (childDirectoryStyles.getString("EmailFont") != null)
					directoryChildStyleObject.put("EmailFont", childDirectoryStyles.getString("EmailFont"));

				if (childDirectoryStyles.getString("EmailColor") != null)
					directoryChildStyleObject.put("EmailColor", childDirectoryStyles.getString("EmailColor"));

				if (childDirectoryStyles.getString("EmailFamily") != null)
					directoryChildStyleObject.put("EmailFamily", childDirectoryStyles.getString("EmailFamily"));

				directoryChildStyleObject.put("LocationId", locationId);

				try {
					directoryChildStyleObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				childDirectoryObject.put("StyleId", directoryChildStyleObject);

				try {
					childDirectoryObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding phone Items

				ParseQuery<ParseObject> queryForPhoneObjects = ParseQuery.getQuery("Phones");
				queryForPhoneObjects.whereEqualTo("PhoneId", childObject.getObjectId());

				List<ParseObject> listOfPhoneObjects = null;

				try {
					listOfPhoneObjects = queryForPhoneObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForPhoneObjects = listOfPhoneObjects.listIterator();

					while (iteratorForPhoneObjects.hasNext()) {

						ParseObject phoneObject = iteratorForPhoneObjects.next();

						ParseObject newPhoneObject = new ParseObject("Phones");

						if (phoneObject.getString("Ext") != null)
							newPhoneObject.put("Ext", phoneObject.getString("Ext"));
						if (phoneObject.getString("Type") != null)
							newPhoneObject.put("Type", phoneObject.getString("Type"));

						newPhoneObject.put("PhoneId", childDirectoryObject.getObjectId());

						newPhoneObject.put("LocationId", locationId);

						try {
							newPhoneObject.save();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				} catch (NullPointerException npe) {

				}

				// adding menu Items

				/*
				 * ParseQuery<ParseObject>
				 * queryForMenuObjects=ParseQuery.getQuery("Menu");
				 * queryForPhoneObjects.whereEqualTo("MenuId",
				 * childObject.getObjectId());
				 * 
				 * List<ParseObject> listOfMenuObjects=null;
				 * 
				 * try { listOfMenuObjects=queryForMenuObjects.find(); } catch
				 * (ParseException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); }
				 * 
				 * 
				 * try{
				 * 
				 * Iterator<ParseObject>
				 * iteratorForMenuObjects=listOfMenuObjects.listIterator();
				 * 
				 * while(iteratorForMenuObjects.hasNext()){
				 * 
				 * ParseObject menuObject=iteratorForMenuObjects.next();
				 * 
				 * ParseObject newMenuObject=new ParseObject("Menu");
				 * 
				 * if(menuObject.getString("Description")!=null ||
				 * menuObject.getString("Description")!= "")
				 * newMenuObject.put("Description",
				 * menuObject.getString("Description"));
				 * if(menuObject.getString("Price")!=null ||
				 * menuObject.getString("Price")!= "")
				 * newMenuObject.put("Price", menuObject.getString("Price"));
				 * 
				 * newMenuObject.put("MenuId",childDirectoryObject.getObjectId()
				 * );
				 * 
				 * newMenuObject.put("LocationId",locationId );
				 * 
				 * try { newMenuObject.save(); } catch (ParseException e) { //
				 * TODO Auto-generated catch block e.printStackTrace(); }
				 * 
				 * }
				 * 
				 * 
				 * 
				 * }catch(NullPointerException npe){
				 * 
				 * 
				 * }
				 */

				// childDirectoryObject.put("DirectoryID",
				// childDirectoryObject.getString(key));

				if (childObject.getString("ParentDirectoryId") != null)
					checkChain(childObject.getObjectId(), parseObject, childDirectoryObject.getObjectId(), locationId);

			}

		} catch (NullPointerException npe) {
			// TODO: handle exception

		}

	}

	@RequestMapping(value = "/addLocation", headers = "content-type=multipart/*")
	public ModelAndView addLocation(MultipartHttpServletRequest request) throws WriterException, IOException {

		// String path=request.getServletContext().getRealPath("/");
		System.out.println(request.getParameter("Name"));
		System.out.println(request.getParameter("Address1"));
		System.out.println(request.getParameter("Address2"));
		System.out.println(request.getParameter("Street"));
		System.out.println(request.getParameter("Town"));
		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("zipcode"));
		System.out.println(request.getParameter("description"));

		// System.out.println("templateId:"+request.getParameter("templateId"));
		System.out.println("groupId :" + request.getParameter("groupId"));
		System.out.println("adminId:" + request.getParameter("adminId"));
		// System.out.println("local path:"+ request.getLocalAddr());
		// System.out.println("path info:"+request.getPathInfo());
		// System.out.println("req uri"+request.getRequestURI());
		// String url=request.getContextPath();

		// byte[] logo=request.getParameter("Logo").getBytes();
		// System.out.println(request.getParameter("Logo").getBytes().length);

		String groupname = "";
		// find of Group name
		ParseQuery<ParseObject> queryForGroupName = ParseQuery.getQuery("Template");
		queryForGroupName.orderByAscending("Name");

		queryForGroupName.whereEqualTo("objectId", request.getParameter("groupId"));

		List<ParseObject> listOfGroupName = null;

		try {
			listOfGroupName = queryForGroupName.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Iterator<ParseObject> iteratorForGroupObjects = listOfGroupName.listIterator();
			List<EgsdTemplateObjects> listOfEgsdGroupObjects = new ArrayList<EgsdTemplateObjects>(100);

			while (iteratorForGroupObjects.hasNext()) {

				ParseObject templateObjects = iteratorForGroupObjects.next();
				if (templateObjects.getString("type").equals("group")) {
					groupname = templateObjects.getString("Name");
				} else {
					groupname = "";
				}

			}

		} catch (NullPointerException npe) {
			groupname = "";
		}

		ParseFile pf = null;
		ParseFile pf1 = null;
		ParseFile pf2 = null;
		ParseObject locationObject = new ParseObject("Location");

		// locationObject.put("ParentLocationID",
		// request.getParameter("locationId"));
		// locationObject.put("GroupId", request.getParameter("locationId"));
		locationObject.put("Name", request.getParameter("Name"));
		locationObject.put("GroupSiteId", request.getParameter("siteId"));
		locationObject.put("Address1", request.getParameter("Address1"));
		locationObject.put("Address2", request.getParameter("Address2"));
		locationObject.put("Street", request.getParameter("Street"));
		locationObject.put("Town", request.getParameter("Town"));
		locationObject.put("zipcode", request.getParameter("zipcode"));
		locationObject.put("Country", request.getParameter("country"));
		// locationObject.put("description",
		// request.getParameter("description"));

		if (groupname != "") {
			locationObject.put("GroupName", groupname);
		}
		// locationObject.put("ParentLocationID",
		// request.getParameter("chainId"));
		// locationObject.put("", r);
		MultipartFile multiFile = request.getFile("logo");
		String imageType = multiFile.getContentType();
		// just to show that we have actually received the file
		try {
			System.out.println("File Length:" + multiFile.getBytes().length);
			System.out.println("File Type:" + multiFile.getContentType());
			String fileName = multiFile.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile.getBytes().length > 0) {
				pf = new ParseFile("logo.jpg", multiFile.getBytes());
				try {
					pf.save();
					locationObject.put("Logo", pf);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		MultipartFile multiFile1 = request.getFile("hotelLogo");
		String imageType1 = multiFile.getContentType();
		// just to show that we have actually received the file
		if(request.getFile("hotelLogo")!=null){
			try {
			System.out.println("File Length:" + multiFile1.getBytes().length);
			System.out.println("File Type:" + multiFile1.getContentType());
			String fileName = multiFile1.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile1.getBytes().length > 0) {
				pf1 = new ParseFile("logo.jpg", multiFile1.getBytes());
				try {
					pf1.save();
					locationObject.put("hotelLogo", pf1);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}}

		
		MultipartFile multiFile2 = request.getFile("hotelFooter");
		String imageType2 = multiFile2.getContentType();
		// just to show that we have actually received the file
		if(request.getFile("hotelFooter")!=null){		
			try {
			System.out.println("File Length:" + multiFile2.getBytes().length);
			System.out.println("File Type:" + multiFile2.getContentType());
			String fileName = multiFile2.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			if (multiFile2.getBytes().length > 0) {
				pf2 = new ParseFile("logo.jpg", multiFile2.getBytes());
				try {
					pf2.save();
					locationObject.put("footerImage", pf2);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}}

			}
		 catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		try {
			locationObject.save();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		GenerateQRCode qrcode = new GenerateQRCode();
		byte[] res = null;
		try {
			res = qrcode.qrCode(locationObject.getObjectId());
		} catch (WriterException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		pf = new ParseFile("logo.jpg", res);
		System.out.println(res.length);
		try {
			pf.save();
			locationObject.put("QRCode", pf);
			locationObject.put("Directories", locationObject.getObjectId());
			locationObject.put("GroupId", request.getParameter("adminId"));
			locationObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ParseQuery<ParseObject> queryDefaultDirectoryItemObjects = ParseQuery.getQuery("DirectoryItem");
		if (request.getParameter("groupId") != null)
			queryDefaultDirectoryItemObjects.whereEqualTo("DirectoryID", request.getParameter("groupId"));

		List<ParseObject> listOfDefaultDirectoryItems = null;

		try {
			listOfDefaultDirectoryItems = queryDefaultDirectoryItemObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForDefaultDirectoryItems = listOfDefaultDirectoryItems.listIterator();

			while (iteratorForDefaultDirectoryItems.hasNext()) {

				ParseObject parseObjectOfParentDirectoryItem = iteratorForDefaultDirectoryItems.next();

				System.out.println(parseObjectOfParentDirectoryItem.getString("Title"));

				ParseObject directoryItemObject = new ParseObject("DirectoryItem");

				if (parseObjectOfParentDirectoryItem.getString("Title") != null)
					directoryItemObject.put("Title", parseObjectOfParentDirectoryItem.getString("Title"));
				if (parseObjectOfParentDirectoryItem.getString("Caption") != null)
					directoryItemObject.put("Caption", parseObjectOfParentDirectoryItem.getString("Caption"));
				if (parseObjectOfParentDirectoryItem.getString("Description") != null)
					directoryItemObject.put("Description", parseObjectOfParentDirectoryItem.getString("Description"));
				if (parseObjectOfParentDirectoryItem.getString("Timings") != null)
					directoryItemObject.put("Timings", parseObjectOfParentDirectoryItem.getString("Timings"));

				if (parseObjectOfParentDirectoryItem.getParseObject("Picture") != null)
					directoryItemObject.put("Picture", parseObjectOfParentDirectoryItem.getParseObject("Picture"));

				directoryItemObject.put("ParentReferrence", locationObject.getObjectId());
				directoryItemObject.put("LocationId", locationObject.getObjectId());
				directoryItemObject.put("DirectoryID", locationObject.getObjectId());

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding styles to chain directory Items

				ParseQuery<ParseObject> queryForStyleObjects = ParseQuery.getQuery("Style");
				queryForStyleObjects.whereEqualTo("objectId",
						parseObjectOfParentDirectoryItem.getParseObject("StyleId").getObjectId());

				List<ParseObject> listOfDirectoryItemStyleObject = null;

				try {
					listOfDirectoryItemStyleObject = queryForStyleObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForDirectoryItemStyleObject = listOfDirectoryItemStyleObject
						.listIterator();

				ParseObject directoryItemStyleObject = iteratorForDirectoryItemStyleObject.next();

				ParseObject directoryItemChainStyleObj = new ParseObject("Style");

				if (directoryItemStyleObject.getString("TitleFont") != null)
					directoryItemChainStyleObj.put("TitleFont", directoryItemStyleObject.getString("TitleFont"));
				if (directoryItemStyleObject.getString("TitleColor") != null)
					directoryItemChainStyleObj.put("TitleColor", directoryItemStyleObject.getString("TitleColor"));
				if (directoryItemStyleObject.getString("CaptionFont") != null)
					directoryItemChainStyleObj.put("CaptionFont", directoryItemStyleObject.getString("CaptionFont"));
				if (directoryItemStyleObject.getString("CaptionColor") != null)
					directoryItemChainStyleObj.put("CaptionColor", directoryItemStyleObject.getString("CaptionColor"));
				if (directoryItemStyleObject.getString("DescriptionFont") != null)
					directoryItemChainStyleObj.put("DescriptionFont",
							directoryItemStyleObject.getString("DescriptionFont"));
				if (directoryItemStyleObject.getString("DescriptionColor") != null)
					directoryItemChainStyleObj.put("DescriptionColor",
							directoryItemStyleObject.getString("DescriptionColor"));

				if (directoryItemStyleObject.getString("TimingsFont") != null)
					directoryItemChainStyleObj.put("TimingsFont", directoryItemStyleObject.getString("TimingsFont"));
				if (directoryItemStyleObject.getString("TimingsColor") != null)
					directoryItemChainStyleObj.put("TimingsColor", directoryItemStyleObject.getString("TimingsColor"));

				directoryItemChainStyleObj.put("LocationId", locationObject.getObjectId());

				try {
					directoryItemChainStyleObj.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				directoryItemObject.put("StyleId", directoryItemChainStyleObj);

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				checkChain(parseObjectOfParentDirectoryItem.getObjectId(), directoryItemObject,
						directoryItemObject.getObjectId(), locationObject.getObjectId());

			}

		} catch (NullPointerException npe) {

		}

		// cloud code

		HashMap<String, String> params = new HashMap<String, String>();
		params.put("adminId", request.getParameter("adminId"));
		params.put("locationId", locationObject.getObjectId());

		String result = null;

		try {
			result = ParseCloud.callFunction("addingLocationId", params);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			result = "there is error in adding location id";
			e.printStackTrace();
		}

		// redirecting to home page
		request.setAttribute("locId", request.getParameter("locId"));

		try {
			select(request);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));
		System.out.println(request.getParameter("tempId"));
		if (request.getParameter("tempId") != null) {
			System.out.println(request.getParameter("tempId"));
			ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
			queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

			List<ParseObject> listOfTemplateObjects = null;

			try {
				listOfTemplateObjects = queryForTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
				List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForTemplateObjects.next();

					listOfEgsdTemplateObjects.add(
							new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
									templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

				}

				mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

			} catch (NullPointerException npe) {

			}

			// list for selecting Templates
			ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
			// queryForSelectingTemplateObjects.whereEqualTo("objectId",
			// request.getParameter("tempId"));
			queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

			List<ParseObject> listOfSelectingTemplateObjects = null;

			try {
				listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
						.listIterator();
				List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForSelectingTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

					listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
							templateObjects.getString("Name"), null, false));

				}

				mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

			} catch (NullPointerException npe) {

			}
			if (request.getParameter("userName").equals("Super Admin"))
				mav.setViewName("SuperAdminTemplates");

			if (request.getParameter("userName").equals("IT Admin"))
				mav.setViewName("ITAdminTemplates");

			if (request.getParameter("userName").equals("CS Admin"))
				mav.setViewName("CSAdminTemplates");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}
		if (request.getParameter("locId") != null) {
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
			try {
				select(request);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (request.getParameter("userName").equals("Location Admin")) {
				mav.setViewName("LocationAdmin");
			}
			if (request.getParameter("userName").equals("CS Admin")) {
				mav.setViewName("CSAdmin");
			}
			if (request.getParameter("userName").equals("Super Admin")) {
				mav.setViewName("SuperAdmin");
			}
			if (request.getParameter("userName").equals("IT Admin")) {
				mav.setViewName("ITAdmin");
			}
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}

		else {
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
			adminLoad(request);
			if (request.getParameter("userName").equals("CS Admin")) {
				mav.setViewName("CSHotelList");
			}
			if (request.getParameter("userName").equals("Super Admin")) {
				mav.setViewName("SuperHotelList");
			}
			if (request.getParameter("userName").equals("IT Admin")) {
				mav.setViewName("ITHotelList");
			}
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}
		}
		return mav;
	}

	@RequestMapping(value = "/defaultTemplate")
	public ModelAndView editDefault(HttpServletRequest request) {

		System.out.println(request.getParameter("user"));
		System.out.println(request.getParameter("userName"));

		// mav.clear();
		getDataFromParse(request);

		ParseQuery<ParseObject> queryForDefaultItemsAtLocation = ParseQuery.getQuery("Template");
		queryForDefaultItemsAtLocation.whereEqualTo("Customized", false);

		List<ParseObject> listOfDefaultItemsInTemplate = null;

		try {
			listOfDefaultItemsInTemplate = queryForDefaultItemsAtLocation.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String locationIdForDefaultTemplate = "";
		List<EgsdTemplateObjects> listOfLocationObjects = new ArrayList<EgsdTemplateObjects>(25);
		try {

			Iterator<ParseObject> iteratorForDefaultItemsAtLocation = listOfDefaultItemsInTemplate.listIterator();

			while (iteratorForDefaultItemsAtLocation.hasNext()) {

				ParseObject defaultTemplateObject = iteratorForDefaultItemsAtLocation.next();

				locationIdForDefaultTemplate = defaultTemplateObject.getObjectId();
				listOfLocationObjects.add(new EgsdTemplateObjects(defaultTemplateObject.getObjectId(),
						defaultTemplateObject.getString("Name"), defaultTemplateObject.getObjectId(),
						defaultTemplateObject.getBoolean("Customized")));

			}

		} catch (NullPointerException npe) {

		}

		mav.addObject("defaultTemplateLocationObject", listOfLocationObjects);

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		mav.setViewName("SuperTemplates");

		return mav;

	}

	// manage contactInfo

	@RequestMapping(value = "/manageDetails", method = RequestMethod.POST)
	public ModelAndView manageContactInfo(HttpServletRequest request) {

		String manageCount = request.getParameter("manageCount");

		int count = Integer.parseInt(manageCount);

		for (int i = 1; i < count; i++) {
			System.out
					.println(request.getParameter("manageType" + i) + " " + request.getParameter("manageDetails" + i));

			/*
			 * ParseObject contactObject=new ParseObject("Phones");
			 * 
			 * if(request.getParameter("manageType"+i) != null )
			 * contactObject.put("Type", request.getParameter("manageType"+i));
			 * if(request.getParameter("manageDetails"+i) != null )
			 * contactObject.put("Ext",
			 * request.getParameter("manageDetails"+i));
			 * if(request.getParameter("manageDetails"+i) != null ||
			 * request.getParameter("manageType"+i) != null)
			 * contactObject.put("PhoneId", request.getParameter("phoneId"));
			 * contactObject.put("LocationId",
			 * request.getParameter("locationId")); try { contactObject.save();
			 * } catch (ParseException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); }
			 */

		}

		return mav;

	}

	// adding chain hotel

	@RequestMapping(value = "/addChainHotel", method = RequestMethod.POST)
	public ModelAndView addChainHotel(HttpServletRequest request) {

		System.out.println("groupId:" + request.getParameter("groupId"));
		System.out.println("locationId:" + request.getParameter("locationId"));
		System.out.println("User:" + request.getParameter("user"));
		System.out.println("User Name:" + request.getParameter("userName"));

		// adding Location
		ParseFile pf = null;

		ParseObject locationObject = new ParseObject("Location");

		locationObject.put("ParentLocationID", request.getParameter("locationId"));
		locationObject.put("GroupId", request.getParameter("locationId"));
		locationObject.put("Name", request.getParameter("Name"));
		locationObject.put("Address1", request.getParameter("Address1"));
		locationObject.put("Address2", request.getParameter("Address2"));
		locationObject.put("Street", request.getParameter("Street"));
		locationObject.put("Town", request.getParameter("Town"));
		locationObject.put("zipcode", request.getParameter("zipcode"));
		// locationObject.put("ParentLocationID",
		// request.getParameter("chainId"));
		// locationObject.put("", r);

		try {
			locationObject.save();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		GenerateQRCode qrcode = new GenerateQRCode();
		byte[] res = null;
		try {
			res = qrcode.qrCode(locationObject.getObjectId());
		} catch (WriterException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		pf = new ParseFile("logo.jpg", res);
		System.out.println(res.length);
		try {
			pf.save();
			locationObject.put("QRCode", pf);
			locationObject.put("Directories", locationObject.getObjectId());
			locationObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ParseQuery<ParseObject> queryDefaultDirectoryItemObjects = ParseQuery.getQuery("DirectoryItem");
		queryDefaultDirectoryItemObjects.whereEqualTo("DirectoryID", request.getParameter("groupId"));

		List<ParseObject> listOfDefaultDirectoryItems = null;

		try {
			listOfDefaultDirectoryItems = queryDefaultDirectoryItemObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForDefaultDirectoryItems = listOfDefaultDirectoryItems.listIterator();

			while (iteratorForDefaultDirectoryItems.hasNext()) {

				ParseObject parseObjectOfParentDirectoryItem = iteratorForDefaultDirectoryItems.next();

				System.out.println(parseObjectOfParentDirectoryItem.getString("Title"));

				ParseObject directoryItemObject = new ParseObject("DirectoryItem");

				if (parseObjectOfParentDirectoryItem.getString("Title") != null)
					directoryItemObject.put("Title", parseObjectOfParentDirectoryItem.getString("Title"));
				if (parseObjectOfParentDirectoryItem.getString("Caption") != null)
					directoryItemObject.put("Caption", parseObjectOfParentDirectoryItem.getString("Caption"));
				if (parseObjectOfParentDirectoryItem.getString("Description") != null)
					directoryItemObject.put("Description", parseObjectOfParentDirectoryItem.getString("Description"));
				if (parseObjectOfParentDirectoryItem.getString("Timings") != null)
					directoryItemObject.put("Timings", parseObjectOfParentDirectoryItem.getString("Timings"));
				if (parseObjectOfParentDirectoryItem.getString("Website") != null)
					directoryItemObject.put("Website", parseObjectOfParentDirectoryItem.getString("Website"));
				if (parseObjectOfParentDirectoryItem.getString("Email") != null)
					directoryItemObject.put("Email", parseObjectOfParentDirectoryItem.getString("Email"));

				if (parseObjectOfParentDirectoryItem.getParseObject("Picture") != null)
					directoryItemObject.put("Picture", parseObjectOfParentDirectoryItem.getParseObject("Picture"));

				directoryItemObject.put("LocationId", locationObject.getObjectId());
				directoryItemObject.put("DirectoryID", locationObject.getObjectId());

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding styles to chain directory Items

				ParseQuery<ParseObject> queryForStyleObjects = ParseQuery.getQuery("Style");
				queryForStyleObjects.whereEqualTo("objectId",
						parseObjectOfParentDirectoryItem.getParseObject("StyleId").getObjectId());

				List<ParseObject> listOfDirectoryItemStyleObject = null;

				try {
					listOfDirectoryItemStyleObject = queryForStyleObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForDirectoryItemStyleObject = listOfDirectoryItemStyleObject
						.listIterator();

				ParseObject directoryItemStyleObject = iteratorForDirectoryItemStyleObject.next();

				ParseObject directoryItemChainStyleObj = new ParseObject("Style");

				if (directoryItemStyleObject.getString("TitleFont") != null)
					directoryItemChainStyleObj.put("TitleFont", directoryItemStyleObject.getString("TitleFont"));
				if (directoryItemStyleObject.getString("TitleColor") != null)
					directoryItemChainStyleObj.put("TitleColor", directoryItemStyleObject.getString("TitleColor"));
				if (directoryItemStyleObject.getString("CaptionFont") != null)
					directoryItemChainStyleObj.put("CaptionFont", directoryItemStyleObject.getString("CaptionFont"));
				if (directoryItemStyleObject.getString("CaptionColor") != null)
					directoryItemChainStyleObj.put("CaptionColor", directoryItemStyleObject.getString("CaptionColor"));
				if (directoryItemStyleObject.getString("DescriptionFont") != null)
					directoryItemChainStyleObj.put("DescriptionFont",
							directoryItemStyleObject.getString("DescriptionFont"));
				if (directoryItemStyleObject.getString("DescriptionColor") != null)
					directoryItemChainStyleObj.put("DescriptionColor",
							directoryItemStyleObject.getString("DescriptionColor"));
				if (directoryItemStyleObject.getString("PhonesFont") != null)
					directoryItemChainStyleObj.put("PhonesFont", directoryItemStyleObject.getString("PhonesFont"));
				if (directoryItemStyleObject.getString("PhonesColor") != null)
					directoryItemChainStyleObj.put("PhonesColor", directoryItemStyleObject.getString("PhonesColor"));
				if (directoryItemStyleObject.getString("TimingsFont") != null)
					directoryItemChainStyleObj.put("TimingsFont", directoryItemStyleObject.getString("TimingsFont"));
				if (directoryItemStyleObject.getString("TimingsColor") != null)
					directoryItemChainStyleObj.put("TimingsColor", directoryItemStyleObject.getString("TimingsColor"));
				if (directoryItemStyleObject.getString("WebsiteFont") != null)
					directoryItemChainStyleObj.put("WebsiteFont", directoryItemStyleObject.getString("WebsiteFont"));
				if (directoryItemStyleObject.getString("WebsiteColor") != null)
					directoryItemChainStyleObj.put("WebsiteColor", directoryItemStyleObject.getString("WebsiteColor"));
				if (directoryItemStyleObject.getString("EmailFont") != null)
					directoryItemChainStyleObj.put("EmailFont", directoryItemStyleObject.getString("EmailFont"));
				if (directoryItemStyleObject.getString("EmailColor") != null)
					directoryItemChainStyleObj.put("EmailColor", directoryItemStyleObject.getString("EmailColor"));

				directoryItemChainStyleObj.put("LocationId", locationObject.getObjectId());

				try {
					directoryItemChainStyleObj.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				directoryItemObject.put("StyleId", directoryItemChainStyleObj);

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding phone Items

				ParseQuery<ParseObject> queryForPhoneObjects = ParseQuery.getQuery("Phones");
				queryForPhoneObjects.whereEqualTo("PhoneId", parseObjectOfParentDirectoryItem.getObjectId());

				List<ParseObject> listOfPhoneObjects = null;

				try {
					listOfPhoneObjects = queryForPhoneObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForPhoneObjects = listOfPhoneObjects.listIterator();

					while (iteratorForPhoneObjects.hasNext()) {

						ParseObject phoneObject = iteratorForPhoneObjects.next();

						ParseObject newPhoneObject = new ParseObject("Phones");

						if (phoneObject.getString("Ext") != null)
							newPhoneObject.put("Ext", phoneObject.getString("Ext"));
						if (phoneObject.getString("Type") != null)
							newPhoneObject.put("Type", phoneObject.getString("Type"));

						newPhoneObject.put("PhoneId", directoryItemObject.getObjectId());
						newPhoneObject.put("LocationId", locationObject.getObjectId());
						try {
							newPhoneObject.save();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				} catch (NullPointerException npe) {

				}

				checkChain(parseObjectOfParentDirectoryItem.getObjectId(), directoryItemObject,
						directoryItemObject.getObjectId(), locationObject.getObjectId());

			}

		} catch (NullPointerException npe) {

		}

		// getDataFromParse(request);

		adminLoad(request);

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));

		if (request.getParameter("userName").equals("Location Admin"))
			mav.setViewName("LocationAdmin");
		if (request.getParameter("userName").equals("CS Admin"))
			mav.setViewName("CSAdmin");
		if (request.getParameter("userName").equals("Super Admin"))
			mav.setViewName("SuperAdmin");
		if (request.getParameter("userName").equals("IT Admin"))
			mav.setViewName("ITAdmin");

		return mav;
	}

	// adding group

	@RequestMapping(value = "/addGroup", method = RequestMethod.POST)
	public ModelAndView addGroup(HttpServletRequest request) {

		System.out.println("Group Name:" + request.getParameter("groupName"));
		System.out.println("Template Id:" + request.getParameter("templateId"));
		System.out.println("User:" + request.getParameter("user"));
		System.out.println("User Name:" + request.getParameter("userName"));

		// adding Template object
		ParseObject templateObject = new ParseObject("Template");

		templateObject.put("Name", request.getParameter("groupName"));
		templateObject.put("Customized", true);
		templateObject.put("type", "group");

		try {
			templateObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		templateObject.put("LocationId", templateObject.getObjectId());

		ParseQuery<ParseObject> queryDefaultDirectoryItemObjects = ParseQuery.getQuery("DirectoryItem");
		queryDefaultDirectoryItemObjects.whereEqualTo("DirectoryID", request.getParameter("templateId"));

		List<ParseObject> listOfDefaultDirectoryItems = null;

		try {
			listOfDefaultDirectoryItems = queryDefaultDirectoryItemObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForDefaultDirectoryItems = listOfDefaultDirectoryItems.listIterator();

			while (iteratorForDefaultDirectoryItems.hasNext()) {

				ParseObject parseObjectOfParentDirectoryItem = iteratorForDefaultDirectoryItems.next();

				System.out.println(parseObjectOfParentDirectoryItem.getString("Title"));

				ParseObject directoryItemObject = new ParseObject("DirectoryItem");

				if (parseObjectOfParentDirectoryItem.getString("Title") != null)
					directoryItemObject.put("Title", parseObjectOfParentDirectoryItem.getString("Title"));
				if (parseObjectOfParentDirectoryItem.getString("Caption") != null)
					directoryItemObject.put("Caption", parseObjectOfParentDirectoryItem.getString("Caption"));
				if (parseObjectOfParentDirectoryItem.getString("Description") != null)
					directoryItemObject.put("Description", parseObjectOfParentDirectoryItem.getString("Description"));
				if (parseObjectOfParentDirectoryItem.getString("Timings") != null)
					directoryItemObject.put("Timings", parseObjectOfParentDirectoryItem.getString("Timings"));
				if (parseObjectOfParentDirectoryItem.getString("Website") != null)
					directoryItemObject.put("Website", parseObjectOfParentDirectoryItem.getString("Website"));
				if (parseObjectOfParentDirectoryItem.getString("Email") != null)
					directoryItemObject.put("Email", parseObjectOfParentDirectoryItem.getString("Email"));

				if (parseObjectOfParentDirectoryItem.getParseObject("Picture") != null)
					directoryItemObject.put("Picture", parseObjectOfParentDirectoryItem.getParseObject("Picture"));

				directoryItemObject.put("LocationId", templateObject.getObjectId());
				directoryItemObject.put("DirectoryID", templateObject.getObjectId());

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding styles to chain directory Items

				ParseQuery<ParseObject> queryForStyleObjects = ParseQuery.getQuery("Style");
				queryForStyleObjects.whereEqualTo("objectId",
						parseObjectOfParentDirectoryItem.getParseObject("StyleId").getObjectId());

				List<ParseObject> listOfDirectoryItemStyleObject = null;

				try {
					listOfDirectoryItemStyleObject = queryForStyleObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForDirectoryItemStyleObject = listOfDirectoryItemStyleObject
						.listIterator();

				ParseObject directoryItemStyleObject = iteratorForDirectoryItemStyleObject.next();

				ParseObject directoryItemChainStyleObj = new ParseObject("Style");

				if (directoryItemStyleObject.getString("TitleFont") != null)
					directoryItemChainStyleObj.put("TitleFont", directoryItemStyleObject.getString("TitleFont"));
				if (directoryItemStyleObject.getString("TitleColor") != null)
					directoryItemChainStyleObj.put("TitleColor", directoryItemStyleObject.getString("TitleColor"));
				if (directoryItemStyleObject.getString("CaptionFont") != null)
					directoryItemChainStyleObj.put("CaptionFont", directoryItemStyleObject.getString("CaptionFont"));
				if (directoryItemStyleObject.getString("CaptionColor") != null)
					directoryItemChainStyleObj.put("CaptionColor", directoryItemStyleObject.getString("CaptionColor"));
				if (directoryItemStyleObject.getString("DescriptionFont") != null)
					directoryItemChainStyleObj.put("DescriptionFont",
							directoryItemStyleObject.getString("DescriptionFont"));
				if (directoryItemStyleObject.getString("DescriptionColor") != null)
					directoryItemChainStyleObj.put("DescriptionColor",
							directoryItemStyleObject.getString("DescriptionColor"));
				if (directoryItemStyleObject.getString("PhonesFont") != null)
					directoryItemChainStyleObj.put("PhonesFont", directoryItemStyleObject.getString("PhonesFont"));
				if (directoryItemStyleObject.getString("PhonesColor") != null)
					directoryItemChainStyleObj.put("PhonesColor", directoryItemStyleObject.getString("PhonesColor"));
				if (directoryItemStyleObject.getString("TimingsFont") != null)
					directoryItemChainStyleObj.put("TimingsFont", directoryItemStyleObject.getString("TimingsFont"));
				if (directoryItemStyleObject.getString("TimingsColor") != null)
					directoryItemChainStyleObj.put("TimingsColor", directoryItemStyleObject.getString("TimingsColor"));
				if (directoryItemStyleObject.getString("WebsiteFont") != null)
					directoryItemChainStyleObj.put("WebsiteFont", directoryItemStyleObject.getString("WebsiteFont"));
				if (directoryItemStyleObject.getString("WebsiteColor") != null)
					directoryItemChainStyleObj.put("WebsiteColor", directoryItemStyleObject.getString("WebsiteColor"));
				if (directoryItemStyleObject.getString("EmailFont") != null)
					directoryItemChainStyleObj.put("EmailFont", directoryItemStyleObject.getString("EmailFont"));
				if (directoryItemStyleObject.getString("EmailColor") != null)
					directoryItemChainStyleObj.put("EmailColor", directoryItemStyleObject.getString("EmailColor"));

				directoryItemChainStyleObj.put("LocationId", templateObject.getObjectId());

				try {
					directoryItemChainStyleObj.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				directoryItemObject.put("StyleId", directoryItemChainStyleObj);

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding phone Items

				ParseQuery<ParseObject> queryForPhoneObjects = ParseQuery.getQuery("Phones");
				queryForPhoneObjects.whereEqualTo("PhoneId", parseObjectOfParentDirectoryItem.getObjectId());

				List<ParseObject> listOfPhoneObjects = null;

				try {
					listOfPhoneObjects = queryForPhoneObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForPhoneObjects = listOfPhoneObjects.listIterator();

					while (iteratorForPhoneObjects.hasNext()) {

						ParseObject phoneObject = iteratorForPhoneObjects.next();

						ParseObject newPhoneObject = new ParseObject("Phones");

						if (phoneObject.getString("Ext") != null)
							newPhoneObject.put("Ext", phoneObject.getString("Ext"));
						if (phoneObject.getString("Type") != null)
							newPhoneObject.put("Type", phoneObject.getString("Type"));

						newPhoneObject.put("PhoneId", directoryItemObject.getObjectId());

						newPhoneObject.put("LocationId", templateObject.getObjectId());
						try {
							newPhoneObject.save();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				} catch (NullPointerException npe) {

				}

				checkChain(parseObjectOfParentDirectoryItem.getObjectId(), directoryItemObject,
						directoryItemObject.getObjectId(), templateObject.getObjectId());

			}

		} catch (NullPointerException npe) {

		}

		// getDataFromParse(request);
		// adminLoad(request);

		request.setAttribute("locId", request.getParameter("locId"));

		try {
			select(request);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		mav.addObject("userName", request.getParameter("userName"));
		mav.addObject("user", request.getParameter("user"));
		if (request.getParameter("locId") != null) {
			if (request.getParameter("userName").equals("Location Admin")) {
				mav.setViewName("LocationAdmin");
			}
			if (request.getParameter("userName").equals("CS Admin")) {
				mav.setViewName("CSAdmin");
			}
			if (request.getParameter("userName").equals("Super Admin")) {
				mav.setViewName("SuperAdmin");
			}
			if (request.getParameter("userName").equals("IT Admin")) {
				mav.setViewName("ITAdmin");
			}
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}
		if (request.getParameter("tempId") != null) {
			System.out.println(request.getParameter("tempId"));
			ParseQuery<ParseObject> queryForTemplateObjects = ParseQuery.getQuery("Template");
			queryForTemplateObjects.whereEqualTo("objectId", request.getParameter("tempId"));

			List<ParseObject> listOfTemplateObjects = null;

			try {
				listOfTemplateObjects = queryForTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForTemplateObjects = listOfTemplateObjects.listIterator();
				List<EgsdTemplateObjects> listOfEgsdTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForTemplateObjects.next();

					listOfEgsdTemplateObjects.add(
							new EgsdTemplateObjects(templateObjects.getObjectId(), templateObjects.getString("Name"),
									templateObjects.getObjectId(), templateObjects.getBoolean("Customized")));

				}

				mav.addObject("listOfEgsdTemplateObjects", listOfEgsdTemplateObjects);

			} catch (NullPointerException npe) {

			}

			// list for selecting Templates
			ParseQuery<ParseObject> queryForSelectingTemplateObjects = ParseQuery.getQuery("Template");
			// queryForSelectingTemplateObjects.whereEqualTo("objectId",
			// request.getParameter("tempId"));
			queryForSelectingTemplateObjects.whereNotEqualTo("type", "group");

			List<ParseObject> listOfSelectingTemplateObjects = null;

			try {
				listOfSelectingTemplateObjects = queryForSelectingTemplateObjects.find();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				Iterator<ParseObject> iteratorForSelectingTemplateObjects = listOfSelectingTemplateObjects
						.listIterator();
				List<EgsdTemplateObjects> listOfEgsdSelectedTemplateObjects = new ArrayList<EgsdTemplateObjects>(20);

				while (iteratorForSelectingTemplateObjects.hasNext()) {

					ParseObject templateObjects = iteratorForSelectingTemplateObjects.next();

					listOfEgsdSelectedTemplateObjects.add(new EgsdTemplateObjects(templateObjects.getObjectId(),
							templateObjects.getString("Name"), null, false));

				}

				mav.addObject("listOfSelectedTemplateObjects", listOfEgsdSelectedTemplateObjects);

			} catch (NullPointerException npe) {

			}
			if (request.getParameter("userName").equals("Super Admin"))
				mav.setViewName("SuperAdminTemplates");

			if (request.getParameter("userName").equals("IT Admin"))
				mav.setViewName("ITAdminTemplates");

			if (request.getParameter("userName").equals("CS Admin"))
				mav.setViewName("CSAdminTemplates");

			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}

		else {
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
			adminLoad(request);
			if (request.getParameter("userName").equals("CS Admin")) {
				mav.setViewName("CSHotelList");
			}
			if (request.getParameter("userName").equals("Super Admin")) {
				mav.setViewName("SuperHotelList");
			}
			if (request.getParameter("userName").equals("IT Admin")) {
				mav.setViewName("ITHotelList");
			}
			mav.addObject("userName", request.getParameter("userName"));
			mav.addObject("user", request.getParameter("user"));
		}

		return mav;

	}

	// adding group

	@RequestMapping(value = "/Admin/addGroupHotelList", method = RequestMethod.POST)
	public @ResponseBody String addGroupHotelList(HttpServletRequest request) {

		System.out.println("Group Name:" + request.getParameter("groupName"));
		System.out.println("Template Id:" + request.getParameter("templateId"));
		System.out.println("User:" + request.getParameter("user"));
		System.out.println("User Name:" + request.getParameter("userName"));

		// adding Template object
		ParseObject templateObject = new ParseObject("Template");

		templateObject.put("Name", request.getParameter("groupName"));
		templateObject.put("Customized", true);
		templateObject.put("type", "group");

		try {
			templateObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		templateObject.put("LocationId", templateObject.getObjectId());

		ParseQuery<ParseObject> queryDefaultDirectoryItemObjects = ParseQuery.getQuery("DirectoryItem");
		queryDefaultDirectoryItemObjects.whereEqualTo("DirectoryID", request.getParameter("templateId"));

		List<ParseObject> listOfDefaultDirectoryItems = null;

		try {
			listOfDefaultDirectoryItems = queryDefaultDirectoryItemObjects.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			Iterator<ParseObject> iteratorForDefaultDirectoryItems = listOfDefaultDirectoryItems.listIterator();

			while (iteratorForDefaultDirectoryItems.hasNext()) {

				ParseObject parseObjectOfParentDirectoryItem = iteratorForDefaultDirectoryItems.next();

				System.out.println(parseObjectOfParentDirectoryItem.getString("Title"));

				ParseObject directoryItemObject = new ParseObject("DirectoryItem");

				if (parseObjectOfParentDirectoryItem.getString("Title") != null)
					directoryItemObject.put("Title", parseObjectOfParentDirectoryItem.getString("Title"));
				if (parseObjectOfParentDirectoryItem.getString("Caption") != null)
					directoryItemObject.put("Caption", parseObjectOfParentDirectoryItem.getString("Caption"));
				if (parseObjectOfParentDirectoryItem.getString("Description") != null)
					directoryItemObject.put("Description", parseObjectOfParentDirectoryItem.getString("Description"));
				if (parseObjectOfParentDirectoryItem.getString("Timings") != null)
					directoryItemObject.put("Timings", parseObjectOfParentDirectoryItem.getString("Timings"));
				if (parseObjectOfParentDirectoryItem.getString("Website") != null)
					directoryItemObject.put("Website", parseObjectOfParentDirectoryItem.getString("Website"));
				if (parseObjectOfParentDirectoryItem.getString("Email") != null)
					directoryItemObject.put("Email", parseObjectOfParentDirectoryItem.getString("Email"));

				if (parseObjectOfParentDirectoryItem.getParseObject("Picture") != null)
					directoryItemObject.put("Picture", parseObjectOfParentDirectoryItem.getParseObject("Picture"));

				directoryItemObject.put("LocationId", templateObject.getObjectId());
				directoryItemObject.put("DirectoryID", templateObject.getObjectId());

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding styles to chain directory Items

				ParseQuery<ParseObject> queryForStyleObjects = ParseQuery.getQuery("Style");
				queryForStyleObjects.whereEqualTo("objectId",
						parseObjectOfParentDirectoryItem.getParseObject("StyleId").getObjectId());

				List<ParseObject> listOfDirectoryItemStyleObject = null;

				try {
					listOfDirectoryItemStyleObject = queryForStyleObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Iterator<ParseObject> iteratorForDirectoryItemStyleObject = listOfDirectoryItemStyleObject
						.listIterator();

				ParseObject directoryItemStyleObject = iteratorForDirectoryItemStyleObject.next();

				ParseObject directoryItemChainStyleObj = new ParseObject("Style");

				if (directoryItemStyleObject.getString("TitleFont") != null)
					directoryItemChainStyleObj.put("TitleFont", directoryItemStyleObject.getString("TitleFont"));
				if (directoryItemStyleObject.getString("TitleColor") != null)
					directoryItemChainStyleObj.put("TitleColor", directoryItemStyleObject.getString("TitleColor"));
				if (directoryItemStyleObject.getString("CaptionFont") != null)
					directoryItemChainStyleObj.put("CaptionFont", directoryItemStyleObject.getString("CaptionFont"));
				if (directoryItemStyleObject.getString("CaptionColor") != null)
					directoryItemChainStyleObj.put("CaptionColor", directoryItemStyleObject.getString("CaptionColor"));
				if (directoryItemStyleObject.getString("DescriptionFont") != null)
					directoryItemChainStyleObj.put("DescriptionFont",
							directoryItemStyleObject.getString("DescriptionFont"));
				if (directoryItemStyleObject.getString("DescriptionColor") != null)
					directoryItemChainStyleObj.put("DescriptionColor",
							directoryItemStyleObject.getString("DescriptionColor"));
				if (directoryItemStyleObject.getString("PhonesFont") != null)
					directoryItemChainStyleObj.put("PhonesFont", directoryItemStyleObject.getString("PhonesFont"));
				if (directoryItemStyleObject.getString("PhonesColor") != null)
					directoryItemChainStyleObj.put("PhonesColor", directoryItemStyleObject.getString("PhonesColor"));
				if (directoryItemStyleObject.getString("TimingsFont") != null)
					directoryItemChainStyleObj.put("TimingsFont", directoryItemStyleObject.getString("TimingsFont"));
				if (directoryItemStyleObject.getString("TimingsColor") != null)
					directoryItemChainStyleObj.put("TimingsColor", directoryItemStyleObject.getString("TimingsColor"));
				if (directoryItemStyleObject.getString("WebsiteFont") != null)
					directoryItemChainStyleObj.put("WebsiteFont", directoryItemStyleObject.getString("WebsiteFont"));
				if (directoryItemStyleObject.getString("WebsiteColor") != null)
					directoryItemChainStyleObj.put("WebsiteColor", directoryItemStyleObject.getString("WebsiteColor"));
				if (directoryItemStyleObject.getString("EmailFont") != null)
					directoryItemChainStyleObj.put("EmailFont", directoryItemStyleObject.getString("EmailFont"));
				if (directoryItemStyleObject.getString("EmailColor") != null)
					directoryItemChainStyleObj.put("EmailColor", directoryItemStyleObject.getString("EmailColor"));

				directoryItemChainStyleObj.put("LocationId", templateObject.getObjectId());

				try {
					directoryItemChainStyleObj.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				directoryItemObject.put("StyleId", directoryItemChainStyleObj);

				try {
					directoryItemObject.save();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// adding phone Items

				ParseQuery<ParseObject> queryForPhoneObjects = ParseQuery.getQuery("Phones");
				queryForPhoneObjects.whereEqualTo("PhoneId", parseObjectOfParentDirectoryItem.getObjectId());

				List<ParseObject> listOfPhoneObjects = null;

				try {
					listOfPhoneObjects = queryForPhoneObjects.find();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {

					Iterator<ParseObject> iteratorForPhoneObjects = listOfPhoneObjects.listIterator();

					while (iteratorForPhoneObjects.hasNext()) {

						ParseObject phoneObject = iteratorForPhoneObjects.next();

						ParseObject newPhoneObject = new ParseObject("Phones");

						if (phoneObject.getString("Ext") != null)
							newPhoneObject.put("Ext", phoneObject.getString("Ext"));
						if (phoneObject.getString("Type") != null)
							newPhoneObject.put("Type", phoneObject.getString("Type"));

						newPhoneObject.put("PhoneId", directoryItemObject.getObjectId());

						newPhoneObject.put("LocationId", templateObject.getObjectId());
						try {
							newPhoneObject.save();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				} catch (NullPointerException npe) {

				}

				checkChain(parseObjectOfParentDirectoryItem.getObjectId(), directoryItemObject,
						directoryItemObject.getObjectId(), templateObject.getObjectId());

			}

		} catch (NullPointerException npe) {

		}

		return "success";

		// getDataFromParse(request);
		/*
		 * adminLoad(request);
		 * 
		 * mav.addObject("userName", request.getParameter("userName"));
		 * mav.addObject("user", request.getParameter("user"));
		 * 
		 * if (request.getParameter("userName").equals("Location Admin"))
		 * mav.setViewName("LocationAdmin"); if
		 * (request.getParameter("userName").equals("CS Admin"))
		 * mav.setViewName("CSAdmin"); if
		 * (request.getParameter("userName").equals("Super Admin"))
		 * 
		 * mav.setViewName("SuperAdmin");
		 * 
		 * 
		 * return mav;
		 */
	}

	@RequestMapping(value = "/addNewDirectory", headers = "content-type=multipart/*")
	public ModelAndView addNewDirectoryItems(MultipartHttpServletRequest request) {

		final ModelAndView mav = new ModelAndView("CSAdmin");
		ParseFile pf = null;
		System.out.println(request.getParameter("title"));
		System.out.println(request.getParameter("caption"));
		System.out.println(request.getParameter("description"));
		System.out.println(request.getParameter("timings"));
		System.out.println(request.getParameter("website"));
		System.out.println(request.getParameter("email"));
		System.out.println(request.getParameter("directoryId"));

		MultipartFile multiFile = request.getFile("logo");
		String imageType = multiFile.getContentType();
		// just to show that we have actually received the file
		try {
			System.out.println("File Length:" + multiFile.getBytes().length);
			System.out.println("File Type:" + multiFile.getContentType());
			String fileName = multiFile.getOriginalFilename();
			System.out.println("File Name:" + fileName);
			pf = new ParseFile("Picture.jpg", multiFile.getBytes());
			try {
				pf.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				pf.save();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		ParseObject diretoryItemObject = new ParseObject("DirectoryItem");

		diretoryItemObject.put("Title", request.getParameter("title"));
		diretoryItemObject.put("Caption", request.getParameter("caption"));
		diretoryItemObject.put("Description", request.getParameter("description"));
		diretoryItemObject.put("Timings", request.getParameter("timings"));
		diretoryItemObject.put("Website", request.getParameter("website"));
		diretoryItemObject.put("Email", request.getParameter("email"));
		diretoryItemObject.put("DirectoryID", request.getParameter("directoryId"));
		diretoryItemObject.put("Picture", pf);

		try {
			diretoryItemObject.save();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			ParseQuery<ParseObject> query = ParseQuery.getQuery("Location");
			query.whereEqualTo("objectId", request.getParameter("directoryId"));
			results = query.find();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(results);
		List<EgsdLoctionObject> hlobj = new ArrayList<EgsdLoctionObject>();
		Iterator<ParseObject> hlit = results.listIterator();
		ParseObject p = null;
		while (hlit.hasNext()) {
			p = hlit.next();
			/*
			 * System.out.println(p.getObjectId());
			 * System.out.println(p.getString("Directories"));
			 * System.out.println(p.getString("Name"));
			 * System.out.println(p.getString("zipcode"));
			 * System.out.println(p.getString("Address1"));
			 */
			hlobj.add(new EgsdLoctionObject(p.getObjectId(), p.getString("Directories"), p.getString("Name"),
					p.getString("zipcode"), p.getString("Address1"), p.getString("Address2"), p.getString("Street"),
					p.getString("Town"), p.getString("GroupSiteId"), p.getString("GroupName"), p.getString("Country"),
					null, null, null, p.getString("description")));

			// hlobj.add(new
			// EgsdHotelAndLocObj(p.getString("hotel_name"),p.getString("location")));
		}
		System.out.println(hlobj);
		mav.addObject("locObj", hlobj);

		// this is for directory table objects

		List<EgsdDirectoryItemParseObject> directoryItemParseObjectsList = null;
		try {
			ParseQuery<EgsdDirectoryItemParseObject> queryForDirectoryItem = ParseQuery.getQuery("DirectoryItem");
			queryForDirectoryItem.whereEqualTo("DirectoryID", request.getParameter("directoryId"));
			queryForDirectoryItem.orderByAscending("Title");
			directoryItemParseObjectsList = queryForDirectoryItem.find();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EgsdDirectoryItemObjects> directoryItemObjectsList = new ArrayList<EgsdDirectoryItemObjects>(200);
		System.out.println("Directory items are loaded:");
		Iterator<EgsdDirectoryItemParseObject> iterator = directoryItemParseObjectsList.listIterator();
		System.out.println("objectId" + "---> " + "DirectoryId" + "--->" + "getParentDirectoryId" + "--->" + "getTitle"
				+ "--->" + "getCaption" + "--->" + "getTimings" + "--->" + "getWebsite" + "--->" + "getEmail" + "--->"
				+ "getPhones");
		while (iterator.hasNext()) {

			EgsdDirectoryItemParseObject egsd = iterator.next();
			/*
			 * System.out.println( egsd.getObjectId() + "---> " +
			 * egsd.getDirectoryId() + "--->" + egsd.getParentDirectoryId() +
			 * "--->" + egsd.getTitle() + "--->" + egsd.getCaption() + "--->" +
			 * egsd.getTimings() + "--->" + egsd.getWebsite() + "--->" +
			 * egsd.getEmail() + "--->" + egsd.getPhones() + "--->" +
			 * egsd.getStyleID() +"<--StyleID ");
			 */
			String img = "No Image To Display";
			if (egsd.getParseFile("Picture") != null)
				img = egsd.getParseFile("Picture").getUrl();
			// System.out.print(img);
			String styleId = null;
			ParseObject StyleIdPO = egsd.getParseObject("StyleId");
			if (egsd.getParseObject("StyleId") != null)
				styleId = StyleIdPO.getObjectId();
			// System.out.println(styleId);

			/*
			 * if(StyleIdPO.getObjectId()!=null) System.out.println(
			 * "StyleID AT Directory Items"+StyleIdPO.getObjectId());
			 */

			directoryItemObjectsList.add(new EgsdDirectoryItemObjects(egsd.getObjectId(), egsd.getDirectoryId(),
					egsd.getTitle(), egsd.getCaption(), egsd.getDescription(), egsd.getTimings(), egsd.getWebsite(),
					egsd.getEmail(), egsd.getParentDirectoryId(), img, styleId, egsd.getPhones(),
					egsd.getParentDirectoryId(), egsd.getLocationId(), egsd.getCustomizedOrder()));

		}
		System.out.println("before adding dir objs");
		mav.addObject("direcObjList", directoryItemObjectsList);
		mav.addObject("subDirObj", directoryItemObjectsList);
		mav.addObject("subsubDirObj", directoryItemObjectsList);
		mav.addObject("DirObjId", directoryItemObjectsList);
		mav.addObject("DiscriptionObjId", directoryItemObjectsList);
		System.out.println("aftr adding dir objs");

		return mav;
	}

	@RequestMapping(value = "/jstree")
	public String jstree(HttpServletRequest request) throws ParseException {
		String source = request.getParameter("sourceElementID");
		String dest = request.getParameter("destinationElementID");
		System.out.println("source is " + source);
		System.out.println("dest is " + dest);

		ParseObject jsTree = ParseObject.createWithoutData("DirectoryItem", source);
		if (dest != null && !dest.equals("")) {
			jsTree.put("DirectoryID", dest);
			jsTree.put("ParentDirectoryId", dest);
		}
		try {
			jsTree.save();
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return "";
	}

	@RequestMapping(value = "/adminApplication")
	public String adminApplication(HttpServletRequest request) throws ParseException {
		String elementID = request.getParameter("elementID");
		int frontDesk = Integer.parseInt(request.getParameter("frontDesk"));
		int baggage = Integer.parseInt(request.getParameter("baggage"));
		int maidService = Integer.parseInt(request.getParameter("maidService"));
		int emergency = Integer.parseInt(request.getParameter("emergency"));
		String food = request.getParameter("food");
		String taxi = request.getParameter("taxi");
		String localAttractions = request.getParameter("localAttractions");
		String hotelDirectory = request.getParameter("hotelDirectory");

		ParseObject parseObjectForLocation = ParseObject.createWithoutData("Location", elementID);

		if (frontDesk != 0) {
			parseObjectForLocation.put("FrontDesk", frontDesk);
		}
		if (baggage != 0) {
			parseObjectForLocation.put("BellDesk", baggage);
		}
		if (maidService != 0) {
			parseObjectForLocation.put("MaidDesk", maidService);
		}
		if (emergency != 0) {
			parseObjectForLocation.put("Emergency", emergency);
		}
		if (food != null) {
			parseObjectForLocation.put("food", food);
		}
		if (taxi != null) {
			parseObjectForLocation.put("taxi", taxi);
		}
		if (localAttractions != null) {
			parseObjectForLocation.put("localAttractions", localAttractions);
		}
		if (hotelDirectory != null) {
			parseObjectForLocation.put("hotelDirectory", hotelDirectory);
		}

		try {
			parseObjectForLocation.save();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "";
	}

	/*
	 * @RequestMapping(value = "/addLocation/{locName}") public @ResponseBody
	 * JsonResponse addLocation(@PathVariable("locName") String locName,
	 * BindingResult result ){ JsonResponse res = new JsonResponse(); //
	 * List<CSAdminUser> userList = new ArrayList<CSAdminUser>();
	 * ValidationUtils.rejectIfEmpty(result, "location",
	 * "Location can not be empty.");
	 * 
	 * System.out.println(); if(!result.hasErrors()){
	 * 
	 * res.setStatus("SUCCESS"); }else{ res.setStatus("FAIL");
	 * res.setResult(result.getAllErrors()); }
	 * 
	 * return res; }
	 */

}
