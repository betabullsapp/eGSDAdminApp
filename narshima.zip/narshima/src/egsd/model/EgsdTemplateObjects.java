package egsd.model;

public class EgsdTemplateObjects {

	
	private String objectId;
	private String name;
	private String locationId;
	private boolean customized;
	public EgsdTemplateObjects(String objectId, String name, String locationId, boolean customized) {
		super();
		this.objectId = objectId;
		this.name = name;
		this.locationId = locationId;
		this.customized = customized;
	}
	public String getObjectId() {
		return objectId;
	}
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public boolean isCustomized() {
		return customized;
	}
	public void setCustomized(boolean customized) {
		this.customized = customized;
	}
	@Override
	public String toString() {
		return "EgsdTemplateObjects [objectId=" + objectId + ", name=" + name + ", locationId=" + locationId
				+ ", customized=" + customized + "]";
	}
		
	
	
	
}
