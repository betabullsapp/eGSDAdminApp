package egsd.model;

import java.util.List;

public class DirectoryDetailsModel {
	
	List directoryList;
	List styleList;
	List menuList;
	List phoneList;
	public List getDirectoryList() {
		return directoryList;
	}
	public void setDirectoryList(List directoryList) {
		this.directoryList = directoryList;
	}
	public List getStyleList() {
		return styleList;
	}
	public void setStyleList(List styleList) {
		this.styleList = styleList;
	}
	public List getMenuList() {
		return menuList;
	}
	public void setMenuList(List menuList) {
		this.menuList = menuList;
	}
	public List getPhoneList() {
		return phoneList;
	}
	public void setPhoneList(List phoneList) {
		this.phoneList = phoneList;
	}

}
